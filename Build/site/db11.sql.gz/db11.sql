
-- Dump of TYPO3 Connection "Default"
-- MySQL dump 10.19  Distrib 10.3.29-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: db    Database: db
-- ------------------------------------------------------
-- Server version	10.3.30-MariaDB-1:10.3.30+maria~focal-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `backend_layout`
--

DROP TABLE IF EXISTS `backend_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backend_layout` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `config` text COLLATE utf8_unicode_ci NOT NULL,
  `icon` text COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_layout`
--

LOCK TABLES `backend_layout` WRITE;
/*!40000 ALTER TABLE `backend_layout` DISABLE KEYS */;
/*!40000 ALTER TABLE `backend_layout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_dashboards`
--

DROP TABLE IF EXISTS `be_dashboards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_dashboards` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `identifier` varchar(120) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `title` varchar(120) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `widgets` text COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_dashboards`
--

LOCK TABLES `be_dashboards` WRITE;
/*!40000 ALTER TABLE `be_dashboards` DISABLE KEYS */;
INSERT INTO `be_dashboards` VALUES (1,0,1647327668,1647327668,1,0,0,0,0,'b73d9cfd0dd6e942c4f1b69b84da310def44c694','My dashboard','{\"cce1bfd5b32c91d18c1a79c84b0544e4158f13fb\":{\"identifier\":\"t3information\"},\"4150914c687762ce876220e93d64f044c2117246\":{\"identifier\":\"t3news\"},\"c21f0a703f813c431531b54ff2f14c09541e069a\":{\"identifier\":\"docGettingStarted\"}}');
/*!40000 ALTER TABLE `be_dashboards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_groups`
--

DROP TABLE IF EXISTS `be_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `non_exclude_fields` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `explicit_allowdeny` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `allowed_languages` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `custom_options` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `db_mountpoints` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `pagetypes_select` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tables_select` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tables_modify` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `groupMods` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `availableWidgets` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_mountpoints` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_permissions` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `TSconfig` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `subgroup` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `workspace_perms` smallint(6) NOT NULL DEFAULT 1,
  `category_perms` longtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `mfa_providers` text COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_groups`
--

LOCK TABLES `be_groups` WRITE;
/*!40000 ALTER TABLE `be_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `be_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_users`
--

DROP TABLE IF EXISTS `be_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `username` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `avatar` int(10) unsigned NOT NULL DEFAULT 0,
  `password` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `admin` smallint(5) unsigned NOT NULL DEFAULT 0,
  `usergroup` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `lang` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'default',
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `db_mountpoints` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `options` smallint(5) unsigned NOT NULL DEFAULT 0,
  `realName` varchar(80) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `userMods` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `allowed_languages` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `uc` mediumblob DEFAULT NULL,
  `file_mountpoints` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_permissions` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `workspace_perms` smallint(6) NOT NULL DEFAULT 1,
  `TSconfig` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastlogin` int(10) unsigned NOT NULL DEFAULT 0,
  `workspace_id` int(11) NOT NULL DEFAULT 0,
  `category_perms` longtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `password_reset_token` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `mfa` mediumblob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `username` (`username`),
  KEY `parent` (`pid`,`deleted`,`disable`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_users`
--

LOCK TABLES `be_users` WRITE;
/*!40000 ALTER TABLE `be_users` DISABLE KEYS */;
INSERT INTO `be_users` VALUES (1,0,1647327691,1647327644,0,0,0,0,0,NULL,'admin',0,'$argon2i$v=19$m=65536,t=16,p=1$VnhldGFPVkFqL2VVWGcxOA$6JYFjdPYMY4XDWvE2HzvUDFdDNFnadPouHDqu2POn38',1,'','default','',NULL,0,'',NULL,'','a:15:{s:14:\"interfaceSetup\";s:7:\"backend\";s:10:\"moduleData\";a:11:{s:28:\"dashboard/current_dashboard/\";s:40:\"b73d9cfd0dd6e942c4f1b69b84da310def44c694\";s:8:\"web_list\";a:0:{}s:10:\"FormEngine\";a:2:{i:0;a:4:{s:32:\"39dbcbcf6026e584b0032e0fef8fd333\";a:4:{i:0;s:51:\"Task 2 - 1.6 - Project 1 - Customer GmbH - MOJzl56n\";i:1;a:5:{s:4:\"edit\";a:1:{s:28:\"tx_timelog_domain_model_task\";a:1:{i:2;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:51:\"&edit%5Btx_timelog_domain_model_task%5D%5B2%5D=edit\";i:3;a:5:{s:5:\"table\";s:28:\"tx_timelog_domain_model_task\";s:3:\"uid\";i:2;s:3:\"pid\";i:3;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"e99b862b5fb646163abd0b35eef975a2\";a:4:{i:0;s:47:\"Task group 1 - 0.7, -0.7 - Project 1 - 9d05nZyE\";i:1;a:5:{s:4:\"edit\";a:1:{s:33:\"tx_timelog_domain_model_taskgroup\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:56:\"&edit%5Btx_timelog_domain_model_taskgroup%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:33:\"tx_timelog_domain_model_taskgroup\";s:3:\"uid\";i:1;s:3:\"pid\";i:3;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"c04b4281e5af008c6e8aed1ddd85b79a\";a:4:{i:0;s:51:\"Task 3 - 1.7 - Project 2 - Customer GmbH - 105Nqp98\";i:1;a:5:{s:4:\"edit\";a:1:{s:28:\"tx_timelog_domain_model_task\";a:1:{i:3;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:51:\"&edit%5Btx_timelog_domain_model_task%5D%5B3%5D=edit\";i:3;a:5:{s:5:\"table\";s:28:\"tx_timelog_domain_model_task\";s:3:\"uid\";i:3;s:3:\"pid\";i:3;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"45aff0eb30a53b26ea009f39667df4f4\";a:4:{i:0;s:46:\"Task group 2 - 0.0, 0.0 - Project 1 - 9d05nZyE\";i:1;a:5:{s:4:\"edit\";a:1:{s:33:\"tx_timelog_domain_model_taskgroup\";a:1:{i:2;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:56:\"&edit%5Btx_timelog_domain_model_taskgroup%5D%5B2%5D=edit\";i:3;a:5:{s:5:\"table\";s:33:\"tx_timelog_domain_model_taskgroup\";s:3:\"uid\";i:2;s:3:\"pid\";i:3;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}}i:1;s:32:\"c04b4281e5af008c6e8aed1ddd85b79a\";}s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";a:0:{}s:6:\"web_ts\";a:2:{s:8:\"function\";s:88:\"TYPO3\\CMS\\Tstemplate\\Controller\\TypoScriptTemplateConstantEditorModuleFunctionController\";s:19:\"constant_editor_cat\";s:24:\"pizpalue: administration\";}s:10:\"web_layout\";a:2:{s:8:\"function\";s:1:\"1\";s:8:\"language\";s:1:\"0\";}s:16:\"opendocs::recent\";a:8:{s:32:\"c04b4281e5af008c6e8aed1ddd85b79a\";a:4:{i:0;s:23:\"Task 3 - 0.0 - 105Nqp98\";i:1;a:5:{s:4:\"edit\";a:1:{s:28:\"tx_timelog_domain_model_task\";a:1:{i:3;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:51:\"&edit%5Btx_timelog_domain_model_task%5D%5B3%5D=edit\";i:3;a:5:{s:5:\"table\";s:28:\"tx_timelog_domain_model_task\";s:3:\"uid\";i:3;s:3:\"pid\";i:3;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"97ed4e91b158c32d503348f4e976b184\";a:4:{i:0;s:58:\"Task 0956 - 0.6 - First project - Customer GmbH - MOJzl56n\";i:1;a:5:{s:4:\"edit\";a:1:{s:28:\"tx_timelog_domain_model_task\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:51:\"&edit%5Btx_timelog_domain_model_task%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:28:\"tx_timelog_domain_model_task\";s:3:\"uid\";i:1;s:3:\"pid\";i:3;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"db15bfe2bbbf7b61b5ca2250b6f6f078\";a:4:{i:0;s:35:\"First project - 0.0, 0.0 - 7wznO6qK\";i:1;a:5:{s:4:\"edit\";a:1:{s:31:\"tx_timelog_domain_model_project\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:54:\"&edit%5Btx_timelog_domain_model_project%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:31:\"tx_timelog_domain_model_project\";s:3:\"uid\";i:1;s:3:\"pid\";i:3;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"7375619f7e5538655fd7ef89e58101fd\";a:4:{i:0;s:49:\"Second project - 0.6, 0.6 - Owner GmbH - 7wznO6qK\";i:1;a:5:{s:4:\"edit\";a:1:{s:31:\"tx_timelog_domain_model_project\";a:1:{i:2;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:54:\"&edit%5Btx_timelog_domain_model_project%5D%5B2%5D=edit\";i:3;a:5:{s:5:\"table\";s:31:\"tx_timelog_domain_model_project\";s:3:\"uid\";i:2;s:3:\"pid\";i:3;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"39dbcbcf6026e584b0032e0fef8fd333\";a:4:{i:0;s:58:\"Task 0956 - 0.6 - First project - Customer GmbH - MOJzl56n\";i:1;a:5:{s:4:\"edit\";a:1:{s:28:\"tx_timelog_domain_model_task\";a:1:{i:2;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:51:\"&edit%5Btx_timelog_domain_model_task%5D%5B2%5D=edit\";i:3;a:5:{s:5:\"table\";s:28:\"tx_timelog_domain_model_task\";s:3:\"uid\";i:2;s:3:\"pid\";i:3;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"45aff0eb30a53b26ea009f39667df4f4\";a:4:{i:0;s:50:\"First task group - 0.0, 0.0 - Project 1 - 9d05nZyE\";i:1;a:5:{s:4:\"edit\";a:1:{s:33:\"tx_timelog_domain_model_taskgroup\";a:1:{i:2;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:56:\"&edit%5Btx_timelog_domain_model_taskgroup%5D%5B2%5D=edit\";i:3;a:5:{s:5:\"table\";s:33:\"tx_timelog_domain_model_taskgroup\";s:3:\"uid\";i:2;s:3:\"pid\";i:3;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"e99b862b5fb646163abd0b35eef975a2\";a:4:{i:0;s:50:\"First task group - 0.0, 0.0 - Project 1 - 9d05nZyE\";i:1;a:5:{s:4:\"edit\";a:1:{s:33:\"tx_timelog_domain_model_taskgroup\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:56:\"&edit%5Btx_timelog_domain_model_taskgroup%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:33:\"tx_timelog_domain_model_taskgroup\";s:3:\"uid\";i:1;s:3:\"pid\";i:3;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"2258d9587529a9ea12f96ce7d90372b3\";a:4:{i:0;s:4:\"Data\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:3;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:28:\"&edit%5Bpages%5D%5B3%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:3;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}}s:8:\"web_info\";a:4:{s:8:\"function\";s:60:\"TYPO3\\CMS\\Info\\Controller\\InfoPageTyposcriptConfigController\";s:8:\"language\";N;s:19:\"constant_editor_cat\";N;s:12:\"tsconf_parts\";s:1:\"6\";}s:47:\"TYPO3\\CMS\\Belog\\Controller\\BackendLogController\";s:334:\"O:39:\"TYPO3\\CMS\\Belog\\Domain\\Model\\Constraint\":11:{s:14:\"\0*\0userOrGroup\";s:1:\"0\";s:9:\"\0*\0number\";i:20;s:15:\"\0*\0workspaceUid\";i:-99;s:10:\"\0*\0channel\";s:0:\"\";s:8:\"\0*\0level\";s:5:\"debug\";s:17:\"\0*\0startTimestamp\";i:0;s:15:\"\0*\0endTimestamp\";i:0;s:18:\"\0*\0manualDateStart\";N;s:17:\"\0*\0manualDateStop\";N;s:9:\"\0*\0pageId\";i:0;s:8:\"\0*\0depth\";i:0;}\";s:9:\"clipboard\";a:5:{s:5:\"tab_1\";a:0:{}s:5:\"tab_2\";a:0:{}s:5:\"tab_3\";a:0:{}s:7:\"current\";s:6:\"normal\";s:6:\"normal\";a:2:{s:2:\"el\";a:1:{s:33:\"tx_timelog_domain_model_project|1\";s:1:\"1\";}s:4:\"mode\";s:4:\"copy\";}}s:13:\"system_config\";a:3:{s:4:\"tree\";s:20:\"httpMiddlewareStacks\";s:11:\"regexSearch\";b:0;s:25:\"node_httpMiddlewareStacks\";a:2:{s:7:\"backend\";i:1;s:11:\"raw.backend\";i:1;}}}s:19:\"thumbnailsByDefault\";i:1;s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";i:50;s:8:\"edit_RTE\";s:1:\"1\";s:20:\"edit_docModuleUpload\";s:1:\"1\";s:15:\"resizeTextareas\";i:1;s:25:\"resizeTextareas_MaxHeight\";i:500;s:24:\"resizeTextareas_Flexible\";i:0;s:4:\"lang\";s:7:\"default\";s:19:\"firstLoginTimeStamp\";i:1647327665;s:15:\"moduleSessionID\";a:10:{s:28:\"dashboard/current_dashboard/\";s:40:\"cb75b226949556cba884007553bebca293a35359\";s:8:\"web_list\";s:40:\"cb75b226949556cba884007553bebca293a35359\";s:10:\"FormEngine\";s:40:\"5be1cdd2566b4f2a53054eb58d543bc86d25f429\";s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";s:40:\"5be1cdd2566b4f2a53054eb58d543bc86d25f429\";s:6:\"web_ts\";s:40:\"eac96ed0a61501e291b10549ff9c84bc3916d97b\";s:10:\"web_layout\";s:40:\"eac96ed0a61501e291b10549ff9c84bc3916d97b\";s:16:\"opendocs::recent\";s:40:\"5be1cdd2566b4f2a53054eb58d543bc86d25f429\";s:8:\"web_info\";s:40:\"126c8e714d4d81cba9b5a6f57f6127643f554f4e\";s:47:\"TYPO3\\CMS\\Belog\\Controller\\BackendLogController\";s:40:\"126c8e714d4d81cba9b5a6f57f6127643f554f4e\";s:9:\"clipboard\";s:40:\"f5eac9083fbf397bd850d25e83e07c24fcc9ea68\";}s:17:\"BackendComponents\";a:1:{s:6:\"States\";a:2:{s:8:\"Pagetree\";a:1:{s:9:\"stateHash\";a:3:{s:3:\"0_0\";s:1:\"1\";s:3:\"0_1\";s:1:\"1\";s:3:\"0_2\";s:1:\"1\";}}s:16:\"ExtensionManager\";a:1:{s:6:\"filter\";s:5:\"Local\";}}}s:10:\"inlineView\";s:428:\"{\"site\":{\"1\":{\"site_language\":{\"1\":\"0\",\"2\":\"\"}}},\"tx_timelog_domain_model_task\":{\"NEW6230468b996b0922490505\":{\"tx_timelog_domain_model_interval\":[1]},\"NEW623982e320f1a633619573\":{\"tx_timelog_domain_model_interval\":[3]},\"3\":{\"tx_timelog_domain_model_interval\":{\"0\":4,\"1\":5,\"2\":6,\"3\":7,\"6\":\"8\"}}},\"tx_timelog_domain_model_project\":{\"1\":{\"tx_timelog_domain_model_taskgroup\":[1]},\"2\":{\"tx_timelog_domain_model_taskgroup\":{\"1\":\"\"}}}}\";}',NULL,NULL,1,NULL,1647927497,0,NULL,'',NULL);
/*!40000 ALTER TABLE `be_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_groups`
--

DROP TABLE IF EXISTS `fe_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tx_extbase_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `title` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `subgroup` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `TSconfig` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `felogin_redirectPid` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_groups`
--

LOCK TABLES `fe_groups` WRITE;
/*!40000 ALTER TABLE `fe_groups` DISABLE KEYS */;
INSERT INTO `fe_groups` VALUES (1,4,1647330293,1647330293,1,0,0,'','0','Users','','','');
/*!40000 ALTER TABLE `fe_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_users`
--

DROP TABLE IF EXISTS `fe_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tx_extbase_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `usergroup` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(160) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `first_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `middle_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `last_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `telephone` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `fax` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `uc` blob DEFAULT NULL,
  `title` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `zip` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `city` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `country` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `www` varchar(80) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `company` varchar(80) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `image` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `TSconfig` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastlogin` int(10) unsigned NOT NULL DEFAULT 0,
  `is_online` int(10) unsigned NOT NULL DEFAULT 0,
  `felogin_redirectPid` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `felogin_forgotHash` varchar(80) COLLATE utf8_unicode_ci DEFAULT '',
  `tx_timelog_owner_email` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `mfa` mediumblob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`username`(100)),
  KEY `username` (`username`(100)),
  KEY `is_online` (`is_online`),
  KEY `felogin_forgotHash` (`felogin_forgotHash`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_users`
--

LOCK TABLES `fe_users` WRITE;
/*!40000 ALTER TABLE `fe_users` DISABLE KEYS */;
INSERT INTO `fe_users` VALUES (1,4,1647501063,1647330356,1,0,0,0,0,'','0','owner','$argon2i$v=19$m=65536,t=16,p=1$a2pTUUp5ZkRoOFV2TlkwZg$0BgrijJbQ5VbmWu0EWbEflLZTdoETegRxOkWm1qwlyk','1','','First','Owner','','','','','first.owner@timelog.ddev.site',NULL,'','','','','','Owner GmbH','0','',0,0,'','','',NULL),(2,4,1647501050,1647330438,1,0,0,0,0,'','0','customer','$argon2i$v=19$m=65536,t=16,p=1$djJpemlWS2RXdmdwMS9aag$MD/CgZLbdkhiYPht2rTkDyjdE9iCHW/Fuz+hV9NV7ns','1','','First','','Customer','','','','first.customer@timelog.ddev.site',NULL,'','','','','','Customer GmbH','0','',0,0,'','','',NULL),(3,4,1647337900,1647337900,1,0,0,0,0,'','0','worker','$argon2i$v=19$m=65536,t=16,p=1$RUJ5dWh5WGNPVTdHRnAyZw$1J65UZJ1g5hJnka6brQPTlUkBCGpTPf/MjPRH0FKFRA','1','','First','','Worker','','','','first.worker@timelog.ddev.site',NULL,'','','','','','',NULL,'',0,0,'','','',NULL);
/*!40000 ALTER TABLE `fe_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `perms_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_groupid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_user` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_group` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_everybody` smallint(5) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(2048) COLLATE utf8_unicode_ci DEFAULT NULL,
  `doktype` int(10) unsigned NOT NULL DEFAULT 0,
  `TSconfig` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_siteroot` smallint(6) NOT NULL DEFAULT 0,
  `php_tree_stop` smallint(6) NOT NULL DEFAULT 0,
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `shortcut` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut_mode` int(10) unsigned NOT NULL DEFAULT 0,
  `subtitle` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `target` varchar(80) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `lastUpdated` int(10) unsigned NOT NULL DEFAULT 0,
  `keywords` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `cache_timeout` int(10) unsigned NOT NULL DEFAULT 0,
  `cache_tags` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `newUntil` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `no_search` smallint(5) unsigned NOT NULL DEFAULT 0,
  `SYS_LASTCHANGED` int(10) unsigned NOT NULL DEFAULT 0,
  `abstract` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `module` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `extendToSubpages` smallint(5) unsigned NOT NULL DEFAULT 0,
  `author` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `author_email` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `nav_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `nav_hide` smallint(6) NOT NULL DEFAULT 0,
  `content_from_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid_ol` smallint(6) NOT NULL DEFAULT 0,
  `l18n_cfg` smallint(6) NOT NULL DEFAULT 0,
  `fe_login_mode` smallint(6) NOT NULL DEFAULT 0,
  `backend_layout` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `backend_layout_next_level` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tsconfig_includes` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `seo_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `no_index` smallint(6) NOT NULL DEFAULT 0,
  `no_follow` smallint(6) NOT NULL DEFAULT 0,
  `og_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `og_description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `og_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `twitter_description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `twitter_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_card` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `canonical_link` varchar(2048) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sitemap_priority` decimal(2,1) NOT NULL DEFAULT 0.5,
  `sitemap_changefreq` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `nav_icon_set` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `nav_icon_identifier` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `nav_icon` int(10) unsigned DEFAULT 0,
  `thumbnail` int(10) unsigned DEFAULT 0,
  `tx_pizpalue_background_image` int(10) unsigned DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `determineSiteRoot` (`is_siteroot`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `slug` (`slug`(127)),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES (1,0,1647512027,1647327718,1,0,0,0,0,'',256,NULL,0,0,0,0,NULL,0,'{\"doktype\":\"\",\"title\":\"\",\"slug\":\"\",\"nav_title\":\"\",\"subtitle\":\"\",\"nav_icon_set\":\"\",\"nav_icon\":\"\",\"seo_title\":\"\",\"description\":\"\",\"no_index\":\"\",\"no_follow\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"og_title\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_card\":\"\",\"abstract\":\"\",\"keywords\":\"\",\"author\":\"\",\"author_email\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"newUntil\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tx_pizpalue_background_image\":\"\",\"thumbnail\":\"\",\"content_from_pid\":\"\",\"target\":\"\",\"cache_timeout\":\"\",\"cache_tags\":\"\",\"is_siteroot\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"module\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"\",\"hidden\":\"\",\"nav_hide\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"fe_login_mode\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,1,0,31,27,0,'Timelog development site','/',1,'TCEMAIN.preview {\r\n    tx_timelog_domain_model_project {\r\n        disableButtonForDokType = 255, 199\r\n        previewPageId = 2\r\n    }\r\n    tx_timelog_domain_model_taskgroup {\r\n        disableButtonForDokType = 255, 199\r\n        previewPageId = 2\r\n    }\r\n    tx_timelog_domain_model_task {\r\n        disableButtonForDokType = 255, 199\r\n        previewPageId = 2\r\n    }\r\n}',1,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1647512027,NULL,'',0,'','','',0,0,0,0,0,0,'pagets__simple','pagets__simple',NULL,0,'',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,'',0,'','',0,0,0),(2,1,1647512075,1647329880,1,0,0,0,0,'',256,NULL,0,0,0,0,NULL,0,'{\"doktype\":\"\",\"title\":\"\",\"slug\":\"\",\"nav_title\":\"\",\"subtitle\":\"\",\"nav_icon_set\":\"\",\"nav_icon\":\"\",\"seo_title\":\"\",\"description\":\"\",\"no_index\":\"\",\"no_follow\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"og_title\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_card\":\"\",\"abstract\":\"\",\"keywords\":\"\",\"author\":\"\",\"author_email\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"newUntil\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tx_pizpalue_background_image\":\"\",\"thumbnail\":\"\",\"content_from_pid\":\"\",\"target\":\"\",\"cache_timeout\":\"\",\"cache_tags\":\"\",\"is_siteroot\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"module\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"\",\"hidden\":\"\",\"nav_hide\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"fe_login_mode\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,1,1,31,31,0,'Timelog','/timelog',1,'',0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1647512075,NULL,'',0,'','','',0,0,0,0,0,0,'','',NULL,0,'',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,'',0,'','',0,0,0),(3,2,1647512065,1647329899,1,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,0,'{\"doktype\":\"\",\"title\":\"\",\"slug\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"module\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"hidden\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\",\"tx_pizpalue_background_image\":\"\"}',0,0,0,0,1,1,31,31,0,'Data','/timelog/data',254,'',0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,0,'','',NULL,0,'',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,'',0,'','',0,0,0),(4,1,1647330276,1647330272,1,0,0,0,0,'0',128,NULL,0,0,0,0,NULL,0,'{\"hidden\":null}',0,0,0,0,1,1,31,31,0,'Users','/users',254,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,0,'','',NULL,0,'',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,'',0,'','',0,0,0);
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_be_shortcuts`
--

DROP TABLE IF EXISTS `sys_be_shortcuts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_be_shortcuts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sc_group` smallint(6) NOT NULL DEFAULT 0,
  `route` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `arguments` text COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts`
--

LOCK TABLES `sys_be_shortcuts` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category`
--

DROP TABLE IF EXISTS `sys_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_category` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `parent` int(10) unsigned NOT NULL DEFAULT 0,
  `items` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `category_parent` (`parent`),
  KEY `category_list` (`pid`,`deleted`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category`
--

LOCK TABLES `sys_category` WRITE;
/*!40000 ALTER TABLE `sys_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category_record_mm`
--

DROP TABLE IF EXISTS `sys_category_record_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_category_record_mm` (
  `uid_local` int(10) unsigned NOT NULL DEFAULT 0,
  `uid_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `tablenames` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `fieldname` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sorting` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category_record_mm`
--

LOCK TABLES `sys_category_record_mm` WRITE;
/*!40000 ALTER TABLE `sys_category_record_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category_record_mm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file`
--

DROP TABLE IF EXISTS `sys_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `last_indexed` int(11) NOT NULL DEFAULT 0,
  `missing` smallint(6) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `type` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `metadata` int(11) NOT NULL DEFAULT 0,
  `identifier` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `identifier_hash` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `folder_hash` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `extension` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `mime_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `name` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `sha1` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `size` bigint(20) unsigned NOT NULL DEFAULT 0,
  `creation_date` int(11) NOT NULL DEFAULT 0,
  `modification_date` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `sel01` (`storage`,`identifier_hash`),
  KEY `folder` (`storage`,`folder_hash`),
  KEY `tstamp` (`tstamp`),
  KEY `lastindex` (`last_indexed`),
  KEY `sha1` (`sha1`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file`
--

LOCK TABLES `sys_file` WRITE;
/*!40000 ALTER TABLE `sys_file` DISABLE KEYS */;
INSERT INTO `sys_file` VALUES (1,0,1647328183,0,0,0,'2',0,'/typo3conf/ext/pizpalue/Resources/Public/Images/logo.svg','f58aecbf54576a74b25ac2b41de7ea67ab111985','dd94046bf22bb2ceaab9445e61808b94503ecba0','svg','image/svg+xml','logo.svg','209bad3465fb3ea3045e14b4fb46648e4fa669f0',6428,1647327504,1647262776),(2,0,1647328183,0,0,0,'2',0,'/typo3conf/ext/pizpalue/Resources/Public/Images/logo_inv.svg','6f173dfaa393763e1afe9baeac4ec8fcd222f105','dd94046bf22bb2ceaab9445e61808b94503ecba0','svg','image/svg+xml','logo_inv.svg','6fb1dcf4ee8443902d186f5960437bd32356e5c6',6426,1647327504,1647262776);
/*!40000 ALTER TABLE `sys_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_collection`
--

DROP TABLE IF EXISTS `sys_file_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_collection` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'static',
  `files` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `folder` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `recursive` smallint(6) NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_collection`
--

LOCK TABLES `sys_file_collection` WRITE;
/*!40000 ALTER TABLE `sys_file_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_collection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_metadata`
--

DROP TABLE IF EXISTS `sys_file_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_metadata` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `file` int(11) NOT NULL DEFAULT 0,
  `title` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `width` int(11) NOT NULL DEFAULT 0,
  `height` int(11) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `alternative` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `file` (`file`),
  KEY `fal_filelist` (`l10n_parent`,`sys_language_uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_metadata`
--

LOCK TABLES `sys_file_metadata` WRITE;
/*!40000 ALTER TABLE `sys_file_metadata` DISABLE KEYS */;
INSERT INTO `sys_file_metadata` VALUES (1,0,1647328182,1647328182,1,0,0,NULL,0,'',0,0,0,0,1,NULL,1773,600,NULL,NULL,0),(2,0,1647328182,1647328182,1,0,0,NULL,0,'',0,0,0,0,2,NULL,1773,600,NULL,NULL,0);
/*!40000 ALTER TABLE `sys_file_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_processedfile`
--

DROP TABLE IF EXISTS `sys_file_processedfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_processedfile` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `original` int(11) NOT NULL DEFAULT 0,
  `identifier` varchar(512) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `name` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `processing_url` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `configuration` blob DEFAULT NULL,
  `configurationsha1` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `originalfilesha1` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `task_type` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `checksum` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `width` int(11) DEFAULT 0,
  `height` int(11) DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `combined_1` (`original`,`task_type`(100),`configurationsha1`),
  KEY `identifier` (`storage`,`identifier`(180))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_processedfile`
--

LOCK TABLES `sys_file_processedfile` WRITE;
/*!40000 ALTER TABLE `sys_file_processedfile` DISABLE KEYS */;
INSERT INTO `sys_file_processedfile` VALUES (1,1647328183,1647328183,0,1,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','209bad3465fb3ea3045e14b4fb46648e4fa669f0','Image.CropScaleMask','458d20b702',1773,600),(2,1647328183,1647328183,0,2,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','6fb1dcf4ee8443902d186f5960437bd32356e5c6','Image.CropScaleMask','ff6c9ed4e2',1773,600);
/*!40000 ALTER TABLE `sys_file_processedfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_reference`
--

DROP TABLE IF EXISTS `sys_file_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_reference` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `fieldname` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  `table_local` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `title` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `alternative` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `link` varchar(1024) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `crop` varchar(4000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `autoplay` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `tablenames_fieldname` (`tablenames`(32),`fieldname`(12)),
  KEY `deleted` (`deleted`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`),
  KEY `combined_1` (`l10n_parent`,`t3ver_oid`,`t3ver_wsid`,`t3ver_state`,`deleted`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_reference`
--

LOCK TABLES `sys_file_reference` WRITE;
/*!40000 ALTER TABLE `sys_file_reference` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_reference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_storage`
--

DROP TABLE IF EXISTS `sys_file_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_storage` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `driver` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `configuration` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_default` smallint(6) NOT NULL DEFAULT 0,
  `is_browsable` smallint(6) NOT NULL DEFAULT 0,
  `is_public` smallint(6) NOT NULL DEFAULT 0,
  `is_writable` smallint(6) NOT NULL DEFAULT 0,
  `is_online` smallint(6) NOT NULL DEFAULT 1,
  `auto_extract_metadata` smallint(6) NOT NULL DEFAULT 1,
  `processingfolder` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_storage`
--

LOCK TABLES `sys_file_storage` WRITE;
/*!40000 ALTER TABLE `sys_file_storage` DISABLE KEYS */;
INSERT INTO `sys_file_storage` VALUES (1,0,1647327684,1647327684,0,0,'This is the local fileadmin/ directory. This storage mount has been created automatically by TYPO3.','fileadmin/ (auto-created)','Local','<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"basePath\">\n                    <value index=\"vDEF\">fileadmin/</value>\n                </field>\n                <field index=\"pathType\">\n                    <value index=\"vDEF\">relative</value>\n                </field>\n                <field index=\"caseSensitive\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',1,1,1,1,1,1,NULL);
/*!40000 ALTER TABLE `sys_file_storage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_filemounts`
--

DROP TABLE IF EXISTS `sys_filemounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_filemounts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `path` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `base` int(10) unsigned NOT NULL DEFAULT 0,
  `read_only` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_filemounts`
--

LOCK TABLES `sys_filemounts` WRITE;
/*!40000 ALTER TABLE `sys_filemounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_filemounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_history`
--

DROP TABLE IF EXISTS `sys_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_history` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `actiontype` smallint(6) NOT NULL DEFAULT 0,
  `usertype` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'BE',
  `userid` int(10) unsigned DEFAULT NULL,
  `originaluserid` int(10) unsigned DEFAULT NULL,
  `recuid` int(11) NOT NULL DEFAULT 0,
  `tablename` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `history_data` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `workspace` int(11) DEFAULT 0,
  `correlation_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `recordident_1` (`tablename`(100),`recuid`),
  KEY `recordident_2` (`tablename`(100),`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=167 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_history`
--

LOCK TABLES `sys_history` WRITE;
/*!40000 ALTER TABLE `sys_history` DISABLE KEYS */;
INSERT INTO `sys_history` VALUES (1,1647327691,2,'BE',1,0,1,'be_users','{\"oldRecord\":{\"password\":\"$argon2i$v=19$m=65536,t=16,p=1$TmtmQmY0LnRhTERHeWI4Zg$+i+i3hC4MAJvbpAJ7VmeLj+GFNc+BB01\\/brmPgFzkKw\"},\"newRecord\":{\"password\":\"$argon2i$v=19$m=65536,t=16,p=1$VnhldGFPVkFqL2VVWGcxOA$6JYFjdPYMY4XDWvE2HzvUDFdDNFnadPouHDqu2POn38\"}}',0,'0400$44d1b1cde027e72cad2f76ee129474bc:084907bc914ff27cf2301aec50eb66b2'),(2,1647327718,1,'BE',1,0,1,'pages','{\"uid\":1,\"pid\":0,\"tstamp\":1647327718,\"crdate\":1647327718,\"cruser_id\":1,\"deleted\":0,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"fe_group\":\"0\",\"sorting\":256,\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"t3ver_count\":0,\"t3ver_tstamp\":0,\"t3ver_move_id\":0,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Timelog development site\",\"slug\":\"\\/\",\"doktype\":1,\"TSconfig\":null,\"is_siteroot\":0,\"php_tree_stop\":0,\"url\":\"\",\"shortcut\":0,\"shortcut_mode\":0,\"subtitle\":\"\",\"layout\":0,\"target\":\"\",\"media\":0,\"lastUpdated\":0,\"keywords\":null,\"cache_timeout\":0,\"cache_tags\":\"\",\"newUntil\":0,\"description\":null,\"no_search\":0,\"SYS_LASTCHANGED\":0,\"abstract\":null,\"module\":\"\",\"extendToSubpages\":0,\"author\":\"\",\"author_email\":\"\",\"nav_title\":\"\",\"nav_hide\":0,\"content_from_pid\":0,\"mount_pid\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"fe_login_mode\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":null,\"legacy_overlay_uid\":0,\"tx_impexp_origuid\":0,\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"og_title\":\"\",\"og_description\":null,\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":null,\"twitter_image\":0,\"twitter_card\":\"summary\",\"canonical_link\":\"\",\"sitemap_priority\":\"0.5\",\"sitemap_changefreq\":\"\",\"categories\":0}',0,'0400$666c6deb9941cf44fbab922b796e66d5:e175f7045d7ccbfb26ffcf279422c2e5'),(3,1647327722,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"a:1:{s:6:\\\"hidden\\\";N;}\"}}',0,'0400$ed941898dd822b3652253c3928aece26:e175f7045d7ccbfb26ffcf279422c2e5'),(4,1647327736,1,'BE',1,0,1,'sys_template','{\"uid\":1,\"pid\":1,\"tstamp\":1647327736,\"crdate\":1647327736,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"sorting\":256,\"description\":null,\"t3_origuid\":0,\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"t3ver_count\":0,\"t3ver_tstamp\":0,\"t3ver_move_id\":0,\"title\":\"+ext\",\"sitetitle\":\"\",\"root\":0,\"clear\":0,\"include_static_file\":null,\"constants\":null,\"config\":null,\"basedOn\":\"\",\"includeStaticAfterBasedOn\":0,\"static_file_mode\":0,\"tx_impexp_origuid\":0}',0,'0400$ad550c6887d4141fa65824abbb79ae99:35af6288617af54964e77af08c30949a'),(5,1647327787,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"title\":\"+ext\",\"clear\":0,\"root\":0},\"newRecord\":{\"title\":\"Pizpalue\",\"clear\":\"3\",\"root\":\"1\"}}',0,'0400$66b5d2d84f8c13d1403e3fd4d4ac46c7:35af6288617af54964e77af08c30949a'),(6,1647328136,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"include_static_file\":null},\"newRecord\":{\"include_static_file\":\"EXT:bootstrap_package\\/Configuration\\/TypoScript,EXT:timelog\\/Configuration\\/TypoScript,EXT:pizpalue\\/Configuration\\/TypoScript\\/Main\"}}',0,'0400$99e07d463d83ac898d6118f8433573d8:35af6288617af54964e77af08c30949a'),(7,1647328177,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"is_siteroot\":0,\"fe_group\":\"0\",\"l10n_diffsource\":\"a:1:{s:6:\\\"hidden\\\";N;}\"},\"newRecord\":{\"is_siteroot\":\"1\",\"fe_group\":\"\",\"l10n_diffsource\":\"a:54:{s:7:\\\"doktype\\\";N;s:5:\\\"title\\\";N;s:4:\\\"slug\\\";N;s:9:\\\"nav_title\\\";N;s:8:\\\"subtitle\\\";N;s:12:\\\"nav_icon_set\\\";N;s:8:\\\"nav_icon\\\";N;s:9:\\\"seo_title\\\";N;s:11:\\\"description\\\";N;s:8:\\\"no_index\\\";N;s:9:\\\"no_follow\\\";N;s:14:\\\"canonical_link\\\";N;s:18:\\\"sitemap_changefreq\\\";N;s:16:\\\"sitemap_priority\\\";N;s:8:\\\"og_title\\\";N;s:14:\\\"og_description\\\";N;s:8:\\\"og_image\\\";N;s:13:\\\"twitter_title\\\";N;s:19:\\\"twitter_description\\\";N;s:13:\\\"twitter_image\\\";N;s:12:\\\"twitter_card\\\";N;s:8:\\\"abstract\\\";N;s:8:\\\"keywords\\\";N;s:6:\\\"author\\\";N;s:12:\\\"author_email\\\";N;s:11:\\\"lastUpdated\\\";N;s:6:\\\"layout\\\";N;s:8:\\\"newUntil\\\";N;s:14:\\\"backend_layout\\\";N;s:25:\\\"backend_layout_next_level\\\";N;s:28:\\\"tx_pizpalue_background_image\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"content_from_pid\\\";N;s:6:\\\"target\\\";N;s:13:\\\"cache_timeout\\\";N;s:10:\\\"cache_tags\\\";N;s:11:\\\"is_siteroot\\\";N;s:9:\\\"no_search\\\";N;s:13:\\\"php_tree_stop\\\";N;s:6:\\\"module\\\";N;s:5:\\\"media\\\";N;s:17:\\\"tsconfig_includes\\\";N;s:8:\\\"TSconfig\\\";N;s:8:\\\"l18n_cfg\\\";N;s:6:\\\"hidden\\\";N;s:8:\\\"nav_hide\\\";N;s:9:\\\"starttime\\\";N;s:7:\\\"endtime\\\";N;s:16:\\\"extendToSubpages\\\";N;s:8:\\\"fe_group\\\";N;s:13:\\\"fe_login_mode\\\";N;s:8:\\\"editlock\\\";N;s:10:\\\"categories\\\";N;s:14:\\\"rowDescription\\\";N;}\"}}',0,'0400$df35a5088bbcf841d7869c8fd06dadbb:e175f7045d7ccbfb26ffcf279422c2e5'),(8,1647328208,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout\":\"\",\"backend_layout_next_level\":\"\"},\"newRecord\":{\"backend_layout\":\"pagets__simple\",\"backend_layout_next_level\":\"pagets__simple\"}}',0,'0400$ea38cf3465bef85e09c6020ea96d09cb:e175f7045d7ccbfb26ffcf279422c2e5'),(9,1647328236,1,'BE',1,0,1,'tt_content','{\"uid\":1,\"rowDescription\":\"\",\"pid\":1,\"tstamp\":1647328236,\"crdate\":1647328236,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":256,\"editlock\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l18n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"t3ver_count\":0,\"t3ver_tstamp\":0,\"t3ver_move_id\":0,\"CType\":\"header\",\"header\":\"Timelog dec site\",\"header_position\":\"center\",\"bodytext\":null,\"bullets_type\":0,\"uploads_description\":0,\"uploads_type\":0,\"assets\":0,\"image\":0,\"imagewidth\":0,\"imageorient\":0,\"imagecols\":1,\"imageborder\":0,\"media\":0,\"layout\":\"0\",\"frame_class\":\"default\",\"cols\":0,\"space_before_class\":\"\",\"space_after_class\":\"\",\"records\":null,\"pages\":null,\"colPos\":8,\"subheader\":\"\",\"header_link\":\"\",\"image_zoom\":0,\"header_layout\":\"1\",\"list_type\":\"\",\"sectionIndex\":1,\"linkToTop\":0,\"file_collections\":null,\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"date\":0,\"recursive\":0,\"imageheight\":0,\"pi_flexform\":null,\"accessibility_title\":\"\",\"accessibility_bypass\":0,\"accessibility_bypass_text\":\"\",\"selected_categories\":null,\"category_field\":\"\",\"table_class\":\"\",\"table_caption\":null,\"table_delimiter\":124,\"table_enclosure\":0,\"table_header_position\":0,\"table_tfoot\":0,\"tx_impexp_origuid\":0,\"categories\":0,\"teaser\":null,\"aspect_ratio\":\"1.3333333333333\",\"items_per_page\":10,\"readmore_label\":\"\",\"quote_source\":\"\",\"quote_link\":\"\",\"panel_class\":\"default\",\"file_folder\":null,\"icon\":\"\",\"icon_set\":\"\",\"icon_file\":0,\"icon_position\":\"\",\"icon_size\":\"default\",\"icon_type\":\"default\",\"icon_color\":\"#FFFFFF\",\"icon_background\":\"#333333\",\"external_media_source\":\"\",\"external_media_ratio\":\"\",\"tx_bootstrappackage_card_group_item\":0,\"tx_bootstrappackage_carousel_item\":0,\"tx_bootstrappackage_accordion_item\":0,\"tx_bootstrappackage_icon_group_item\":0,\"tx_bootstrappackage_tab_item\":0,\"tx_bootstrappackage_timeline_item\":0,\"frame_layout\":\"default\",\"background_color_class\":\"primary\",\"background_image\":0,\"background_image_options\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"parallax\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"fade\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"filter\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"tx_pizpalue_header_class\":\"none\",\"tx_pizpalue_subheader_class\":\"none\",\"tx_pizpalue_layout_breakpoint\":\"\",\"tx_pizpalue_classes\":\"\",\"tx_pizpalue_style\":\"\",\"tx_pizpalue_attributes\":\"\",\"tx_pizpalue_animation\":\"0\",\"tx_pizpalue_image_variants\":\"variants\",\"tx_pizpalue_background_image_variants\":\"pageVariants\",\"tx_pizpalue_image_scaling\":\"xxl: 1.0,\\nxl: 1.0,\\nlg: 1.0,\\nmd: 1.0,\\nsm: 1.0,\\nxs: 1.0\",\"tx_pizpalue_image_aspect_ratio\":\"xxl: 0,\\nxl: 0,\\nlg: 0,\\nmd: 0,\\nsm: 0,\\nxs: 0\"}',0,'0400$b094d309efa05da8033bc1c28a5707e3:7fa2c035f26826fe83eeecaaeddc4d40'),(10,1647328247,2,'BE',1,0,1,'tt_content','{\"oldRecord\":{\"header\":\"Timelog dec site\",\"l18n_diffsource\":\"\"},\"newRecord\":{\"header\":\"Timelog dev site\",\"l18n_diffsource\":\"a:34:{s:5:\\\"CType\\\";N;s:6:\\\"colPos\\\";N;s:6:\\\"header\\\";N;s:13:\\\"header_layout\\\";N;s:24:\\\"tx_pizpalue_header_class\\\";N;s:15:\\\"header_position\\\";N;s:4:\\\"date\\\";N;s:11:\\\"header_link\\\";N;s:9:\\\"subheader\\\";N;s:27:\\\"tx_pizpalue_subheader_class\\\";N;s:6:\\\"layout\\\";N;s:29:\\\"tx_pizpalue_layout_breakpoint\\\";N;s:18:\\\"space_before_class\\\";N;s:17:\\\"space_after_class\\\";N;s:11:\\\"frame_class\\\";N;s:12:\\\"frame_layout\\\";N;s:22:\\\"background_color_class\\\";N;s:16:\\\"background_image\\\";N;s:24:\\\"background_image_options\\\";N;s:37:\\\"tx_pizpalue_background_image_variants\\\";N;s:21:\\\"tx_pizpalue_animation\\\";N;s:19:\\\"tx_pizpalue_classes\\\";N;s:17:\\\"tx_pizpalue_style\\\";N;s:22:\\\"tx_pizpalue_attributes\\\";N;s:12:\\\"sectionIndex\\\";N;s:9:\\\"linkToTop\\\";N;s:16:\\\"sys_language_uid\\\";N;s:6:\\\"hidden\\\";N;s:9:\\\"starttime\\\";N;s:7:\\\"endtime\\\";N;s:8:\\\"fe_group\\\";N;s:8:\\\"editlock\\\";N;s:10:\\\"categories\\\";N;s:14:\\\"rowDescription\\\";N;}\"}}',0,'0400$80c1e6a523cc0f875787d47674183c2d:7fa2c035f26826fe83eeecaaeddc4d40'),(11,1647329880,1,'BE',1,0,2,'pages','{\"uid\":2,\"pid\":1,\"tstamp\":1647329880,\"crdate\":1647329880,\"cruser_id\":1,\"deleted\":0,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"fe_group\":\"0\",\"sorting\":256,\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"t3ver_count\":0,\"t3ver_tstamp\":0,\"t3ver_move_id\":0,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"title\":\"Timelog\",\"slug\":\"\\/timelog\",\"doktype\":1,\"TSconfig\":null,\"is_siteroot\":0,\"php_tree_stop\":0,\"url\":\"\",\"shortcut\":0,\"shortcut_mode\":0,\"subtitle\":\"\",\"layout\":0,\"target\":\"\",\"media\":0,\"lastUpdated\":0,\"keywords\":null,\"cache_timeout\":0,\"cache_tags\":\"\",\"newUntil\":0,\"description\":null,\"no_search\":0,\"SYS_LASTCHANGED\":0,\"abstract\":null,\"module\":\"\",\"extendToSubpages\":0,\"author\":\"\",\"author_email\":\"\",\"nav_title\":\"\",\"nav_hide\":0,\"content_from_pid\":0,\"mount_pid\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"fe_login_mode\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":null,\"legacy_overlay_uid\":0,\"tx_impexp_origuid\":0,\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"og_title\":\"\",\"og_description\":null,\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":null,\"twitter_image\":0,\"twitter_card\":\"summary\",\"canonical_link\":\"\",\"sitemap_priority\":\"0.5\",\"sitemap_changefreq\":\"\",\"categories\":0,\"nav_icon_set\":\"\",\"nav_icon_identifier\":\"\",\"nav_icon\":0,\"thumbnail\":0,\"tx_pizpalue_background_image\":0}',0,'0400$60a9393181cd1bfd29ed3d9a625162f4:f11830df10b4b0bca2db34810c2241b3'),(12,1647329885,2,'BE',1,0,2,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"a:1:{s:6:\\\"hidden\\\";N;}\"}}',0,'0400$6f5e649896de9cea77a12f42ed29b0ff:f11830df10b4b0bca2db34810c2241b3'),(13,1647329899,1,'BE',1,0,3,'pages','{\"uid\":3,\"pid\":2,\"tstamp\":1647329899,\"crdate\":1647329899,\"cruser_id\":1,\"deleted\":0,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"fe_group\":\"0\",\"sorting\":256,\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"t3ver_count\":0,\"t3ver_tstamp\":0,\"t3ver_move_id\":0,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"title\":\"Data\",\"slug\":\"\\/timelog\\/data\",\"doktype\":254,\"TSconfig\":null,\"is_siteroot\":0,\"php_tree_stop\":0,\"url\":\"\",\"shortcut\":0,\"shortcut_mode\":0,\"subtitle\":\"\",\"layout\":0,\"target\":\"\",\"media\":0,\"lastUpdated\":0,\"keywords\":null,\"cache_timeout\":0,\"cache_tags\":\"\",\"newUntil\":0,\"description\":null,\"no_search\":0,\"SYS_LASTCHANGED\":0,\"abstract\":null,\"module\":\"\",\"extendToSubpages\":0,\"author\":\"\",\"author_email\":\"\",\"nav_title\":\"\",\"nav_hide\":0,\"content_from_pid\":0,\"mount_pid\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"fe_login_mode\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":null,\"legacy_overlay_uid\":0,\"tx_impexp_origuid\":0,\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"og_title\":\"\",\"og_description\":null,\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":null,\"twitter_image\":0,\"twitter_card\":\"summary\",\"canonical_link\":\"\",\"sitemap_priority\":\"0.5\",\"sitemap_changefreq\":\"\",\"categories\":0,\"nav_icon_set\":\"\",\"nav_icon_identifier\":\"\",\"nav_icon\":0,\"thumbnail\":0,\"tx_pizpalue_background_image\":0}',0,'0400$1d3e723b176f40e7c56c51fc5aa2eb27:fe15eeb7d49e64e2cea91ab53fcf0db1'),(14,1647329902,2,'BE',1,0,3,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"a:1:{s:6:\\\"hidden\\\";N;}\"}}',0,'0400$62243cef119f04628220ca60d578e80b:fe15eeb7d49e64e2cea91ab53fcf0db1'),(15,1647329924,1,'BE',1,0,2,'tt_content','{\"uid\":2,\"rowDescription\":\"\",\"pid\":2,\"tstamp\":1647329924,\"crdate\":1647329924,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":256,\"editlock\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l18n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"t3ver_count\":0,\"t3ver_tstamp\":0,\"t3ver_move_id\":0,\"CType\":\"list\",\"header\":\"\",\"header_position\":\"\",\"bodytext\":null,\"bullets_type\":0,\"uploads_description\":0,\"uploads_type\":0,\"assets\":0,\"image\":0,\"imagewidth\":0,\"imageorient\":0,\"imagecols\":1,\"imageborder\":0,\"media\":0,\"layout\":\"0\",\"frame_class\":\"default\",\"cols\":0,\"space_before_class\":\"\",\"space_after_class\":\"\",\"records\":null,\"pages\":\"\",\"colPos\":0,\"subheader\":\"\",\"header_link\":\"\",\"image_zoom\":0,\"header_layout\":\"0\",\"list_type\":\"timelog_taskpanel\",\"sectionIndex\":1,\"linkToTop\":0,\"file_collections\":null,\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"date\":0,\"recursive\":0,\"imageheight\":0,\"pi_flexform\":null,\"accessibility_title\":\"\",\"accessibility_bypass\":0,\"accessibility_bypass_text\":\"\",\"selected_categories\":null,\"category_field\":\"\",\"table_class\":\"\",\"table_caption\":null,\"table_delimiter\":124,\"table_enclosure\":0,\"table_header_position\":0,\"table_tfoot\":0,\"tx_impexp_origuid\":0,\"categories\":0,\"teaser\":null,\"aspect_ratio\":\"1.3333333333333\",\"items_per_page\":10,\"readmore_label\":\"\",\"quote_source\":\"\",\"quote_link\":\"\",\"panel_class\":\"default\",\"file_folder\":null,\"icon\":\"\",\"icon_set\":\"\",\"icon_file\":0,\"icon_position\":\"\",\"icon_size\":\"default\",\"icon_type\":\"default\",\"icon_color\":\"#FFFFFF\",\"icon_background\":\"#333333\",\"external_media_source\":\"\",\"external_media_ratio\":\"\",\"tx_bootstrappackage_card_group_item\":0,\"tx_bootstrappackage_carousel_item\":0,\"tx_bootstrappackage_accordion_item\":0,\"tx_bootstrappackage_icon_group_item\":0,\"tx_bootstrappackage_tab_item\":0,\"tx_bootstrappackage_timeline_item\":0,\"frame_layout\":\"default\",\"background_color_class\":\"none\",\"background_image\":0,\"background_image_options\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"parallax\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"fade\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"filter\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"tx_pizpalue_header_class\":\"none\",\"tx_pizpalue_subheader_class\":\"none\",\"tx_pizpalue_layout_breakpoint\":\"\",\"tx_pizpalue_classes\":\"\",\"tx_pizpalue_style\":\"\",\"tx_pizpalue_attributes\":\"\",\"tx_pizpalue_animation\":\"0\",\"tx_pizpalue_image_variants\":\"variants\",\"tx_pizpalue_background_image_variants\":\"pageVariants\",\"tx_pizpalue_image_scaling\":\"xxl: 1.0,\\nxl: 1.0,\\nlg: 1.0,\\nmd: 1.0,\\nsm: 1.0,\\nxs: 1.0\",\"tx_pizpalue_image_aspect_ratio\":\"xxl: 0,\\nxl: 0,\\nlg: 0,\\nmd: 0,\\nsm: 0,\\nxs: 0\"}',0,'0400$8398ffe3f6ebb8fbd809cf9a883459f3:01dbc21fdb1263685b9147b3b1596ea8'),(16,1647329958,2,'BE',1,0,2,'tt_content','{\"oldRecord\":{\"pages\":\"\",\"l18n_diffsource\":\"\"},\"newRecord\":{\"pages\":\"3\",\"l18n_diffsource\":\"a:38:{s:5:\\\"CType\\\";N;s:6:\\\"colPos\\\";N;s:6:\\\"header\\\";N;s:13:\\\"header_layout\\\";N;s:24:\\\"tx_pizpalue_header_class\\\";N;s:15:\\\"header_position\\\";N;s:4:\\\"date\\\";N;s:11:\\\"header_link\\\";N;s:9:\\\"subheader\\\";N;s:27:\\\"tx_pizpalue_subheader_class\\\";N;s:9:\\\"list_type\\\";N;s:26:\\\"tx_pizpalue_image_variants\\\";N;s:5:\\\"pages\\\";N;s:9:\\\"recursive\\\";N;s:6:\\\"layout\\\";N;s:29:\\\"tx_pizpalue_layout_breakpoint\\\";N;s:18:\\\"space_before_class\\\";N;s:17:\\\"space_after_class\\\";N;s:11:\\\"frame_class\\\";N;s:12:\\\"frame_layout\\\";N;s:22:\\\"background_color_class\\\";N;s:16:\\\"background_image\\\";N;s:24:\\\"background_image_options\\\";N;s:37:\\\"tx_pizpalue_background_image_variants\\\";N;s:21:\\\"tx_pizpalue_animation\\\";N;s:19:\\\"tx_pizpalue_classes\\\";N;s:17:\\\"tx_pizpalue_style\\\";N;s:22:\\\"tx_pizpalue_attributes\\\";N;s:12:\\\"sectionIndex\\\";N;s:9:\\\"linkToTop\\\";N;s:16:\\\"sys_language_uid\\\";N;s:6:\\\"hidden\\\";N;s:9:\\\"starttime\\\";N;s:7:\\\"endtime\\\";N;s:8:\\\"fe_group\\\";N;s:8:\\\"editlock\\\";N;s:10:\\\"categories\\\";N;s:14:\\\"rowDescription\\\";N;}\"}}',0,'0400$0900049e7c587010ed8a2d97cec73f86:01dbc21fdb1263685b9147b3b1596ea8'),(17,1647329967,2,'BE',1,0,2,'tt_content','{\"oldRecord\":{\"pages\":\"3\"},\"newRecord\":{\"pages\":\"\"}}',0,'0400$58f885e6b3712ea5fc9bf9686172427b:01dbc21fdb1263685b9147b3b1596ea8'),(18,1647329974,1,'BE',1,0,2,'sys_template','{\"uid\":2,\"pid\":2,\"tstamp\":1647329974,\"crdate\":1647329974,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"sorting\":256,\"description\":null,\"t3_origuid\":0,\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"t3ver_count\":0,\"t3ver_tstamp\":0,\"t3ver_move_id\":0,\"title\":\"+ext\",\"sitetitle\":\"\",\"root\":0,\"clear\":0,\"include_static_file\":null,\"constants\":null,\"config\":null,\"basedOn\":\"\",\"includeStaticAfterBasedOn\":0,\"static_file_mode\":0,\"tx_impexp_origuid\":0}',0,'0400$fd9f77517bf2cc331730d0593014326c:092a6d165d49be6de27c1b2c5d7d6698'),(19,1647330046,2,'BE',1,0,2,'sys_template','{\"oldRecord\":{\"constants\":null},\"newRecord\":{\"constants\":\"\\nplugin.tx_timelog_taskpanel.persistence.storagePid = 3\"}}',0,'0400$2ef239c68ab6d34b62b75e396295b6b2:092a6d165d49be6de27c1b2c5d7d6698'),(20,1647330154,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":null},\"newRecord\":{\"constants\":\"\\npizpalue.agency.siteMode = 2\"}}',0,'0400$794987225c144946a1c6d85a1513216f:35af6288617af54964e77af08c30949a'),(21,1647330272,1,'BE',1,0,4,'pages','{\"uid\":4,\"pid\":1,\"tstamp\":1647330272,\"crdate\":1647330272,\"cruser_id\":1,\"deleted\":0,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"fe_group\":\"0\",\"sorting\":128,\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"t3ver_count\":0,\"t3ver_tstamp\":0,\"t3ver_move_id\":0,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"title\":\"Users\",\"slug\":\"\\/users\",\"doktype\":254,\"TSconfig\":null,\"is_siteroot\":0,\"php_tree_stop\":0,\"url\":\"\",\"shortcut\":0,\"shortcut_mode\":0,\"subtitle\":\"\",\"layout\":0,\"target\":\"\",\"media\":0,\"lastUpdated\":0,\"keywords\":null,\"cache_timeout\":0,\"cache_tags\":\"\",\"newUntil\":0,\"description\":null,\"no_search\":0,\"SYS_LASTCHANGED\":0,\"abstract\":null,\"module\":\"\",\"extendToSubpages\":0,\"author\":\"\",\"author_email\":\"\",\"nav_title\":\"\",\"nav_hide\":0,\"content_from_pid\":0,\"mount_pid\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"fe_login_mode\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":null,\"legacy_overlay_uid\":0,\"tx_impexp_origuid\":0,\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"og_title\":\"\",\"og_description\":null,\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":null,\"twitter_image\":0,\"twitter_card\":\"summary\",\"canonical_link\":\"\",\"sitemap_priority\":\"0.5\",\"sitemap_changefreq\":\"\",\"categories\":0,\"nav_icon_set\":\"\",\"nav_icon_identifier\":\"\",\"nav_icon\":0,\"thumbnail\":0,\"tx_pizpalue_background_image\":0}',0,'0400$5efaeb439569942b9b9bb8727293a9d9:412add0b3eb6ec8f1cb6710aea92e21e'),(22,1647330276,2,'BE',1,0,4,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"a:1:{s:6:\\\"hidden\\\";N;}\"}}',0,'0400$53d4bb0c4660fab86d4f787611d059a5:412add0b3eb6ec8f1cb6710aea92e21e'),(23,1647330293,1,'BE',1,0,1,'fe_groups','{\"uid\":1,\"pid\":4,\"tstamp\":1647330293,\"crdate\":1647330293,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"description\":\"\",\"tx_extbase_type\":\"0\",\"title\":\"Users\",\"lockToDomain\":\"\",\"subgroup\":\"\",\"TSconfig\":\"\",\"felogin_redirectPid\":\"\"}',0,'0400$dab1d46422b39067fdfc7a23b5e2bb92:74fdbe61b0d9932f32a509c1ca766543'),(24,1647330356,1,'BE',1,0,1,'fe_users','{\"uid\":1,\"pid\":4,\"tstamp\":1647330356,\"crdate\":1647330356,\"cruser_id\":1,\"deleted\":0,\"disable\":0,\"starttime\":0,\"endtime\":0,\"description\":\"\",\"tx_extbase_type\":\"0\",\"username\":\"owner\",\"password\":\"$argon2i$v=19$m=65536,t=16,p=1$a2pTUUp5ZkRoOFV2TlkwZg$0BgrijJbQ5VbmWu0EWbEflLZTdoETegRxOkWm1qwlyk\",\"usergroup\":\"1\",\"name\":\"\",\"first_name\":\"First\",\"middle_name\":\"Owner\",\"last_name\":\"\",\"address\":\"\",\"telephone\":\"\",\"fax\":\"\",\"email\":\"first.owner@timelog.ddev.site\",\"lockToDomain\":\"\",\"uc\":null,\"title\":\"\",\"zip\":\"\",\"city\":\"\",\"country\":\"\",\"www\":\"\",\"company\":\"\",\"image\":null,\"TSconfig\":\"\",\"lastlogin\":0,\"is_online\":0,\"felogin_redirectPid\":\"\",\"felogin_forgotHash\":\"\",\"tx_timelog_owner_email\":\"\"}',0,'0400$11c7f99ba03e29db33ec8616e5965620:237e89c1b2a56068427543279fe1982e'),(25,1647330438,1,'BE',1,0,2,'fe_users','{\"uid\":2,\"pid\":4,\"tstamp\":1647330438,\"crdate\":1647330438,\"cruser_id\":1,\"deleted\":0,\"disable\":0,\"starttime\":0,\"endtime\":0,\"description\":\"\",\"tx_extbase_type\":\"0\",\"username\":\"customer\",\"password\":\"$argon2i$v=19$m=65536,t=16,p=1$djJpemlWS2RXdmdwMS9aag$MD\\/CgZLbdkhiYPht2rTkDyjdE9iCHW\\/Fuz+hV9NV7ns\",\"usergroup\":\"1\",\"name\":\"\",\"first_name\":\"First\",\"middle_name\":\"\",\"last_name\":\"Customer\",\"address\":\"\",\"telephone\":\"\",\"fax\":\"\",\"email\":\"first.customer@timelog.ddev.site\",\"lockToDomain\":\"\",\"uc\":null,\"title\":\"\",\"zip\":\"\",\"city\":\"\",\"country\":\"\",\"www\":\"\",\"company\":\"\",\"image\":null,\"TSconfig\":\"\",\"lastlogin\":0,\"is_online\":0,\"felogin_redirectPid\":\"\",\"felogin_forgotHash\":\"\",\"tx_timelog_owner_email\":\"\"}',0,'0400$c2edcd090dc74b5e0f7f6c3ae7c0c96a:3f083a6a2d15ee54bb50505f181f8201'),(26,1647330754,2,'BE',1,0,2,'pages','{\"oldRecord\":{\"TSconfig\":null,\"fe_group\":\"0\",\"l10n_diffsource\":\"a:1:{s:6:\\\"hidden\\\";N;}\"},\"newRecord\":{\"TSconfig\":\"TCEMAIN.preview {\\r\\n    disableButtonForDokType = 255, 199\\r\\n    tx_timelog_domain_model_project {\\r\\n        previewPageId = 3\\r\\n    }\\r\\n    tx_timelog_domain_model_taskgroup {\\r\\n        previewPageId = 3\\r\\n    }\\r\\n    tx_timelog_domain_model_task {\\r\\n        previewPageId = 3\\r\\n    }\\r\\n}\",\"fe_group\":\"\",\"l10n_diffsource\":\"a:54:{s:7:\\\"doktype\\\";N;s:5:\\\"title\\\";N;s:4:\\\"slug\\\";N;s:9:\\\"nav_title\\\";N;s:8:\\\"subtitle\\\";N;s:12:\\\"nav_icon_set\\\";N;s:8:\\\"nav_icon\\\";N;s:9:\\\"seo_title\\\";N;s:11:\\\"description\\\";N;s:8:\\\"no_index\\\";N;s:9:\\\"no_follow\\\";N;s:14:\\\"canonical_link\\\";N;s:18:\\\"sitemap_changefreq\\\";N;s:16:\\\"sitemap_priority\\\";N;s:8:\\\"og_title\\\";N;s:14:\\\"og_description\\\";N;s:8:\\\"og_image\\\";N;s:13:\\\"twitter_title\\\";N;s:19:\\\"twitter_description\\\";N;s:13:\\\"twitter_image\\\";N;s:12:\\\"twitter_card\\\";N;s:8:\\\"abstract\\\";N;s:8:\\\"keywords\\\";N;s:6:\\\"author\\\";N;s:12:\\\"author_email\\\";N;s:11:\\\"lastUpdated\\\";N;s:6:\\\"layout\\\";N;s:8:\\\"newUntil\\\";N;s:14:\\\"backend_layout\\\";N;s:25:\\\"backend_layout_next_level\\\";N;s:28:\\\"tx_pizpalue_background_image\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"content_from_pid\\\";N;s:6:\\\"target\\\";N;s:13:\\\"cache_timeout\\\";N;s:10:\\\"cache_tags\\\";N;s:11:\\\"is_siteroot\\\";N;s:9:\\\"no_search\\\";N;s:13:\\\"php_tree_stop\\\";N;s:6:\\\"module\\\";N;s:5:\\\"media\\\";N;s:17:\\\"tsconfig_includes\\\";N;s:8:\\\"TSconfig\\\";N;s:8:\\\"l18n_cfg\\\";N;s:6:\\\"hidden\\\";N;s:8:\\\"nav_hide\\\";N;s:9:\\\"starttime\\\";N;s:7:\\\"endtime\\\";N;s:16:\\\"extendToSubpages\\\";N;s:8:\\\"fe_group\\\";N;s:13:\\\"fe_login_mode\\\";N;s:8:\\\"editlock\\\";N;s:10:\\\"categories\\\";N;s:14:\\\"rowDescription\\\";N;}\"}}',0,'0400$6af9eb2765a6c185b34b48a6cd957509:f11830df10b4b0bca2db34810c2241b3'),(27,1647330778,2,'BE',1,0,2,'pages','{\"oldRecord\":{\"TSconfig\":\"TCEMAIN.preview {\\r\\n    disableButtonForDokType = 255, 199\\r\\n    tx_timelog_domain_model_project {\\r\\n        previewPageId = 3\\r\\n    }\\r\\n    tx_timelog_domain_model_taskgroup {\\r\\n        previewPageId = 3\\r\\n    }\\r\\n    tx_timelog_domain_model_task {\\r\\n        previewPageId = 3\\r\\n    }\\r\\n}\"},\"newRecord\":{\"TSconfig\":\"TCEMAIN.preview {\\r\\n    disableButtonForDokType = 255, 199\\r\\n    tx_timelog_domain_model_project {\\r\\n        previewPageId = 2\\r\\n    }\\r\\n    tx_timelog_domain_model_taskgroup {\\r\\n        previewPageId = 2\\r\\n    }\\r\\n    tx_timelog_domain_model_task {\\r\\n        previewPageId = 2\\r\\n    }\\r\\n}\"}}',0,'0400$993c713704a44e3742ebe5f511315c65:f11830df10b4b0bca2db34810c2241b3'),(28,1647330904,1,'BE',1,0,1,'tx_timelog_domain_model_project','{\"uid\":1,\"pid\":3,\"tstamp\":1647330904,\"crdate\":1647330904,\"cruser_id\":1,\"deleted\":0,\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"t3ver_count\":0,\"t3ver_tstamp\":0,\"t3ver_move_id\":0,\"handle\":\"\",\"title\":\"First project\",\"description\":\"# Goal\\r\\nThe goel description  The goel description  The goel description  The goel description  The goel description  The goel description  The goel description  The goel description  The goel description  The goel description \\r\\n\\r\\n# References\\r\\n- Repository\",\"internal_note\":\"\",\"active_time\":0,\"heap_time\":0,\"batch_time\":0,\"client\":2,\"owner\":1,\"cc_email\":\"\",\"tasks\":0,\"task_groups\":0}',0,'0400$433f0ab4977f5cb8482b149e44b0392a:f4a1a31fdc9b2106a014c54eae29ec98'),(29,1647331052,1,'BE',1,0,1,'tx_timelog_domain_model_task','{\"uid\":1,\"pid\":3,\"tstamp\":1647331052,\"crdate\":1647331052,\"cruser_id\":1,\"deleted\":0,\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"t3ver_count\":0,\"t3ver_tstamp\":0,\"t3ver_move_id\":0,\"handle\":\"\",\"title\":\"Task 0956\",\"description\":\"# Subgroup\\r\\n- Description goes here\\r\\n- [Description goes here](https:\\/\\/timelog.ddev.site)\\r\\n\\r\\n# Subgroup\\r\\n- Description goes here\\r\\n- Description goes here\",\"active_time\":0,\"batch_date\":0,\"project\":1,\"worker\":0,\"task_group\":0,\"intervals\":0}',0,'0400$2a2bf857c6434c005c04f86ee18d2b74:5b1b8c29cdf8caac2c60e44caac64098'),(30,1647331052,1,'BE',1,0,1,'tx_timelog_domain_model_interval','{\"uid\":1,\"pid\":3,\"tstamp\":1647331052,\"crdate\":1647331052,\"cruser_id\":1,\"deleted\":0,\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"t3ver_count\":0,\"t3ver_tstamp\":0,\"t3ver_move_id\":0,\"task\":0,\"start_time\":1647330956,\"end_time\":0,\"duration\":0}',0,'0400$2a2bf857c6434c005c04f86ee18d2b74:73a56528dec4f7421d2402a3f5e83294'),(31,1647331067,2,'BE',1,0,1,'tx_timelog_domain_model_interval','{\"oldRecord\":{\"end_time\":0},\"newRecord\":{\"end_time\":1647333000}}',0,'0400$53e73748e24df12aabb7af28d0fffe25:73a56528dec4f7421d2402a3f5e83294'),(32,1647337900,1,'BE',1,0,3,'fe_users','{\"uid\":3,\"pid\":4,\"tstamp\":1647337900,\"crdate\":1647337900,\"cruser_id\":1,\"deleted\":0,\"disable\":0,\"starttime\":0,\"endtime\":0,\"description\":\"\",\"tx_extbase_type\":\"0\",\"username\":\"worker\",\"password\":\"$argon2i$v=19$m=65536,t=16,p=1$RUJ5dWh5WGNPVTdHRnAyZw$1J65UZJ1g5hJnka6brQPTlUkBCGpTPf\\/MjPRH0FKFRA\",\"usergroup\":\"1\",\"name\":\"\",\"first_name\":\"First\",\"middle_name\":\"\",\"last_name\":\"Worker\",\"address\":\"\",\"telephone\":\"\",\"fax\":\"\",\"email\":\"first.worker@timelog.ddev.site\",\"lockToDomain\":\"\",\"uc\":null,\"title\":\"\",\"zip\":\"\",\"city\":\"\",\"country\":\"\",\"www\":\"\",\"company\":\"\",\"image\":null,\"TSconfig\":\"\",\"lastlogin\":0,\"is_online\":0,\"felogin_redirectPid\":\"\",\"felogin_forgotHash\":\"\",\"tx_timelog_owner_email\":\"\"}',0,'0400$c11b736483a3e1fc31eabbaf209e1dcd:4f8ae03a7dbbb7f1150f97ab3fdd7687'),(33,1647337939,2,'BE',1,0,1,'tx_timelog_domain_model_task','{\"oldRecord\":{\"worker\":0},\"newRecord\":{\"worker\":\"3\"}}',0,'0400$dea37836448e584c716e68a4c43b4776:5b1b8c29cdf8caac2c60e44caac64098'),(34,1647426367,2,'BE',1,0,1,'tx_timelog_domain_model_project','{\"oldRecord\":{\"tasks\":0},\"newRecord\":{\"tasks\":1}}',0,'0400$b49f80ffef1a064bbb6aec907c5b9c97:f4a1a31fdc9b2106a014c54eae29ec98'),(35,1647426367,1,'BE',1,0,1,'tx_timelog_domain_model_taskgroup','{\"uid\":1,\"pid\":3,\"tstamp\":1647426367,\"crdate\":1647426367,\"cruser_id\":1,\"deleted\":0,\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"t3ver_count\":0,\"t3ver_tstamp\":0,\"t3ver_move_id\":0,\"handle\":\"\",\"title\":\"First task group\",\"description\":\"Description from first task group goes here\",\"internal_note\":\"\",\"time_target\":0,\"time_deviation\":0,\"active_time\":0,\"heap_time\":0,\"batch_time\":0,\"project\":0,\"tasks\":0}',0,'0400$b49f80ffef1a064bbb6aec907c5b9c97:2e5a9a4ea2135b751c6385b1c016a6c5'),(36,1647426367,2,'BE',1,0,1,'tx_timelog_domain_model_project','{\"oldRecord\":{\"tasks\":0},\"newRecord\":{\"tasks\":1}}',0,'0400$b49f80ffef1a064bbb6aec907c5b9c97:f4a1a31fdc9b2106a014c54eae29ec98'),(37,1647427374,2,'BE',1,0,1,'tx_timelog_domain_model_interval','{\"oldRecord\":{\"end_time\":1647333000},\"newRecord\":{\"end_time\":1647419460}}',0,'0400$4c238e853e96c957bd76113906fee65f:73a56528dec4f7421d2402a3f5e83294'),(38,1647433425,2,'BE',1,0,1,'tx_timelog_domain_model_interval','{\"oldRecord\":{\"end_time\":1647419460},\"newRecord\":{\"end_time\":1647333060}}',0,'0400$83fdd992f3a931c2d32d8786aa7962d5:73a56528dec4f7421d2402a3f5e83294'),(39,1647501050,2,'BE',1,0,2,'fe_users','{\"oldRecord\":{\"company\":\"\",\"image\":null},\"newRecord\":{\"company\":\"Customer GmbH\",\"image\":0}}',0,'0400$e301328c5311856f45c65cbca412dc72:3f083a6a2d15ee54bb50505f181f8201'),(40,1647501063,2,'BE',1,0,1,'fe_users','{\"oldRecord\":{\"company\":\"\",\"image\":null},\"newRecord\":{\"company\":\"Owner GmbH\",\"image\":0}}',0,'0400$c4db9ac35fbd3b8533df63f76ae86166:237e89c1b2a56068427543279fe1982e'),(41,1647511198,2,'BE',1,0,2,'pages','{\"oldRecord\":{\"TSconfig\":\"TCEMAIN.preview {\\r\\n    disableButtonForDokType = 255, 199\\r\\n    tx_timelog_domain_model_project {\\r\\n        previewPageId = 2\\r\\n    }\\r\\n    tx_timelog_domain_model_taskgroup {\\r\\n        previewPageId = 2\\r\\n    }\\r\\n    tx_timelog_domain_model_task {\\r\\n        previewPageId = 2\\r\\n    }\\r\\n}\",\"l10n_diffsource\":\"{\\\"doktype\\\":null,\\\"title\\\":null,\\\"slug\\\":null,\\\"nav_title\\\":null,\\\"subtitle\\\":null,\\\"nav_icon_set\\\":null,\\\"nav_icon\\\":null,\\\"seo_title\\\":null,\\\"description\\\":null,\\\"no_index\\\":null,\\\"no_follow\\\":null,\\\"canonical_link\\\":null,\\\"sitemap_changefreq\\\":null,\\\"sitemap_priority\\\":null,\\\"og_title\\\":null,\\\"og_description\\\":null,\\\"og_image\\\":null,\\\"twitter_title\\\":null,\\\"twitter_description\\\":null,\\\"twitter_image\\\":null,\\\"twitter_card\\\":null,\\\"abstract\\\":null,\\\"keywords\\\":null,\\\"author\\\":null,\\\"author_email\\\":null,\\\"lastUpdated\\\":null,\\\"layout\\\":null,\\\"newUntil\\\":null,\\\"backend_layout\\\":null,\\\"backend_layout_next_level\\\":null,\\\"tx_pizpalue_background_image\\\":null,\\\"thumbnail\\\":null,\\\"content_from_pid\\\":null,\\\"target\\\":null,\\\"cache_timeout\\\":null,\\\"cache_tags\\\":null,\\\"is_siteroot\\\":null,\\\"no_search\\\":null,\\\"php_tree_stop\\\":null,\\\"module\\\":null,\\\"media\\\":null,\\\"tsconfig_includes\\\":null,\\\"TSconfig\\\":null,\\\"l18n_cfg\\\":null,\\\"hidden\\\":null,\\\"nav_hide\\\":null,\\\"starttime\\\":null,\\\"endtime\\\":null,\\\"extendToSubpages\\\":null,\\\"fe_group\\\":null,\\\"fe_login_mode\\\":null,\\\"editlock\\\":null,\\\"categories\\\":null,\\\"rowDescription\\\":null}\"},\"newRecord\":{\"TSconfig\":\"TCEMAIN.preview {\\r\\n    tx_timelog_domain_model_project {\\r\\n        disableButtonForDokType = 255, 199\\r\\n        previewPageId = 2\\r\\n    }\\r\\n    tx_timelog_domain_model_taskgroup {\\r\\n        disableButtonForDokType = 255, 199\\r\\n        previewPageId = 2\\r\\n    }\\r\\n    tx_timelog_domain_model_task {\\r\\n        disableButtonForDokType = 255, 199\\r\\n        previewPageId = 2\\r\\n    }\\r\\n}\",\"l10n_diffsource\":\"{\\\"doktype\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"nav_icon_set\\\":\\\"\\\",\\\"nav_icon\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"tx_pizpalue_background_image\\\":\\\"\\\",\\\"thumbnail\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"TSconfig\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"fe_login_mode\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$99c443896fea4d9611f5817272327793:f11830df10b4b0bca2db34810c2241b3'),(42,1647512001,2,'BE',1,0,3,'pages','{\"oldRecord\":{\"TSconfig\":null,\"l10n_diffsource\":\"{\\\"hidden\\\":null}\"},\"newRecord\":{\"TSconfig\":\"TCEMAIN.preview {\\r\\n    tx_timelog_domain_model_project {\\r\\n        disableButtonForDokType = 255, 199\\r\\n        previewPageId = 2\\r\\n    }\\r\\n    tx_timelog_domain_model_taskgroup {\\r\\n        disableButtonForDokType = 255, 199\\r\\n        previewPageId = 2\\r\\n    }\\r\\n    tx_timelog_domain_model_task {\\r\\n        disableButtonForDokType = 255, 199\\r\\n        previewPageId = 2\\r\\n    }\\r\\n}\",\"l10n_diffsource\":\"{\\\"doktype\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"TSconfig\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"tx_pizpalue_background_image\\\":\\\"\\\"}\"}}',0,'0400$541d945a3b862bf19d1cbf67cec9b7d4:fe15eeb7d49e64e2cea91ab53fcf0db1'),(43,1647512027,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"TSconfig\":null,\"l10n_diffsource\":\"{\\\"doktype\\\":null,\\\"title\\\":null,\\\"slug\\\":null,\\\"nav_title\\\":null,\\\"subtitle\\\":null,\\\"nav_icon_set\\\":null,\\\"nav_icon\\\":null,\\\"seo_title\\\":null,\\\"description\\\":null,\\\"no_index\\\":null,\\\"no_follow\\\":null,\\\"canonical_link\\\":null,\\\"sitemap_changefreq\\\":null,\\\"sitemap_priority\\\":null,\\\"og_title\\\":null,\\\"og_description\\\":null,\\\"og_image\\\":null,\\\"twitter_title\\\":null,\\\"twitter_description\\\":null,\\\"twitter_image\\\":null,\\\"twitter_card\\\":null,\\\"abstract\\\":null,\\\"keywords\\\":null,\\\"author\\\":null,\\\"author_email\\\":null,\\\"lastUpdated\\\":null,\\\"layout\\\":null,\\\"newUntil\\\":null,\\\"backend_layout\\\":null,\\\"backend_layout_next_level\\\":null,\\\"tx_pizpalue_background_image\\\":null,\\\"thumbnail\\\":null,\\\"content_from_pid\\\":null,\\\"target\\\":null,\\\"cache_timeout\\\":null,\\\"cache_tags\\\":null,\\\"is_siteroot\\\":null,\\\"no_search\\\":null,\\\"php_tree_stop\\\":null,\\\"module\\\":null,\\\"media\\\":null,\\\"tsconfig_includes\\\":null,\\\"TSconfig\\\":null,\\\"l18n_cfg\\\":null,\\\"hidden\\\":null,\\\"nav_hide\\\":null,\\\"starttime\\\":null,\\\"endtime\\\":null,\\\"extendToSubpages\\\":null,\\\"fe_group\\\":null,\\\"fe_login_mode\\\":null,\\\"editlock\\\":null,\\\"categories\\\":null,\\\"rowDescription\\\":null}\"},\"newRecord\":{\"TSconfig\":\"TCEMAIN.preview {\\r\\n    tx_timelog_domain_model_project {\\r\\n        disableButtonForDokType = 255, 199\\r\\n        previewPageId = 2\\r\\n    }\\r\\n    tx_timelog_domain_model_taskgroup {\\r\\n        disableButtonForDokType = 255, 199\\r\\n        previewPageId = 2\\r\\n    }\\r\\n    tx_timelog_domain_model_task {\\r\\n        disableButtonForDokType = 255, 199\\r\\n        previewPageId = 2\\r\\n    }\\r\\n}\",\"l10n_diffsource\":\"{\\\"doktype\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"nav_icon_set\\\":\\\"\\\",\\\"nav_icon\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"tx_pizpalue_background_image\\\":\\\"\\\",\\\"thumbnail\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"TSconfig\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"fe_login_mode\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$1a885a21c41dbe568a5ebe1095c14577:e175f7045d7ccbfb26ffcf279422c2e5'),(44,1647512065,2,'BE',1,0,3,'pages','{\"oldRecord\":{\"TSconfig\":\"TCEMAIN.preview {\\r\\n    tx_timelog_domain_model_project {\\r\\n        disableButtonForDokType = 255, 199\\r\\n        previewPageId = 2\\r\\n    }\\r\\n    tx_timelog_domain_model_taskgroup {\\r\\n        disableButtonForDokType = 255, 199\\r\\n        previewPageId = 2\\r\\n    }\\r\\n    tx_timelog_domain_model_task {\\r\\n        disableButtonForDokType = 255, 199\\r\\n        previewPageId = 2\\r\\n    }\\r\\n}\"},\"newRecord\":{\"TSconfig\":\"\"}}',0,'0400$62335aea6d533f54b41341fde90f5352:fe15eeb7d49e64e2cea91ab53fcf0db1'),(45,1647512075,2,'BE',1,0,2,'pages','{\"oldRecord\":{\"TSconfig\":\"TCEMAIN.preview {\\r\\n    tx_timelog_domain_model_project {\\r\\n        disableButtonForDokType = 255, 199\\r\\n        previewPageId = 2\\r\\n    }\\r\\n    tx_timelog_domain_model_taskgroup {\\r\\n        disableButtonForDokType = 255, 199\\r\\n        previewPageId = 2\\r\\n    }\\r\\n    tx_timelog_domain_model_task {\\r\\n        disableButtonForDokType = 255, 199\\r\\n        previewPageId = 2\\r\\n    }\\r\\n}\"},\"newRecord\":{\"TSconfig\":\"\"}}',0,'0400$6477ef81afda2af4fd27af0bc4b38e62:f11830df10b4b0bca2db34810c2241b3'),(46,1647607063,1,'BE',1,0,2,'tx_timelog_domain_model_interval','{\"uid\":2,\"pid\":3,\"tstamp\":1647607063,\"crdate\":1647607063,\"cruser_id\":1,\"deleted\":0,\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"task\":1,\"start_time\":1647330956,\"end_time\":1647333060,\"duration\":0.57999999999999996}',0,'0400$9eecc64fa331b2c123b503a346c7726d:a6d90d3a7ca7bae81d59cda3699b4cd6'),(47,1647607063,1,'BE',1,0,2,'tx_timelog_domain_model_task','{\"uid\":2,\"pid\":3,\"tstamp\":1647607063,\"crdate\":1647607063,\"cruser_id\":1,\"deleted\":0,\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"handle\":\"MOJzl56n\",\"title\":\"Task 0956\",\"description\":\"# Subgroup\\r\\n- Description goes here\\r\\n- [Description goes here](https:\\/\\/timelog.ddev.site)\\r\\n\\r\\n# Subgroup\\r\\n- Description goes here\\r\\n- Description goes here\",\"active_time\":0.57999999999999996,\"batch_date\":0,\"project\":1,\"worker\":3,\"task_group\":0,\"intervals\":2}',0,'0400$9eecc64fa331b2c123b503a346c7726d:01835c40b4c33cbb907545b5df8f4806'),(48,1647607063,1,'BE',1,0,2,'tx_timelog_domain_model_taskgroup','{\"uid\":2,\"pid\":3,\"tstamp\":1647607063,\"crdate\":1647607063,\"cruser_id\":1,\"deleted\":0,\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"handle\":\"9d05nZyE\",\"title\":\"First task group\",\"description\":\"Description from first task group goes here\",\"internal_note\":\"\",\"time_target\":0,\"time_deviation\":0,\"active_time\":0,\"heap_time\":0,\"batch_time\":0,\"project\":1,\"tasks\":0}',0,'0400$9eecc64fa331b2c123b503a346c7726d:b74200366405cd81bcfc60f455930d55'),(49,1647607063,1,'BE',1,0,2,'tx_timelog_domain_model_project','{\"uid\":2,\"pid\":3,\"tstamp\":1647607063,\"crdate\":1647607063,\"cruser_id\":1,\"deleted\":0,\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"handle\":\"7wznO6qK\",\"title\":\"First project\",\"description\":\"# Goal\\r\\nThe goel description  The goel description  The goel description  The goel description  The goel description  The goel description  The goel description  The goel description  The goel description  The goel description \\r\\n\\r\\n# References\\r\\n- Repository\",\"internal_note\":\"\",\"active_time\":0.57999999999999996,\"heap_time\":0.57999999999999996,\"batch_time\":0,\"client\":2,\"owner\":1,\"cc_email\":\"\",\"tasks\":0,\"task_groups\":0}',0,'0400$0d31471319fc15a502f202ae9156ba0b:e9eb95d4b222a0d09054aa059b9f9053'),(50,1647607078,2,'BE',1,0,2,'tx_timelog_domain_model_project','{\"oldRecord\":{\"title\":\"First project\"},\"newRecord\":{\"title\":\"Second project\"}}',0,'0400$2ed81f32560caed1c79add369e4b9878:e9eb95d4b222a0d09054aa059b9f9053'),(51,1647607150,2,'BE',1,0,2,'tx_timelog_domain_model_task','{\"oldRecord\":{\"title\":\"Task 0956\"},\"newRecord\":{\"title\":\"Task 2\"}}',0,'0400$d38a42d81f21cde3fc3393fd3fc69cab:01835c40b4c33cbb907545b5df8f4806'),(52,1647607160,2,'BE',1,0,1,'tx_timelog_domain_model_task','{\"oldRecord\":{\"title\":\"Task 0956\"},\"newRecord\":{\"title\":\"Task 1\"}}',0,'0400$72c2010b89578d9e8c3e3ac3a37f5c06:5b1b8c29cdf8caac2c60e44caac64098'),(53,1647607185,2,'BE',1,0,1,'tx_timelog_domain_model_project','{\"oldRecord\":{\"title\":\"First project\"},\"newRecord\":{\"title\":\"Project 1\"}}',0,'0400$3bc3b325c5d10298f87ba89560272ebc:f4a1a31fdc9b2106a014c54eae29ec98'),(54,1647607198,2,'BE',1,0,2,'tx_timelog_domain_model_project','{\"oldRecord\":{\"title\":\"Second project\"},\"newRecord\":{\"title\":\"Project 2\"}}',0,'0400$96d9a5ce6ec081e1d482a2f3727671d2:e9eb95d4b222a0d09054aa059b9f9053'),(55,1647607225,2,'BE',1,0,2,'tx_timelog_domain_model_taskgroup','{\"oldRecord\":{\"title\":\"First task group\",\"time_target\":0},\"newRecord\":{\"title\":\"Task group 2\",\"time_target\":\"0.00\"}}',0,'0400$65b838dd5d4d4da6d72f870dfc125a07:b74200366405cd81bcfc60f455930d55'),(56,1647607236,2,'BE',1,0,1,'tx_timelog_domain_model_taskgroup','{\"oldRecord\":{\"title\":\"First task group\",\"time_target\":0},\"newRecord\":{\"title\":\"Task group 1\",\"time_target\":\"0.00\"}}',0,'0400$d9ca058d2664400a3f222d66ca2ce638:2e5a9a4ea2135b751c6385b1c016a6c5'),(57,1647607336,2,'BE',1,0,2,'tx_timelog_domain_model_interval','{\"oldRecord\":{\"end_time\":1647333060},\"newRecord\":{\"end_time\":1647336660}}',0,'0400$9ff637834442f7276fddd4bc2dca3b12:a6d90d3a7ca7bae81d59cda3699b4cd6'),(58,1647608502,2,'BE',1,0,2,'tx_timelog_domain_model_task','{\"oldRecord\":{\"project\":2},\"newRecord\":{\"project\":\"1\"}}',0,'0400$7cd6328a9333a02615e90a124ce514fc:01835c40b4c33cbb907545b5df8f4806'),(59,1647609762,2,'BE',1,0,2,'tx_timelog_domain_model_task','{\"oldRecord\":{\"project\":1},\"newRecord\":{\"project\":\"2\"}}',0,'0400$e676ca5294f256ac9ca9f2ec478e0fa2:01835c40b4c33cbb907545b5df8f4806'),(60,1647610939,2,'BE',1,0,2,'tx_timelog_domain_model_task','{\"oldRecord\":{\"project\":2},\"newRecord\":{\"project\":\"1\"}}',0,'0400$b69916ce6f7ad697b313e3867ae7a3d2:01835c40b4c33cbb907545b5df8f4806'),(61,1647610996,2,'BE',1,0,2,'tx_timelog_domain_model_task','{\"oldRecord\":{\"project\":1},\"newRecord\":{\"project\":\"2\"}}',0,'0400$9de2283a1b3bfc8fe0aa41d3edd8ed5d:01835c40b4c33cbb907545b5df8f4806'),(62,1647612966,2,'BE',1,0,2,'tx_timelog_domain_model_task','{\"oldRecord\":{\"project\":2},\"newRecord\":{\"project\":\"1\"}}',0,'0400$e45126e371426ff3797a2baa64fd3d82:01835c40b4c33cbb907545b5df8f4806'),(63,1647613723,2,'BE',1,0,2,'tx_timelog_domain_model_task','{\"oldRecord\":{\"project\":1},\"newRecord\":{\"project\":\"2\"}}',0,'0400$18b16470277d7423e2c22fe4175cdd21:01835c40b4c33cbb907545b5df8f4806'),(64,1647842843,2,'BE',1,0,2,'tx_timelog_domain_model_task','{\"oldRecord\":{\"project\":2},\"newRecord\":{\"project\":\"1\"}}',0,'0400$172cfd1a897be5c313e110438a4e869d:01835c40b4c33cbb907545b5df8f4806'),(65,1647849253,2,'BE',1,0,2,'tx_timelog_domain_model_task','{\"oldRecord\":{\"project\":1},\"newRecord\":{\"project\":\"2\"}}',0,'0400$519781fbb1b2f6dbc134ed2c00fd2b96:01835c40b4c33cbb907545b5df8f4806'),(66,1647849484,2,'BE',1,0,2,'tx_timelog_domain_model_task','{\"oldRecord\":{\"project\":2},\"newRecord\":{\"project\":\"1\"}}',0,'0400$701e9e901dc55c6cfcdecb0fb576681a:01835c40b4c33cbb907545b5df8f4806'),(67,1647850207,2,'BE',1,0,2,'tx_timelog_domain_model_task','{\"oldRecord\":{\"project\":1},\"newRecord\":{\"project\":\"2\"}}',0,'0400$4ad8c0fbad629fa6bdeabb37cc37a957:01835c40b4c33cbb907545b5df8f4806'),(68,1647878211,2,'BE',1,0,2,'tx_timelog_domain_model_task','{\"oldRecord\":{\"project\":2},\"newRecord\":{\"project\":\"1\"}}',0,'0400$7dca19bc1335f5d0262a359cee96ad26:01835c40b4c33cbb907545b5df8f4806'),(69,1647878283,2,'BE',1,0,2,'tx_timelog_domain_model_task','{\"oldRecord\":{\"project\":1},\"newRecord\":{\"project\":0}}',0,'0400$c6e8df98b7dc9f8f25200530e3eb2525:01835c40b4c33cbb907545b5df8f4806'),(70,1647878585,2,'BE',1,0,2,'tx_timelog_domain_model_task','{\"oldRecord\":{\"project\":0},\"newRecord\":{\"project\":\"1\"}}',0,'0400$c43b10413b15ec5c60cc2b3765440781:01835c40b4c33cbb907545b5df8f4806'),(71,1647878604,2,'BE',1,0,2,'tx_timelog_domain_model_task','{\"oldRecord\":{\"project\":1},\"newRecord\":{\"project\":\"2\"}}',0,'0400$1714f3f1c54095924f5499afbef9a91b:01835c40b4c33cbb907545b5df8f4806'),(72,1647878623,2,'BE',1,0,2,'tx_timelog_domain_model_task','{\"oldRecord\":{\"project\":2},\"newRecord\":{\"project\":\"1\"}}',0,'0400$3d5e5c810c8be3debe13ce7c4ff1c51e:01835c40b4c33cbb907545b5df8f4806'),(73,1647878654,2,'BE',1,0,1,'tx_timelog_domain_model_task','{\"oldRecord\":{\"project\":1},\"newRecord\":{\"project\":\"2\"}}',0,'0400$c9430e57542c519ef46f3c7c265feba6:5b1b8c29cdf8caac2c60e44caac64098'),(74,1647879518,2,'BE',1,0,1,'tx_timelog_domain_model_task','{\"oldRecord\":{\"project\":2},\"newRecord\":{\"project\":\"1\"}}',0,'0400$be7ad883edcd91267fa8563e01904c2c:5b1b8c29cdf8caac2c60e44caac64098'),(75,1647879544,2,'BE',1,0,2,'tx_timelog_domain_model_task','{\"oldRecord\":{\"project\":1},\"newRecord\":{\"project\":\"2\"}}',0,'0400$d2a175517161c033c55a5e3cee672a63:01835c40b4c33cbb907545b5df8f4806'),(76,1647879557,2,'BE',1,0,2,'tx_timelog_domain_model_task','{\"oldRecord\":{\"project\":2},\"newRecord\":{\"project\":\"1\"}}',0,'0400$dea7ceff5300a74acb182e68fb0f2967:01835c40b4c33cbb907545b5df8f4806'),(77,1647879594,2,'BE',1,0,1,'tx_timelog_domain_model_task','{\"oldRecord\":{\"project\":1},\"newRecord\":{\"project\":\"2\"}}',0,'0400$c6f35173e1ca5e9e763276d4dc8038c1:5b1b8c29cdf8caac2c60e44caac64098'),(78,1647930201,2,'BE',1,0,2,'tx_timelog_domain_model_task','{\"oldRecord\":{\"project\":null},\"newRecord\":{\"project\":\"1\"}}',0,'0400$70d360eb012591dd1a54b3c6e041b47a:01835c40b4c33cbb907545b5df8f4806'),(79,1647936286,1,'BE',1,0,3,'tx_timelog_domain_model_task','{\"uid\":3,\"pid\":3,\"tstamp\":1647936286,\"crdate\":1647936286,\"cruser_id\":1,\"deleted\":0,\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"handle\":\"\",\"title\":\"Task 3\",\"description\":\"\",\"active_time\":0,\"batch_date\":0,\"project\":0,\"worker\":3,\"task_group\":0,\"intervals\":0}',0,'0400$65c9eac9a909af7698d82c7c511eb9e3:fbcf4d73a416dfc0842ed6e373625608'),(80,1647936286,1,'BE',1,0,3,'tx_timelog_domain_model_interval','{\"uid\":3,\"pid\":3,\"tstamp\":1647936286,\"crdate\":1647936286,\"cruser_id\":1,\"deleted\":0,\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"task\":0,\"start_time\":1647936228,\"end_time\":0,\"duration\":0}',0,'0400$65c9eac9a909af7698d82c7c511eb9e3:69ad0557d73551b7c10ca4c3715b2c74'),(81,1647936632,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"project\":0,\"description\":\"\"},\"newRecord\":{\"project\":\"2\",\"description\":\"hoi!\"}}',0,'0400$0f3125cfee8f764dcba2b64c1817de46:fbcf4d73a416dfc0842ed6e373625608'),(82,1647936632,2,'BE',1,0,3,'tx_timelog_domain_model_interval','{\"oldRecord\":{\"start_time\":1647936228,\"end_time\":0},\"newRecord\":{\"start_time\":1647932580,\"end_time\":1647936900}}',0,'0400$0f3125cfee8f764dcba2b64c1817de46:69ad0557d73551b7c10ca4c3715b2c74'),(83,1647936712,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"description\":\"hoi!\"},\"newRecord\":{\"description\":\"\"}}',0,'0400$196373f0755f0cf256bc2a010d57140c:fbcf4d73a416dfc0842ed6e373625608'),(84,1647936768,2,'BE',1,0,3,'tx_timelog_domain_model_interval','{\"oldRecord\":{\"end_time\":1647936900},\"newRecord\":{\"end_time\":\"0\"}}',0,'0400$270e71c129ad6b5e2417f5c1d0acc741:69ad0557d73551b7c10ca4c3715b2c74'),(85,1647936832,2,'BE',1,0,3,'tx_timelog_domain_model_interval','{\"oldRecord\":{\"end_time\":0},\"newRecord\":{\"end_time\":1647940380}}',0,'0400$92791e4f04a78897d15de195c1f0e45b:69ad0557d73551b7c10ca4c3715b2c74'),(86,1647936890,2,'BE',1,0,3,'tx_timelog_domain_model_interval','{\"oldRecord\":{\"start_time\":1647932580,\"end_time\":1647940380},\"newRecord\":{\"start_time\":1647936180,\"end_time\":1647941400}}',0,'0400$0d90702cbc0f636f17b025af9b0ac808:69ad0557d73551b7c10ca4c3715b2c74'),(87,1647937556,2,'BE',1,0,3,'tx_timelog_domain_model_interval','{\"oldRecord\":{\"start_time\":1647936180},\"newRecord\":{\"start_time\":1647936000}}',0,'0400$0c3be3b7adb910bcb0e51cae39ac9a40:69ad0557d73551b7c10ca4c3715b2c74'),(88,1647937576,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"project\":2},\"newRecord\":{\"project\":0}}',0,'0400$a3e10e52a2591b96f9bb38decb8261f9:fbcf4d73a416dfc0842ed6e373625608'),(89,1647937587,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"project\":0},\"newRecord\":{\"project\":\"1\"}}',0,'0400$956a7d298a8be748b91b1c9ffff15a47:fbcf4d73a416dfc0842ed6e373625608'),(90,1647937673,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"task_group\":0,\"description\":\"\"},\"newRecord\":{\"task_group\":\"1\",\"description\":\"# Subgroup\\r\\n- Description goes here\\r\\n- [Description goes here](https:\\/\\/timelog.ddev.site)\\r\\n\\r\\n# Subgroup\\r\\n- Description goes here\\r\\n- Description goes here\"}}',0,'0400$2248fc088d7b7c31b53180dc79bed156:fbcf4d73a416dfc0842ed6e373625608'),(91,1647937735,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"task_group\":1},\"newRecord\":{\"task_group\":0}}',0,'0400$e842f5d6a0e5d4ea06edf06a519f5308:fbcf4d73a416dfc0842ed6e373625608'),(92,1647937863,2,'BE',1,0,3,'tx_timelog_domain_model_interval','{\"oldRecord\":{\"end_time\":1647941400},\"newRecord\":{\"end_time\":1647937800}}',0,'0400$f97c806b2a4b403ec0d66180e42fb0e6:69ad0557d73551b7c10ca4c3715b2c74'),(93,1647937879,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"project\":1},\"newRecord\":{\"project\":0}}',0,'0400$2b8c1721e0901d78c2d951047b61b181:fbcf4d73a416dfc0842ed6e373625608'),(94,1647937886,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"project\":0},\"newRecord\":{\"project\":\"2\"}}',0,'0400$ade9dd76f2e119bab23e69b674ba2bc2:fbcf4d73a416dfc0842ed6e373625608'),(95,1647937896,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"project\":2},\"newRecord\":{\"project\":\"1\"}}',0,'0400$3004f953716e46afef5181a8b48e154c:fbcf4d73a416dfc0842ed6e373625608'),(96,1647937940,1,'BE',1,0,4,'tx_timelog_domain_model_interval','{\"uid\":4,\"pid\":3,\"tstamp\":1647937940,\"crdate\":1647937940,\"cruser_id\":1,\"deleted\":0,\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"task\":0,\"start_time\":1647937917,\"end_time\":1647938700,\"duration\":0}',0,'0400$656fb54328decfc3675157d046d86563:8ac2219f4a493773db368435c7706f7c'),(97,1647938599,2,'BE',1,0,4,'tx_timelog_domain_model_interval','{\"oldRecord\":{\"end_time\":1647938700},\"newRecord\":{\"end_time\":1647942300}}',0,'0400$75e31e2f1819b3b36389c4608e69aaec:8ac2219f4a493773db368435c7706f7c'),(98,1647938652,2,'BE',1,0,4,'tx_timelog_domain_model_interval','{\"oldRecord\":{\"end_time\":1647942300},\"newRecord\":{\"end_time\":1647945900}}',0,'0400$81071425bc2ec0662d59d3bd3b28dd77:8ac2219f4a493773db368435c7706f7c'),(99,1647938889,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"project\":1},\"newRecord\":{\"project\":\"2\"}}',0,'0400$b9dbe9bcbb49b0dd7452f49af5c191e8:fbcf4d73a416dfc0842ed6e373625608'),(100,1647938889,2,'BE',1,0,4,'tx_timelog_domain_model_interval','{\"oldRecord\":{\"end_time\":1647945900},\"newRecord\":{\"end_time\":1647938700}}',0,'0400$b9dbe9bcbb49b0dd7452f49af5c191e8:8ac2219f4a493773db368435c7706f7c'),(101,1647939093,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"project\":2},\"newRecord\":{\"project\":0}}',0,'0400$379451e9ce3d7c6aeaaf42565e467efc:fbcf4d73a416dfc0842ed6e373625608'),(102,1647939122,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"project\":0},\"newRecord\":{\"project\":\"1\"}}',0,'0400$86fc6a9993dbfb9940504af2f73dca1b:fbcf4d73a416dfc0842ed6e373625608'),(103,1647939127,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"task_group\":0},\"newRecord\":{\"task_group\":\"1\"}}',0,'0400$d52dfbe1ff1332e3969826820e72858a:fbcf4d73a416dfc0842ed6e373625608'),(104,1647939149,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"project\":1},\"newRecord\":{\"project\":0}}',0,'0400$112a0903c4aa3dd87518987572f90652:fbcf4d73a416dfc0842ed6e373625608'),(105,1647939167,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"task_group\":1},\"newRecord\":{\"task_group\":0}}',0,'0400$e3672678b760ff26dfaaaee2821e9ef9:fbcf4d73a416dfc0842ed6e373625608'),(106,1647939736,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"project\":0},\"newRecord\":{\"project\":\"1\"}}',0,'0400$00a02c16e4e13a110ebd3f369d68ebc9:fbcf4d73a416dfc0842ed6e373625608'),(107,1647939796,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"task_group\":0},\"newRecord\":{\"task_group\":\"1\"}}',0,'0400$992436ba99febb3b156e7b3ccae16dae:fbcf4d73a416dfc0842ed6e373625608'),(108,1647939810,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"project\":1},\"newRecord\":{\"project\":0}}',0,'0400$a128b24ab0467db6225d2e9542ce5cf1:fbcf4d73a416dfc0842ed6e373625608'),(109,1647940215,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"project\":0,\"task_group\":1},\"newRecord\":{\"project\":\"1\",\"task_group\":0}}',0,'0400$046ed4cc03958de7f36e84617cf26545:fbcf4d73a416dfc0842ed6e373625608'),(110,1647940224,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"task_group\":0},\"newRecord\":{\"task_group\":\"1\"}}',0,'0400$541179cf86e3b5bfba54d614d0912719:fbcf4d73a416dfc0842ed6e373625608'),(111,1647940233,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"project\":1,\"task_group\":1},\"newRecord\":{\"project\":0,\"task_group\":0}}',0,'0400$e54e3860c378bc317f09fbb35815b092:fbcf4d73a416dfc0842ed6e373625608'),(112,1647940394,2,'BE',1,0,4,'tx_timelog_domain_model_interval','{\"oldRecord\":{\"end_time\":1647938700},\"newRecord\":{\"end_time\":1647942300}}',0,'0400$97316908ebf0f99d5ed90e12a75cd3c7:8ac2219f4a493773db368435c7706f7c'),(113,1647940403,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"project\":0},\"newRecord\":{\"project\":\"1\"}}',0,'0400$5cfc1cc315c94be9dcc619bbbc675bf4:fbcf4d73a416dfc0842ed6e373625608'),(114,1647940412,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"project\":1},\"newRecord\":{\"project\":\"2\"}}',0,'0400$c28d607ba9c381d43206fac28869643e:fbcf4d73a416dfc0842ed6e373625608'),(115,1647940421,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"task_group\":0},\"newRecord\":{\"task_group\":\"2\"}}',0,'0400$1d32f15adae6410d7b2494175d859abb:fbcf4d73a416dfc0842ed6e373625608'),(116,1647940428,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"project\":2,\"task_group\":2},\"newRecord\":{\"project\":0,\"task_group\":0}}',0,'0400$07a92cdbab9b2e94744da5bedd54bf70:fbcf4d73a416dfc0842ed6e373625608'),(117,1647940440,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"project\":0},\"newRecord\":{\"project\":\"2\"}}',0,'0400$6f0ce2d7a044390bcfc12a369bfbb3f0:fbcf4d73a416dfc0842ed6e373625608'),(118,1647940443,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"task_group\":0},\"newRecord\":{\"task_group\":\"2\"}}',0,'0400$6a50e2e2e2c517f4c7ab3a9585a8bea8:fbcf4d73a416dfc0842ed6e373625608'),(119,1647940469,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"task_group\":2},\"newRecord\":{\"task_group\":0}}',0,'0400$cd872cd43bece44da778ca83e5d9558d:fbcf4d73a416dfc0842ed6e373625608'),(120,1647942559,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"task_group\":0},\"newRecord\":{\"task_group\":\"2\"}}',0,'0400$730f049d8bc98bcc7730b96277b18bc9:fbcf4d73a416dfc0842ed6e373625608'),(121,1647942679,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"task_group\":2},\"newRecord\":{\"task_group\":0}}',0,'0400$a3e3ed321715a6f58ec5d8c1a8a43201:fbcf4d73a416dfc0842ed6e373625608'),(122,1647942891,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"task_group\":0},\"newRecord\":{\"task_group\":\"2\"}}',0,'0400$7c7cd78814d05aec02a9c332c254b19e:fbcf4d73a416dfc0842ed6e373625608'),(123,1647942912,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"task_group\":2},\"newRecord\":{\"task_group\":0}}',0,'0400$0a37b091aca3036f592994fc10420214:fbcf4d73a416dfc0842ed6e373625608'),(124,1647943028,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"task_group\":0},\"newRecord\":{\"task_group\":\"2\"}}',0,'0400$5cdb135d1052140fd3d6cc4546ac80af:fbcf4d73a416dfc0842ed6e373625608'),(125,1647943077,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"task_group\":2},\"newRecord\":{\"task_group\":0}}',0,'0400$4840fee73ac23419622a58ecf4689418:fbcf4d73a416dfc0842ed6e373625608'),(126,1647943162,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"task_group\":0},\"newRecord\":{\"task_group\":\"2\"}}',0,'0400$3cd27fa7fed993f67e2a1e00f8927b34:fbcf4d73a416dfc0842ed6e373625608'),(127,1647943225,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"task_group\":2},\"newRecord\":{\"task_group\":0}}',0,'0400$511fbe83626fafc27ed4f7f5dcc2f07a:fbcf4d73a416dfc0842ed6e373625608'),(128,1647943365,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"task_group\":0},\"newRecord\":{\"task_group\":\"2\"}}',0,'0400$bd00e1faedb3071edec714e2840e7622:fbcf4d73a416dfc0842ed6e373625608'),(129,1647943527,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"task_group\":2},\"newRecord\":{\"task_group\":0}}',0,'0400$69c016889f6822fc069768bc3685d0fb:fbcf4d73a416dfc0842ed6e373625608'),(130,1647943568,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"task_group\":0},\"newRecord\":{\"task_group\":\"2\"}}',0,'0400$85b225f7548605dc2fc094103b11edb2:fbcf4d73a416dfc0842ed6e373625608'),(131,1647943574,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"task_group\":2},\"newRecord\":{\"task_group\":0}}',0,'0400$37dcc22b2e5b5d49d69baa3c421d0015:fbcf4d73a416dfc0842ed6e373625608'),(132,1647943703,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"task_group\":0},\"newRecord\":{\"task_group\":\"2\"}}',0,'0400$6dbed36c881086404d7c79b36c4122c5:fbcf4d73a416dfc0842ed6e373625608'),(133,1647943710,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"task_group\":2},\"newRecord\":{\"task_group\":0}}',0,'0400$9db8ae0b6d9fb5a22039d6710675bcee:fbcf4d73a416dfc0842ed6e373625608'),(134,1647943772,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"task_group\":0},\"newRecord\":{\"task_group\":\"2\"}}',0,'0400$03ec0f3aa80fffdc3033f1edc4ba5008:fbcf4d73a416dfc0842ed6e373625608'),(135,1647943828,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"task_group\":2},\"newRecord\":{\"task_group\":0}}',0,'0400$989e8a682534d978a06a1df6eaa69483:fbcf4d73a416dfc0842ed6e373625608'),(136,1647943832,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"task_group\":0},\"newRecord\":{\"task_group\":\"2\"}}',0,'0400$339a923313c1cd39c68d394bc9b4140c:fbcf4d73a416dfc0842ed6e373625608'),(137,1647943914,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"task_group\":2},\"newRecord\":{\"task_group\":0}}',0,'0400$cea3f42b8a8ded6c217274307c5b87fe:fbcf4d73a416dfc0842ed6e373625608'),(138,1647943919,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"task_group\":0},\"newRecord\":{\"task_group\":\"2\"}}',0,'0400$399677e9a0bd6e790bbbd84d623f83fc:fbcf4d73a416dfc0842ed6e373625608'),(139,1647943977,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"task_group\":2},\"newRecord\":{\"task_group\":0}}',0,'0400$bca1c39dd0cb78cc5da973325d9e6c60:fbcf4d73a416dfc0842ed6e373625608'),(140,1647943981,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"task_group\":0},\"newRecord\":{\"task_group\":\"2\"}}',0,'0400$3772585da5adf8efc51a065a8a19200e:fbcf4d73a416dfc0842ed6e373625608'),(141,1647944173,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"task_group\":2},\"newRecord\":{\"task_group\":0}}',0,'0400$2badaca8f2b80c2d78f047dd65bca0df:fbcf4d73a416dfc0842ed6e373625608'),(142,1647944179,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"task_group\":0},\"newRecord\":{\"task_group\":\"2\"}}',0,'0400$c2ba1f80b716821a6d1f28219fd69722:fbcf4d73a416dfc0842ed6e373625608'),(143,1647944186,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"project\":2,\"task_group\":2},\"newRecord\":{\"project\":0,\"task_group\":0}}',0,'0400$953dfc338aa5def7205f2ce799ef8974:fbcf4d73a416dfc0842ed6e373625608'),(144,1647944210,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"project\":0},\"newRecord\":{\"project\":\"1\"}}',0,'0400$372b7a539b4856b5894127aaecc02b3d:fbcf4d73a416dfc0842ed6e373625608'),(145,1647944234,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"intervals\":2},\"newRecord\":{\"intervals\":1}}',0,'0400$992c53485673de8957738d37f4a2a373:fbcf4d73a416dfc0842ed6e373625608'),(146,1647944234,4,'BE',1,0,4,'tx_timelog_domain_model_interval',NULL,0,'0400$992c53485673de8957738d37f4a2a373:8ac2219f4a493773db368435c7706f7c'),(147,1647944485,1,'BE',1,0,5,'tx_timelog_domain_model_interval','{\"uid\":5,\"pid\":3,\"tstamp\":1647944485,\"crdate\":1647944485,\"cruser_id\":1,\"deleted\":0,\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"task\":0,\"start_time\":1647944468,\"end_time\":0,\"duration\":0}',0,'0400$f34276a40b9bb977350c55ea51fd3148:d095ad81b4dfff5fe3936b06910acb6f'),(148,1647945101,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"intervals\":2},\"newRecord\":{\"intervals\":1}}',0,'0400$af293b4a5ccaf2e7cc5776619f3be7d7:fbcf4d73a416dfc0842ed6e373625608'),(149,1647945101,4,'BE',1,0,5,'tx_timelog_domain_model_interval',NULL,0,'0400$af293b4a5ccaf2e7cc5776619f3be7d7:d095ad81b4dfff5fe3936b06910acb6f'),(150,1647945135,1,'BE',1,0,6,'tx_timelog_domain_model_interval','{\"uid\":6,\"pid\":3,\"tstamp\":1647945135,\"crdate\":1647945135,\"cruser_id\":1,\"deleted\":0,\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"task\":0,\"start_time\":1647941460,\"end_time\":0,\"duration\":0}',0,'0400$dd5e56c72d4a70683e2d32e3248c8551:6b1ef2532d2f115b55f064b5fa9772ee'),(151,1647946099,2,'BE',1,0,3,'tx_timelog_domain_model_task','{\"oldRecord\":{\"intervals\":2},\"newRecord\":{\"intervals\":1}}',0,'0400$67f94147f380a394d921bd53150808c9:fbcf4d73a416dfc0842ed6e373625608'),(152,1647946099,4,'BE',1,0,6,'tx_timelog_domain_model_interval',NULL,0,'0400$67f94147f380a394d921bd53150808c9:6b1ef2532d2f115b55f064b5fa9772ee'),(153,1647946121,1,'BE',1,0,7,'tx_timelog_domain_model_interval','{\"uid\":7,\"pid\":3,\"tstamp\":1647946121,\"crdate\":1647946121,\"cruser_id\":1,\"deleted\":0,\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"task\":0,\"start_time\":1647942480,\"end_time\":0,\"duration\":0}',0,'0400$c94e05c6384d2351049decc17514231d:87a6bcb164c2a7c9557413135579d613'),(154,1647946137,2,'BE',1,0,7,'tx_timelog_domain_model_interval','{\"oldRecord\":{\"end_time\":0},\"newRecord\":{\"end_time\":1648033200}}',0,'0400$6fcd38b0226174592923b9799870dd24:87a6bcb164c2a7c9557413135579d613'),(155,1647946155,2,'BE',1,0,7,'tx_timelog_domain_model_interval','{\"oldRecord\":{\"end_time\":1648033200},\"newRecord\":{\"end_time\":1647946800}}',0,'0400$acbcb0ce2e491b44aa52feceb4c815ce:87a6bcb164c2a7c9557413135579d613'),(156,1647946250,1,'BE',1,0,8,'tx_timelog_domain_model_interval','{\"uid\":8,\"pid\":3,\"tstamp\":1647946250,\"crdate\":1647946250,\"cruser_id\":1,\"deleted\":0,\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"task\":0,\"start_time\":1647939000,\"end_time\":0,\"duration\":0}',0,'0400$2440af89be77520ade2e88c080bc4e6a:d46c3dc6476ec39e153db11b0ef246e9'),(157,1647946250,4,'BE',1,0,7,'tx_timelog_domain_model_interval',NULL,0,'0400$2440af89be77520ade2e88c080bc4e6a:87a6bcb164c2a7c9557413135579d613'),(158,1647946271,2,'BE',1,0,8,'tx_timelog_domain_model_interval','{\"oldRecord\":{\"end_time\":0},\"newRecord\":{\"end_time\":1647946800}}',0,'0400$4605234e90dd53479f2a1b2777270a59:d46c3dc6476ec39e153db11b0ef246e9'),(159,1647946290,2,'BE',1,0,8,'tx_timelog_domain_model_interval','{\"oldRecord\":{\"end_time\":1647946800},\"newRecord\":{\"end_time\":\"0\"}}',0,'0400$eaf184c9a8679dd9c974d1bcb70d0a5a:d46c3dc6476ec39e153db11b0ef246e9'),(160,1647946299,2,'BE',1,0,8,'tx_timelog_domain_model_interval','{\"oldRecord\":{\"end_time\":0},\"newRecord\":{\"end_time\":1647946800}}',0,'0400$794c8490f2a5fdb1e795d7f62de6e2d6:d46c3dc6476ec39e153db11b0ef246e9'),(161,1647946306,2,'BE',1,0,8,'tx_timelog_domain_model_interval','{\"oldRecord\":{\"end_time\":1647946800},\"newRecord\":{\"end_time\":\"0\"}}',0,'0400$0839e0f10cecdd8d38f9b11c1577a341:d46c3dc6476ec39e153db11b0ef246e9'),(162,1647946323,2,'BE',1,0,8,'tx_timelog_domain_model_interval','{\"oldRecord\":{\"end_time\":0},\"newRecord\":{\"end_time\":1647943200}}',0,'0400$67f93f2cc20d0aaefd952b88e40377cc:d46c3dc6476ec39e153db11b0ef246e9'),(163,1647946332,2,'BE',1,0,8,'tx_timelog_domain_model_interval','{\"oldRecord\":{\"end_time\":1647943200},\"newRecord\":{\"end_time\":\"0\"}}',0,'0400$268853b2253d00a1e0f43b43c9de5bfb:d46c3dc6476ec39e153db11b0ef246e9'),(164,1647946518,2,'BE',1,0,8,'tx_timelog_domain_model_interval','{\"oldRecord\":{\"end_time\":0},\"newRecord\":{\"end_time\":1647946800}}',0,'0400$be94a4eff2866645d320d29fc87bf80a:d46c3dc6476ec39e153db11b0ef246e9'),(165,1647946529,2,'BE',1,0,8,'tx_timelog_domain_model_interval','{\"oldRecord\":{\"end_time\":1647946800},\"newRecord\":{\"end_time\":\"0\"}}',0,'0400$7c363e9f1db623d6197a5a0dff7c87d9:d46c3dc6476ec39e153db11b0ef246e9'),(166,1647951456,2,'BE',1,0,8,'tx_timelog_domain_model_interval','{\"oldRecord\":{\"end_time\":0},\"newRecord\":{\"end_time\":1647946800}}',0,'0400$99ce99009bc65fe651598054a72abe12:d46c3dc6476ec39e153db11b0ef246e9');
/*!40000 ALTER TABLE `sys_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_language`
--

DROP TABLE IF EXISTS `sys_language`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_language` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `title` varchar(80) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `flag` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `language_isocode` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `nav_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `locale` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `hreflang` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `direction` varchar(3) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_language`
--

LOCK TABLES `sys_language` WRITE;
/*!40000 ALTER TABLE `sys_language` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_language` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_lockedrecords`
--

DROP TABLE IF EXISTS `sys_lockedrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_lockedrecords` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `record_table` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `record_uid` int(11) NOT NULL DEFAULT 0,
  `record_pid` int(11) NOT NULL DEFAULT 0,
  `username` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `feuserid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=304 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_lockedrecords`
--

LOCK TABLES `sys_lockedrecords` WRITE;
/*!40000 ALTER TABLE `sys_lockedrecords` DISABLE KEYS */;
INSERT INTO `sys_lockedrecords` VALUES (303,1,1647951456,'tx_timelog_domain_model_task',3,0,'admin',0);
/*!40000 ALTER TABLE `sys_lockedrecords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_news`
--

DROP TABLE IF EXISTS `sys_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_news` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `content` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_news`
--

LOCK TABLES `sys_news` WRITE;
/*!40000 ALTER TABLE `sys_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_note`
--

DROP TABLE IF EXISTS `sys_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_note` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `subject` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `message` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `personal` smallint(5) unsigned NOT NULL DEFAULT 0,
  `category` smallint(5) unsigned NOT NULL DEFAULT 0,
  `position` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_note`
--

LOCK TABLES `sys_note` WRITE;
/*!40000 ALTER TABLE `sys_note` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_refindex`
--

DROP TABLE IF EXISTS `sys_refindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_refindex` (
  `hash` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tablename` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `recuid` int(11) NOT NULL DEFAULT 0,
  `field` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `flexpointer` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `softref_key` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `softref_id` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `ref_table` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ref_uid` int(11) NOT NULL DEFAULT 0,
  `ref_string` varchar(1024) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`hash`),
  KEY `lookup_rec` (`tablename`(100),`recuid`),
  KEY `lookup_uid` (`ref_table`(100),`ref_uid`),
  KEY `lookup_string` (`ref_string`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_refindex`
--

LOCK TABLES `sys_refindex` WRITE;
/*!40000 ALTER TABLE `sys_refindex` DISABLE KEYS */;
INSERT INTO `sys_refindex` VALUES ('0229dd0c0678bc7b4f5c664836a93d9f','tx_timelog_domain_model_task',3,'intervals','','','',1,0,'tx_timelog_domain_model_interval',3,''),('214f2f5e77b7520be4b62787a93a5131','fe_users',3,'usergroup','','','',0,0,'fe_groups',1,''),('231c6a5f7fe66cb7ce11bbfa74345c2f','tx_timelog_domain_model_task',1,'project','','','',0,0,'tx_timelog_domain_model_project',2,''),('23f53d3f4875a4680e7dcf86f6d38e70','tx_timelog_domain_model_task',3,'worker','','','',0,0,'fe_users',3,''),('25ff69f2c42145e28c5f74737e9bd4d8','tx_timelog_domain_model_task',1,'intervals','','','',0,0,'tx_timelog_domain_model_interval',1,''),('29ddc3f9171ee9bd001eb176fd1fe4c0','tx_timelog_domain_model_project',1,'client','','','',0,0,'fe_users',2,''),('2b106a0c8f991874510284fae35322d6','tx_timelog_domain_model_taskgroup',2,'project','','','',0,0,'tx_timelog_domain_model_project',2,''),('3e70bf4111a32ef4af9ab7247e7ce9b9','tx_timelog_domain_model_taskgroup',1,'project','','','',0,0,'tx_timelog_domain_model_project',1,''),('437d7241df7c1e4fe01e971d14d2ff7e','tx_timelog_domain_model_project',1,'owner','','','',0,0,'fe_users',1,''),('48a5daa046d3b296a763699e0deb44b8','tx_timelog_domain_model_project',1,'task_groups','','','',0,0,'tx_timelog_domain_model_taskgroup',1,''),('5ba53971a70d4961b2df093377c9459a','tx_timelog_domain_model_task',1,'worker','','','',0,0,'fe_users',3,''),('5e3bd5552eb0484df8384cd081578695','tx_timelog_domain_model_project',2,'tasks','','','',0,0,'tx_timelog_domain_model_task',2,''),('65f0fc6185baf1dde0030141106d1dd9','tx_timelog_domain_model_project',2,'owner','','','',0,0,'fe_users',1,''),('7c4bf64f123787c014651d0c9a46d916','tx_timelog_domain_model_task',3,'intervals','','','',0,0,'tx_timelog_domain_model_interval',8,''),('801b83db2a5c1e82e85daec5503f7553','fe_users',2,'usergroup','','','',0,0,'fe_groups',1,''),('8ba01abd3ce16dc75b77e3c3906d7713','fe_users',1,'usergroup','','','',0,0,'fe_groups',1,''),('96213cfc8e26b776265498db8bfa7ebf','tx_timelog_domain_model_project',2,'task_groups','','','',0,0,'tx_timelog_domain_model_taskgroup',2,''),('b798db9c0fd462710b23c32eece73973','tx_timelog_domain_model_task',2,'worker','','','',0,0,'fe_users',3,''),('b9818a96f8f4dac00243413cf6f38ef1','tx_timelog_domain_model_project',2,'client','','','',0,0,'fe_users',2,''),('d99e7d7f78b00f442fc431e95c280d36','tx_timelog_domain_model_project',1,'tasks','','','',0,0,'tx_timelog_domain_model_task',1,''),('dedf253146734b71e4d362477f5ddc06','tx_timelog_domain_model_task',3,'project','','','',0,0,'tx_timelog_domain_model_project',1,''),('eacce6bc3ede29d1cbcb36c0689367d6','tx_timelog_domain_model_task',2,'project','','','',0,0,'tx_timelog_domain_model_project',1,''),('f4bf256749e0b76f68400b815062747a','tx_timelog_domain_model_task',2,'intervals','','','',0,0,'tx_timelog_domain_model_interval',2,'');
/*!40000 ALTER TABLE `sys_refindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_registry`
--

DROP TABLE IF EXISTS `sys_registry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_registry` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_namespace` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_key` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_value` mediumblob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `entry_identifier` (`entry_namespace`,`entry_key`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_registry`
--

LOCK TABLES `sys_registry` WRITE;
/*!40000 ALTER TABLE `sys_registry` DISABLE KEYS */;
INSERT INTO `sys_registry` VALUES (1,'installUpdate','TYPO3\\CMS\\Form\\Hooks\\FormFileExtensionUpdate','i:1;'),(2,'installUpdate','TYPO3\\CMS\\Install\\Updates\\Typo3DbExtractionUpdate','i:1;'),(3,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FuncExtractionUpdate','i:1;'),(4,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigrateUrlTypesInPagesUpdate','i:1;'),(5,'installUpdate','TYPO3\\CMS\\Install\\Updates\\RedirectExtractionUpdate','i:1;'),(6,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendUserStartModuleUpdate','i:1;'),(7,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigratePagesLanguageOverlayUpdate','i:1;'),(8,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigratePagesLanguageOverlayBeGroupsAccessRights','i:1;'),(9,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendLayoutIconUpdateWizard','i:1;'),(10,'installUpdate','TYPO3\\CMS\\Install\\Updates\\RedirectsExtensionUpdate','i:1;'),(11,'installUpdate','TYPO3\\CMS\\Install\\Updates\\AdminPanelInstall','i:1;'),(12,'installUpdate','TYPO3\\CMS\\Install\\Updates\\PopulatePageSlugs','i:1;'),(13,'installUpdate','TYPO3\\CMS\\Install\\Updates\\Argon2iPasswordHashes','i:1;'),(14,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendUserConfigurationUpdate','i:1;'),(15,'installUpdate','TYPO3\\CMS\\Install\\Updates\\RsaauthExtractionUpdate','i:1;'),(16,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FeeditExtractionUpdate','i:1;'),(17,'installUpdate','TYPO3\\CMS\\Install\\Updates\\TaskcenterExtractionUpdate','i:1;'),(18,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysActionExtractionUpdate','i:1;'),(19,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SvgFilesSanitization','i:1;'),(20,'installUpdate','TYPO3\\CMS\\Felogin\\Updates\\MigrateFeloginPlugins','i:1;'),(21,'installUpdateRows','rowUpdatersDone','a:4:{i:0;s:69:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\WorkspaceVersionRecordsMigration\";i:1;s:66:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\L18nDiffsourceToJsonMigration\";i:2;s:77:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\WorkspaceMovePlaceholderRemovalMigration\";i:3;s:76:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\WorkspaceNewPlaceholderRemovalMigration\";}'),(22,'core','formProtectionSessionToken:1','s:64:\"903fab67be030fc729e62f2b9d6f960879808c972fa5f86087f377a39498e2a2\";'),(23,'extensionDataImport','typo3conf/ext/bootstrap_package/ext_tables_static+adt.sql','s:0:\"\";'),(24,'extensionDataImport','typo3conf/ext/pvh/ext_tables_static+adt.sql','s:0:\"\";'),(25,'extensionDataImport','typo3conf/ext/pizpalue/Initialisation/Files','i:1;'),(26,'extensionDataImport','typo3conf/ext/pizpalue/ext_tables_static+adt.sql','s:0:\"\";'),(27,'extensionDataImport','typo3conf/ext/auxlibs/ext_tables_static+adt.sql','s:0:\"\";'),(28,'extensionDataImport','typo3conf/ext/vhs/ext_tables_static+adt.sql','s:0:\"\";'),(29,'extensionDataImport','typo3conf/ext/timelog/ext_tables_static+adt.sql','s:0:\"\";'),(31,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendUserLanguageMigration','i:1;');
/*!40000 ALTER TABLE `sys_registry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_template`
--

DROP TABLE IF EXISTS `sys_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_template` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `root` smallint(5) unsigned NOT NULL DEFAULT 0,
  `clear` smallint(5) unsigned NOT NULL DEFAULT 0,
  `include_static_file` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `constants` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `config` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `basedOn` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `includeStaticAfterBasedOn` smallint(5) unsigned NOT NULL DEFAULT 0,
  `static_file_mode` smallint(5) unsigned NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `roottemplate` (`deleted`,`hidden`,`root`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_template`
--

LOCK TABLES `sys_template` WRITE;
/*!40000 ALTER TABLE `sys_template` DISABLE KEYS */;
INSERT INTO `sys_template` VALUES (1,1,1647330154,1647327736,1,0,0,0,0,256,NULL,0,0,0,0,0,'Pizpalue',1,3,'EXT:bootstrap_package/Configuration/TypoScript,EXT:timelog/Configuration/TypoScript,EXT:pizpalue/Configuration/TypoScript/Main','\npizpalue.agency.siteMode = 2',NULL,'',0,0,0),(2,2,1647330046,1647329974,1,0,0,0,0,256,NULL,0,0,0,0,0,'+ext',0,0,NULL,'\nplugin.tx_timelog_taskpanel.persistence.storagePid = 3',NULL,'',0,0,0);
/*!40000 ALTER TABLE `sys_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tt_content`
--

DROP TABLE IF EXISTS `tt_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tt_content` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rowDescription` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l18n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l18n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `CType` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `header` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `header_position` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `bodytext` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `bullets_type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_description` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `assets` int(10) unsigned NOT NULL DEFAULT 0,
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `imagewidth` int(10) unsigned NOT NULL DEFAULT 0,
  `imageorient` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imagecols` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imageborder` smallint(5) unsigned NOT NULL DEFAULT 0,
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `frame_class` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'default',
  `cols` int(10) unsigned NOT NULL DEFAULT 0,
  `space_before_class` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `space_after_class` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `records` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `pages` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `colPos` int(10) unsigned NOT NULL DEFAULT 0,
  `subheader` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `header_link` varchar(1024) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  `header_layout` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `list_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sectionIndex` smallint(5) unsigned NOT NULL DEFAULT 0,
  `linkToTop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `file_collections` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `filelink_size` smallint(5) unsigned NOT NULL DEFAULT 0,
  `filelink_sorting` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `filelink_sorting_direction` varchar(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `target` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `date` int(10) unsigned NOT NULL DEFAULT 0,
  `recursive` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imageheight` int(10) unsigned NOT NULL DEFAULT 0,
  `pi_flexform` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `accessibility_title` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `accessibility_bypass` smallint(5) unsigned NOT NULL DEFAULT 0,
  `accessibility_bypass_text` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `selected_categories` longtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `category_field` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `table_class` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `table_caption` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `table_delimiter` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_enclosure` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_header_position` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_tfoot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `teaser` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `aspect_ratio` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1.3333333333333',
  `items_per_page` int(10) unsigned DEFAULT 10,
  `readmore_label` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `quote_source` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `quote_link` varchar(1024) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `panel_class` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'default',
  `file_folder` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `icon` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `icon_set` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `icon_file` int(10) unsigned DEFAULT 0,
  `icon_position` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `icon_size` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'default',
  `icon_type` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'default',
  `icon_color` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `icon_background` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `external_media_source` varchar(1024) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `external_media_ratio` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tx_bootstrappackage_card_group_item` int(10) unsigned DEFAULT 0,
  `tx_bootstrappackage_carousel_item` int(10) unsigned DEFAULT 0,
  `tx_bootstrappackage_accordion_item` int(10) unsigned DEFAULT 0,
  `tx_bootstrappackage_icon_group_item` int(10) unsigned DEFAULT 0,
  `tx_bootstrappackage_tab_item` int(10) unsigned DEFAULT 0,
  `tx_bootstrappackage_timeline_item` int(10) unsigned DEFAULT 0,
  `frame_layout` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'default',
  `background_color_class` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `background_image` int(10) unsigned DEFAULT 0,
  `background_image_options` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `tx_pizpalue_header_class` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tx_pizpalue_subheader_class` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tx_pizpalue_layout_breakpoint` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tx_pizpalue_classes` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tx_pizpalue_style` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tx_pizpalue_attributes` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tx_pizpalue_animation` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tx_pizpalue_image_variants` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'variants',
  `tx_pizpalue_background_image_variants` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'pageVariants',
  `tx_pizpalue_image_scaling` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tx_pizpalue_image_aspect_ratio` text COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`sorting`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l18n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tt_content`
--

LOCK TABLES `tt_content` WRITE;
/*!40000 ALTER TABLE `tt_content` DISABLE KEYS */;
INSERT INTO `tt_content` VALUES (1,'',1,1647328247,1647328236,1,0,0,0,0,'',256,0,0,0,0,NULL,0,'{\"CType\":null,\"colPos\":null,\"header\":null,\"header_layout\":null,\"tx_pizpalue_header_class\":null,\"header_position\":null,\"date\":null,\"header_link\":null,\"subheader\":null,\"tx_pizpalue_subheader_class\":null,\"layout\":null,\"tx_pizpalue_layout_breakpoint\":null,\"space_before_class\":null,\"space_after_class\":null,\"frame_class\":null,\"frame_layout\":null,\"background_color_class\":null,\"background_image\":null,\"background_image_options\":null,\"tx_pizpalue_background_image_variants\":null,\"tx_pizpalue_animation\":null,\"tx_pizpalue_classes\":null,\"tx_pizpalue_style\":null,\"tx_pizpalue_attributes\":null,\"sectionIndex\":null,\"linkToTop\":null,\"sys_language_uid\":null,\"hidden\":null,\"starttime\":null,\"endtime\":null,\"fe_group\":null,\"editlock\":null,\"categories\":null,\"rowDescription\":null}',0,0,0,0,'header','Timelog dev site','center',NULL,0,0,0,0,0,0,0,1,0,0,'0','default',0,'','',NULL,NULL,8,'','',0,'1','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0,NULL,'1.3333333333333',10,'','','','default',NULL,'','',0,'','default','default','#FFFFFF','#333333','','',0,0,0,0,0,0,'default','primary',0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"parallax\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fade\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"filter\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','none','none','','','','','0','variants','pageVariants','xxl: 1.0,\nxl: 1.0,\nlg: 1.0,\nmd: 1.0,\nsm: 1.0,\nxs: 1.0','xxl: 0,\nxl: 0,\nlg: 0,\nmd: 0,\nsm: 0,\nxs: 0'),(2,'',2,1647329967,1647329924,1,0,0,0,0,'',256,0,0,0,0,NULL,0,'{\"CType\":null,\"colPos\":null,\"header\":null,\"header_layout\":null,\"tx_pizpalue_header_class\":null,\"header_position\":null,\"date\":null,\"header_link\":null,\"subheader\":null,\"tx_pizpalue_subheader_class\":null,\"list_type\":null,\"tx_pizpalue_image_variants\":null,\"pages\":null,\"recursive\":null,\"layout\":null,\"tx_pizpalue_layout_breakpoint\":null,\"space_before_class\":null,\"space_after_class\":null,\"frame_class\":null,\"frame_layout\":null,\"background_color_class\":null,\"background_image\":null,\"background_image_options\":null,\"tx_pizpalue_background_image_variants\":null,\"tx_pizpalue_animation\":null,\"tx_pizpalue_classes\":null,\"tx_pizpalue_style\":null,\"tx_pizpalue_attributes\":null,\"sectionIndex\":null,\"linkToTop\":null,\"sys_language_uid\":null,\"hidden\":null,\"starttime\":null,\"endtime\":null,\"fe_group\":null,\"editlock\":null,\"categories\":null,\"rowDescription\":null}',0,0,0,0,'list','','',NULL,0,0,0,0,0,0,0,1,0,0,'0','default',0,'','',NULL,'',0,'','',0,'0','timelog_taskpanel',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0,NULL,'1.3333333333333',10,'','','','default',NULL,'','',0,'','default','default','#FFFFFF','#333333','','',0,0,0,0,0,0,'default','none',0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"parallax\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fade\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"filter\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','none','none','','','','','0','variants','pageVariants','xxl: 1.0,\nxl: 1.0,\nlg: 1.0,\nmd: 1.0,\nsm: 1.0,\nxs: 1.0','xxl: 0,\nxl: 0,\nlg: 0,\nmd: 0,\nsm: 0,\nxs: 0');
/*!40000 ALTER TABLE `tt_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_bootstrappackage_accordion_item`
--

DROP TABLE IF EXISTS `tx_bootstrappackage_accordion_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_bootstrappackage_accordion_item` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tt_content` int(10) unsigned DEFAULT 0,
  `header` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `bodytext` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `media` int(10) unsigned DEFAULT 0,
  `mediaorient` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'left',
  `imagecols` smallint(5) unsigned NOT NULL DEFAULT 1,
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  `t3ver_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l10n_parent`,`sys_language_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_bootstrappackage_accordion_item`
--

LOCK TABLES `tx_bootstrappackage_accordion_item` WRITE;
/*!40000 ALTER TABLE `tx_bootstrappackage_accordion_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_bootstrappackage_accordion_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_bootstrappackage_card_group_item`
--

DROP TABLE IF EXISTS `tx_bootstrappackage_card_group_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_bootstrappackage_card_group_item` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tt_content` int(10) unsigned DEFAULT 0,
  `header` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `subheader` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `image` int(11) NOT NULL DEFAULT 0,
  `bodytext` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `link` varchar(1024) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_icon_set` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_icon_identifier` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_icon` int(10) unsigned DEFAULT 0,
  `link_class` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `t3ver_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l10n_parent`,`sys_language_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_bootstrappackage_card_group_item`
--

LOCK TABLES `tx_bootstrappackage_card_group_item` WRITE;
/*!40000 ALTER TABLE `tx_bootstrappackage_card_group_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_bootstrappackage_card_group_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_bootstrappackage_carousel_item`
--

DROP TABLE IF EXISTS `tx_bootstrappackage_carousel_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_bootstrappackage_carousel_item` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tt_content` int(10) unsigned DEFAULT 0,
  `item_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `layout` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `header` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `header_layout` smallint(5) unsigned NOT NULL DEFAULT 1,
  `header_position` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'center',
  `header_class` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `subheader` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `subheader_layout` smallint(5) unsigned NOT NULL DEFAULT 2,
  `subheader_class` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `nav_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `button_text` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `bodytext` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `image` int(10) unsigned DEFAULT 0,
  `link` varchar(1024) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `text_color` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `background_color` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `background_image` int(10) unsigned DEFAULT 0,
  `background_image_options` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3ver_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l10n_parent`,`sys_language_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_bootstrappackage_carousel_item`
--

LOCK TABLES `tx_bootstrappackage_carousel_item` WRITE;
/*!40000 ALTER TABLE `tx_bootstrappackage_carousel_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_bootstrappackage_carousel_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_bootstrappackage_icon_group_item`
--

DROP TABLE IF EXISTS `tx_bootstrappackage_icon_group_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_bootstrappackage_icon_group_item` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tt_content` int(10) unsigned DEFAULT 0,
  `header` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `subheader` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `bodytext` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `link` varchar(1024) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `icon_set` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `icon_identifier` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `icon_file` int(10) unsigned DEFAULT 0,
  `t3ver_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l10n_parent`,`sys_language_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_bootstrappackage_icon_group_item`
--

LOCK TABLES `tx_bootstrappackage_icon_group_item` WRITE;
/*!40000 ALTER TABLE `tx_bootstrappackage_icon_group_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_bootstrappackage_icon_group_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_bootstrappackage_tab_item`
--

DROP TABLE IF EXISTS `tx_bootstrappackage_tab_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_bootstrappackage_tab_item` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tt_content` int(10) unsigned DEFAULT 0,
  `header` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `bodytext` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `media` int(10) unsigned DEFAULT 0,
  `mediaorient` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'left',
  `imagecols` smallint(5) unsigned NOT NULL DEFAULT 1,
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  `t3ver_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l10n_parent`,`sys_language_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_bootstrappackage_tab_item`
--

LOCK TABLES `tx_bootstrappackage_tab_item` WRITE;
/*!40000 ALTER TABLE `tx_bootstrappackage_tab_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_bootstrappackage_tab_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_bootstrappackage_timeline_item`
--

DROP TABLE IF EXISTS `tx_bootstrappackage_timeline_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_bootstrappackage_timeline_item` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tt_content` int(10) unsigned DEFAULT 0,
  `date` datetime DEFAULT NULL,
  `header` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `bodytext` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `icon_set` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `icon_identifier` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `icon_file` int(10) unsigned DEFAULT 0,
  `image` int(10) unsigned DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `t3ver_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l10n_parent`,`sys_language_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_bootstrappackage_timeline_item`
--

LOCK TABLES `tx_bootstrappackage_timeline_item` WRITE;
/*!40000 ALTER TABLE `tx_bootstrappackage_timeline_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_bootstrappackage_timeline_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_extensionmanager_domain_model_extension`
--

DROP TABLE IF EXISTS `tx_extensionmanager_domain_model_extension`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_extensionmanager_domain_model_extension` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `extension_key` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `repository` int(11) NOT NULL DEFAULT 1,
  `version` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `alldownloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `downloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` int(11) NOT NULL DEFAULT 0,
  `review_state` int(11) NOT NULL DEFAULT 0,
  `category` int(11) NOT NULL DEFAULT 0,
  `last_updated` int(10) unsigned NOT NULL DEFAULT 0,
  `serialized_dependencies` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `author_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `author_email` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ownerusername` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `md5hash` varchar(35) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `update_comment` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `authorcompany` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `integer_version` int(11) NOT NULL DEFAULT 0,
  `current_version` int(11) NOT NULL DEFAULT 0,
  `lastreviewedversion` int(11) NOT NULL DEFAULT 0,
  `documentation_link` varchar(2048) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remote` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'ter',
  `distribution_image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `distribution_welcome_image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `versionextrepo` (`extension_key`,`version`,`remote`),
  KEY `index_currentversions` (`current_version`,`review_state`),
  KEY `parent` (`pid`),
  KEY `index_versionrepo` (`integer_version`,`remote`,`extension_key`),
  KEY `index_extrepo` (`extension_key`,`remote`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_extensionmanager_domain_model_extension`
--

LOCK TABLES `tx_extensionmanager_domain_model_extension` WRITE;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_impexp_presets`
--

DROP TABLE IF EXISTS `tx_impexp_presets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_impexp_presets` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `user_uid` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `public` smallint(6) NOT NULL DEFAULT 0,
  `item_uid` int(11) NOT NULL DEFAULT 0,
  `preset_data` blob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `lookup` (`item_uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_impexp_presets`
--

LOCK TABLES `tx_impexp_presets` WRITE;
/*!40000 ALTER TABLE `tx_impexp_presets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_impexp_presets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_timelog_domain_model_interval`
--

DROP TABLE IF EXISTS `tx_timelog_domain_model_interval`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_timelog_domain_model_interval` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `task` int(10) unsigned NOT NULL DEFAULT 0,
  `start_time` int(11) NOT NULL DEFAULT 0,
  `end_time` int(11) NOT NULL DEFAULT 0,
  `duration` double NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_timelog_domain_model_interval`
--

LOCK TABLES `tx_timelog_domain_model_interval` WRITE;
/*!40000 ALTER TABLE `tx_timelog_domain_model_interval` DISABLE KEYS */;
INSERT INTO `tx_timelog_domain_model_interval` VALUES (1,3,1647879594,1647331052,1,0,0,0,0,0,1,1647330956,1647333060,0.58444444444444),(2,3,1647930201,1647607063,1,0,0,0,0,0,2,1647330956,1647336660,1.5844444444444),(3,3,1647951456,1647936286,1,0,0,0,0,0,3,1647936000,1647937800,0.5),(4,3,1647944234,1647937940,1,1,0,0,0,0,3,1647937917,1647942300,1.2175),(5,3,1647945101,1647944485,1,1,0,0,0,0,3,1647944468,0,0),(6,3,1647946099,1647945135,1,1,0,0,0,0,3,1647941460,0,0),(7,3,1647946250,1647946121,1,1,0,0,0,0,3,1647942480,1647946800,0),(8,3,1647951456,1647946250,1,0,0,0,0,0,3,1647939000,1647946800,2.1666666666667);
/*!40000 ALTER TABLE `tx_timelog_domain_model_interval` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_timelog_domain_model_project`
--

DROP TABLE IF EXISTS `tx_timelog_domain_model_project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_timelog_domain_model_project` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `internal_note` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `active_time` double NOT NULL DEFAULT 0,
  `heap_time` double NOT NULL DEFAULT 0,
  `batch_time` double NOT NULL DEFAULT 0,
  `client` int(10) unsigned DEFAULT 0,
  `owner` int(10) unsigned DEFAULT 0,
  `cc_email` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tasks` int(10) unsigned NOT NULL DEFAULT 0,
  `task_groups` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_timelog_domain_model_project`
--

LOCK TABLES `tx_timelog_domain_model_project` WRITE;
/*!40000 ALTER TABLE `tx_timelog_domain_model_project` DISABLE KEYS */;
INSERT INTO `tx_timelog_domain_model_project` VALUES (1,3,1647951456,1647330904,1,0,0,0,0,0,'7wznO6qK','Project 1','# Goal\r\nThe goel description  The goel description  The goel description  The goel description  The goel description  The goel description  The goel description  The goel description  The goel description  The goel description \r\n\r\n# References\r\n- Repository','',4.2511111111111,4.2511111111111,0,2,1,'',1,1),(2,3,1647944186,1647607063,1,0,0,0,0,0,'7wznO6qK','Project 2','# Goal\r\nThe goel description  The goel description  The goel description  The goel description  The goel description  The goel description  The goel description  The goel description  The goel description  The goel description \r\n\r\n# References\r\n- Repository','',0.58444444444444,0.58444444444444,0,2,1,'',1,1);
/*!40000 ALTER TABLE `tx_timelog_domain_model_project` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_timelog_domain_model_task`
--

DROP TABLE IF EXISTS `tx_timelog_domain_model_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_timelog_domain_model_task` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `active_time` double NOT NULL DEFAULT 0,
  `batch_date` int(11) NOT NULL DEFAULT 0,
  `project` int(10) unsigned DEFAULT 0,
  `worker` int(10) unsigned DEFAULT 0,
  `task_group` int(10) unsigned DEFAULT 0,
  `intervals` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_timelog_domain_model_task`
--

LOCK TABLES `tx_timelog_domain_model_task` WRITE;
/*!40000 ALTER TABLE `tx_timelog_domain_model_task` DISABLE KEYS */;
INSERT INTO `tx_timelog_domain_model_task` VALUES (1,3,1647879594,1647331052,1,0,0,0,0,0,'MOJzl56n','Task 1','# Subgroup\r\n- Description goes here\r\n- [Description goes here](https://timelog.ddev.site)\r\n\r\n# Subgroup\r\n- Description goes here\r\n- Description goes here',0.58444444444444,0,2,3,0,1),(2,3,1647930201,1647607063,1,0,0,0,0,0,'MOJzl56n','Task 2','# Subgroup\r\n- Description goes here\r\n- [Description goes here](https://timelog.ddev.site)\r\n\r\n# Subgroup\r\n- Description goes here\r\n- Description goes here',1.5844444444444,0,1,3,0,1),(3,3,1647951456,1647936286,1,0,0,0,0,0,'105Nqp98','Task 3','# Subgroup\r\n- Description goes here\r\n- [Description goes here](https://timelog.ddev.site)\r\n\r\n# Subgroup\r\n- Description goes here\r\n- Description goes here',2.6666666666667,0,1,3,0,2);
/*!40000 ALTER TABLE `tx_timelog_domain_model_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_timelog_domain_model_taskgroup`
--

DROP TABLE IF EXISTS `tx_timelog_domain_model_taskgroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_timelog_domain_model_taskgroup` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `internal_note` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `time_target` double NOT NULL DEFAULT 0,
  `time_deviation` double NOT NULL DEFAULT 0,
  `active_time` double NOT NULL DEFAULT 0,
  `heap_time` double NOT NULL DEFAULT 0,
  `batch_time` double NOT NULL DEFAULT 0,
  `project` int(10) unsigned DEFAULT 0,
  `tasks` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_timelog_domain_model_taskgroup`
--

LOCK TABLES `tx_timelog_domain_model_taskgroup` WRITE;
/*!40000 ALTER TABLE `tx_timelog_domain_model_taskgroup` DISABLE KEYS */;
INSERT INTO `tx_timelog_domain_model_taskgroup` VALUES (1,3,1647940233,1647426367,1,0,0,0,0,0,'9d05nZyE','Task group 1','Description from first task group goes here','',0,0,0,0,0,1,0),(2,3,1647944186,1647607063,1,0,0,0,0,0,'9d05nZyE','Task group 2','Description from first task group goes here','',0,0,0,0,0,2,0);
/*!40000 ALTER TABLE `tx_timelog_domain_model_taskgroup` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-03-24 13:31:23
