-- MariaDB dump 10.19  Distrib 10.4.28-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.4.28-MariaDB-1:10.4.28+maria~ubu2004-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `backend_layout`
--

DROP TABLE IF EXISTS `backend_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backend_layout` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `config` text NOT NULL,
  `icon` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_layout`
--

LOCK TABLES `backend_layout` WRITE;
/*!40000 ALTER TABLE `backend_layout` DISABLE KEYS */;
/*!40000 ALTER TABLE `backend_layout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_dashboards`
--

DROP TABLE IF EXISTS `be_dashboards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_dashboards` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `identifier` varchar(120) NOT NULL DEFAULT '',
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(120) NOT NULL DEFAULT '',
  `widgets` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `identifier` (`identifier`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_dashboards`
--

LOCK TABLES `be_dashboards` WRITE;
/*!40000 ALTER TABLE `be_dashboards` DISABLE KEYS */;
INSERT INTO `be_dashboards` VALUES (1,0,1685605753,1685605753,0,0,0,0,'928313594de9c7e7ae34339f49c1ee834907bacb',1,'My dashboard','{\"b37a87113b4605c87f0e1bc069cf2adc7eb8a20f\":{\"identifier\":\"t3information\"},\"0a8405ad09c3e1b36f0d31b73e8032d535c8dba1\":{\"identifier\":\"docGettingStarted\"}}');
/*!40000 ALTER TABLE `be_dashboards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_groups`
--

DROP TABLE IF EXISTS `be_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `non_exclude_fields` text DEFAULT NULL,
  `explicit_allowdeny` text DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `custom_options` text DEFAULT NULL,
  `db_mountpoints` text DEFAULT NULL,
  `pagetypes_select` text DEFAULT NULL,
  `tables_select` text DEFAULT NULL,
  `tables_modify` text DEFAULT NULL,
  `groupMods` text DEFAULT NULL,
  `availableWidgets` text DEFAULT NULL,
  `mfa_providers` text DEFAULT NULL,
  `file_mountpoints` text DEFAULT NULL,
  `file_permissions` text DEFAULT NULL,
  `TSconfig` text DEFAULT NULL,
  `subgroup` text DEFAULT NULL,
  `workspace_perms` smallint(6) NOT NULL DEFAULT 1,
  `category_perms` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_groups`
--

LOCK TABLES `be_groups` WRITE;
/*!40000 ALTER TABLE `be_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `be_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_sessions`
--

DROP TABLE IF EXISTS `be_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` longblob DEFAULT NULL,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_sessions`
--

LOCK TABLES `be_sessions` WRITE;
/*!40000 ALTER TABLE `be_sessions` DISABLE KEYS */;
INSERT INTO `be_sessions` VALUES ('8b13563f848589e0658f913f4df95a2dd4403a790cace029bc3595f1bc5af039','[DISABLED]',1,1689050278,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"89424955d30c1bbbcb92c96d082171e0e7897e0d72662f213fd2a6bb02cc5913\";}');
/*!40000 ALTER TABLE `be_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_users`
--

DROP TABLE IF EXISTS `be_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `username` varchar(50) NOT NULL DEFAULT '',
  `avatar` int(10) unsigned NOT NULL DEFAULT 0,
  `password` varchar(255) NOT NULL DEFAULT '',
  `admin` smallint(5) unsigned NOT NULL DEFAULT 0,
  `usergroup` text DEFAULT NULL,
  `lang` varchar(10) NOT NULL DEFAULT 'default',
  `email` varchar(255) NOT NULL DEFAULT '',
  `db_mountpoints` text DEFAULT NULL,
  `options` smallint(5) unsigned NOT NULL DEFAULT 0,
  `realName` varchar(80) NOT NULL DEFAULT '',
  `userMods` text DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `uc` mediumblob DEFAULT NULL,
  `file_mountpoints` text DEFAULT NULL,
  `file_permissions` text DEFAULT NULL,
  `workspace_perms` smallint(6) NOT NULL DEFAULT 1,
  `TSconfig` text DEFAULT NULL,
  `workspace_id` int(11) NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `category_perms` longtext DEFAULT NULL,
  `lastlogin` int(11) NOT NULL DEFAULT 0,
  `password_reset_token` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `username` (`username`),
  KEY `parent` (`pid`,`deleted`,`disable`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_users`
--

LOCK TABLES `be_users` WRITE;
/*!40000 ALTER TABLE `be_users` DISABLE KEYS */;
INSERT INTO `be_users` VALUES (1,0,1685605732,1685605732,0,0,0,0,NULL,'admin',0,'$argon2i$v=19$m=65536,t=16,p=1$VFMzcnRtTEhwMFRZUmswMQ$YmG+c/QbIVsJnQzEQaLtZJozeVSvnXtdYByjNGr3XrQ',1,NULL,'default','',NULL,0,'',NULL,'','a:7:{s:10:\"moduleData\";a:8:{s:28:\"dashboard/current_dashboard/\";s:40:\"928313594de9c7e7ae34339f49c1ee834907bacb\";s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";a:0:{}s:10:\"FormEngine\";a:2:{i:0;a:1:{s:32:\"db15bfe2bbbf7b61b5ca2250b6f6f078\";a:4:{i:0;s:31:\"project 1 - 0.3, 0.3 - gZx0px5n\";i:1;a:5:{s:4:\"edit\";a:1:{s:31:\"tx_timelog_domain_model_project\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:54:\"&edit%5Btx_timelog_domain_model_project%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:31:\"tx_timelog_domain_model_project\";s:3:\"uid\";i:1;s:3:\"pid\";i:3;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}}i:1;s:32:\"db15bfe2bbbf7b61b5ca2250b6f6f078\";}s:16:\"opendocs::recent\";a:8:{s:32:\"dc98268f5a8c690c8c920b903ec5da99\";a:4:{i:0;s:6:\"owner1\";i:1;a:5:{s:4:\"edit\";a:1:{s:8:\"fe_users\";a:1:{i:3;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:31:\"&edit%5Bfe_users%5D%5B3%5D=edit\";i:3;a:5:{s:5:\"table\";s:8:\"fe_users\";s:3:\"uid\";i:3;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"39dbcbcf6026e584b0032e0fef8fd333\";a:4:{i:0;s:14:\"0.1 - NRpZ35qw\";i:1;a:5:{s:4:\"edit\";a:1:{s:28:\"tx_timelog_domain_model_task\";a:1:{i:2;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:51:\"&edit%5Btx_timelog_domain_model_task%5D%5B2%5D=edit\";i:3;a:5:{s:5:\"table\";s:28:\"tx_timelog_domain_model_task\";s:3:\"uid\";i:2;s:3:\"pid\";i:3;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"97ed4e91b158c32d503348f4e976b184\";a:4:{i:0;s:3:\"0.0\";i:1;a:5:{s:4:\"edit\";a:1:{s:28:\"tx_timelog_domain_model_task\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:51:\"&edit%5Btx_timelog_domain_model_task%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:28:\"tx_timelog_domain_model_task\";s:3:\"uid\";i:1;s:3:\"pid\";i:3;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"db15bfe2bbbf7b61b5ca2250b6f6f078\";a:4:{i:0;s:20:\"project 1 - 0.0, 0.0\";i:1;a:5:{s:4:\"edit\";a:1:{s:31:\"tx_timelog_domain_model_project\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:54:\"&edit%5Btx_timelog_domain_model_project%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:31:\"tx_timelog_domain_model_project\";s:3:\"uid\";i:1;s:3:\"pid\";i:3;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"e99b862b5fb646163abd0b35eef975a2\";a:4:{i:0;s:34:\"task group 1 - 0.0, 0.0 - 9d05nZyE\";i:1;a:5:{s:4:\"edit\";a:1:{s:33:\"tx_timelog_domain_model_taskgroup\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:56:\"&edit%5Btx_timelog_domain_model_taskgroup%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:33:\"tx_timelog_domain_model_taskgroup\";s:3:\"uid\";i:1;s:3:\"pid\";i:3;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"831786fd4612b658a2e11ed01c306877\";a:4:{i:0;s:7:\"worker1\";i:1;a:5:{s:4:\"edit\";a:1:{s:8:\"fe_users\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:31:\"&edit%5Bfe_users%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:8:\"fe_users\";s:3:\"uid\";i:1;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"ad6c6673a0ce0bd828f9e86c3bc41bf4\";a:4:{i:0;s:8:\"NEW SITE\";i:1;a:5:{s:4:\"edit\";a:1:{s:12:\"sys_template\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";s:6:\"config\";s:6:\"noView\";N;}i:2;s:54:\"&edit%5Bsys_template%5D%5B1%5D=edit&columnsOnly=config\";i:3;a:5:{s:5:\"table\";s:12:\"sys_template\";s:3:\"uid\";i:1;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"696addfecc296b326ff6e9f04c7ff3e1\";a:4:{i:0;s:16:\"Timelog dev site\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:28:\"&edit%5Bpages%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:1;s:3:\"pid\";i:0;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}}s:6:\"web_ts\";a:1:{s:6:\"action\";s:29:\"web_typoscript_constanteditor\";}s:25:\"web_typoscript_infomodify\";a:1:{s:23:\"selectedTemplatePerPage\";a:1:{i:1;i:1;}}s:12:\"pagetsconfig\";a:1:{s:6:\"action\";s:18:\"pagetsconfig_pages\";}s:29:\"web_typoscript_constanteditor\";a:2:{s:23:\"selectedTemplatePerPage\";a:1:{i:1;i:1;}s:16:\"selectedCategory\";s:27:\"plugin.tx_timelog_taskpanel\";}}s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";i:50;s:20:\"edit_docModuleUpload\";s:1:\"1\";s:15:\"moduleSessionID\";a:8:{s:28:\"dashboard/current_dashboard/\";s:40:\"8858b72cf099bd4cf7f19cfe6a78b61ea90d268f\";s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";s:40:\"7642eabb67b819a6830ad762437b2d977a59fe94\";s:10:\"FormEngine\";s:40:\"7642eabb67b819a6830ad762437b2d977a59fe94\";s:16:\"opendocs::recent\";s:40:\"8858b72cf099bd4cf7f19cfe6a78b61ea90d268f\";s:6:\"web_ts\";s:40:\"8858b72cf099bd4cf7f19cfe6a78b61ea90d268f\";s:25:\"web_typoscript_infomodify\";s:40:\"8858b72cf099bd4cf7f19cfe6a78b61ea90d268f\";s:12:\"pagetsconfig\";s:40:\"8858b72cf099bd4cf7f19cfe6a78b61ea90d268f\";s:29:\"web_typoscript_constanteditor\";s:40:\"8858b72cf099bd4cf7f19cfe6a78b61ea90d268f\";}s:17:\"BackendComponents\";a:1:{s:6:\"States\";a:1:{s:8:\"Pagetree\";a:1:{s:9:\"stateHash\";a:2:{s:3:\"0_0\";s:1:\"1\";s:3:\"0_1\";s:1:\"1\";}}}}s:10:\"inlineView\";s:259:\"{\"tx_timelog_domain_model_task\":{\"NEW6478704c65eb9852947870\":{\"tx_timelog_domain_model_interval\":[1]},\"NEW647876ef1049a482355407\":{\"tx_timelog_domain_model_interval\":[2]}},\"tx_timelog_domain_model_project\":{\"1\":{\"tx_timelog_domain_model_taskgroup\":{\"1\":\"\"}}}}\";}',NULL,NULL,1,NULL,0,NULL,NULL,1689050245,''),(2,0,1685725145,1685725145,0,0,0,0,NULL,'_cli_',0,'$argon2i$v=19$m=65536,t=16,p=1$VzFFVEtRdS9TN21rblVjMQ$12Wj1pn0pebtJQXlJ4LjP4KBza6E0ituWjneW6aLIKA',1,NULL,'default','',NULL,0,'',NULL,'','a:4:{s:10:\"moduleData\";a:0:{}s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";i:50;s:20:\"edit_docModuleUpload\";s:1:\"1\";}',NULL,NULL,1,NULL,0,NULL,NULL,0,'');
/*!40000 ALTER TABLE `be_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_hash`
--

DROP TABLE IF EXISTS `cache_hash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_hash` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash`
--

LOCK TABLES `cache_hash` WRITE;
/*!40000 ALTER TABLE `cache_hash` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_hash_tags`
--

DROP TABLE IF EXISTS `cache_hash_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_hash_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash_tags`
--

LOCK TABLES `cache_hash_tags` WRITE;
/*!40000 ALTER TABLE `cache_hash_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_imagesizes`
--

DROP TABLE IF EXISTS `cache_imagesizes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_imagesizes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_imagesizes`
--

LOCK TABLES `cache_imagesizes` WRITE;
/*!40000 ALTER TABLE `cache_imagesizes` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_imagesizes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_imagesizes_tags`
--

DROP TABLE IF EXISTS `cache_imagesizes_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_imagesizes_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_imagesizes_tags`
--

LOCK TABLES `cache_imagesizes_tags` WRITE;
/*!40000 ALTER TABLE `cache_imagesizes_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_imagesizes_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pages`
--

DROP TABLE IF EXISTS `cache_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages`
--

LOCK TABLES `cache_pages` WRITE;
/*!40000 ALTER TABLE `cache_pages` DISABLE KEYS */;
INSERT INTO `cache_pages` VALUES (1,'1_587febe8f2e52132ef77778a1ac3132423e13f66',1689136678,'x��=ks㸑�\Z�\n�6I�mV��9�<�g���e{7�ʦT	ISCP��;�߯/�ْǛ�.���$�F��\0�\0��?s�U�Ȍ�}���6^���	\r�\n��\Z�a��ӏ����:s��\"8>8�?N@���\n\r�߽�`\Z%����т&�q�$�4y]Y&�j���V����ѩ�ȿ?����8g~H���	�~B�	�>�i�9d9u<�pn�\"\ndE�O	��Y�Й,�;h|��q>�$V����ܹ�#x��=��9���؂b~�#?�ÙQ�I�Á`�+�.�@=�LcJ���l��I�8H<[��ۘ,�=��\0���$֎S�h�τG4vn����C�6��ҐC�2� ���k�]]ZM�,Z��l�8���_m֛-�M����@��,lcjU��ɜ��S��&�\n:rҘC3����@=�J[�O�2!K\">�Ւu�Z�,���U�����\0d��C��3���u�6����4�k��kS�C�Uq\0���\\mz�ߍg��P\0S���_ߞ�^��:�.��^˫7��Ƥ���ޠ�hvZ�^�9�������d�:����f|q��f�ư������ӝ�U/�/��i�����g���������d{�դ�:�0o����JԨ8n@8-,d������hP�۷��:X�lN@�l�T��@�Vo��e�T7�_	�	�*�G5xթ�l�:�aa0mH��k�����e���>�	�$��ɮ��M|��2��>��Y��5��_�⼮����n_��C� �>��Y��m#�M�W�muA9F<�l�$C�h�$\"`x��-�x��MJ��Ec��`wS0�\Z��s1�|�������%��<�`���c�O������A��c��R,5}.x�򏁿�$��������+\\��AD���,�X�eQR��]�F�����tY��Ů�c�bwd<�t}W�<W�}Q�s�S$�(�?t�|���y���9�c:�IpAU�F\n[1r9\"z�Y�|�~bu�{���)s�\\�M:T_��NO$���;?B�� ~�B���ȱ��\0�F1�\"X=H�1/�Z�NHV��T�	x�g�YT�jLկs««�	b|��X�+b\n��C)QT�I���\"a���\'���ӵ��b��8�\n��+���2�Հ�X5D8�8<v��Jф׼vsJ����n��I˛����M=ϛ���są��!_�*	�N]p��v����^2�A}P��]��i|�pEc�S|	�c\0�RX);8�d(�����SJ��)y`�BH�N-�y�T�B�A-]a<,�\0�SL�n�N�G�����J����-�\n���Z�bZsÏi�����\n3G���F]��)����=맪D����\'��KD�w���@�C� ��(��h1�L\Z��!��He�2�&���e�j�F?U�IiyM��\",Ӳ�{/a��������:Hg���h\0����v|3�>��=�O:���L���W��{�is���w0�4:rj����+�T��J�sIz�2}+I4es��/�mG5��cK�Eꔱ���{A�Ur����\"�)\ZК�Sl	�Z�Zŕ2ی�E�E��_�M�6Z��B��q~8e%����ٺ���JĖ���d��e�:�@��a����h�Y#�T\'��jB2��F��|9\n|����%T�,T�8p��^����Y8��r���m�����\"���j�v�7�z�F�\r�\\�T��:�p�/����x�<�˄�_@ɧ�uT[Ǜ��~����c��`~��1��ښ{�0�L�\"�����\r��@1/�ӈ�$a08��\r�����\n���B.���n+�Q�QM����9	��g��5�����[�Q紬m/�to������jt-(Uf�S�����t.�ݘ�X��I�l!Rí�[p��U�5����Y�+,�\r��ۏoϮ��O�%\0p���e��6Mp�B̸q[��\r�}|�˗��l+h�E�WfgXnc�:T!qY��۸3����S�Lj�n�-2�*f+��-EQ@mf��e�\'�\Z�ԇ\Z� �Նw1s�q������?^i�?^��W�*�~��C��Y�T���{C��$�\"`�K�«�?4	m6��\n��k:�y�DC��L>\n!�	2+u�m��D�6�߾�{cl�,Qe%R�\"�Bv����$�\Z�a�3��ςP\0�\0&�.]��&�m\Z]�`.	NBw�d�t+*2��cn�d@��tD��g�V�T�������[\\��v2T��d9ː������X,�\"��У0��v^��=�	\nI�����8�K�,����S0�-T�E�	�/��ra/���%�\r_�*\0〬3����,p!]1LY��g��t��S��g)�HsF��\0�B�C����?+3WT�~+<\0%��\r��d�8�\0�N`;[?8�<Ār���+�!;�*���Z�.Vn�eh��y���j\\��-N��\\\Z��x>=�䈄�zM9V�gW�#��y��Oj��\0Y��	��p��J0&��/2m�Y�6�u�i	�2�$YBG��v���RՓx�Dy�\Z\"��Y��$�Jo}\Zx�<|�1i��F���b��3߲��܁��Rx@�q����vr$��E��G	)������j�rp�X��4�;�/�RZp��۹�U� J0S�\n��ح�4��4�ZMZ�ec��@�����Jm�T�m�:�L4��}��d56�\0���z>��\0��(U�!AnA����I���޳S�(oc�eAG��\"��-�YN��܂�;)�4���^\\*�SE�2�C7XzX�R��c�02¢�����Q�L�:%]���%\r�! ;�$�0&|<�$��_�B���Q��hKdl��k��yGcHuj�\Z��������7���~����4~�]!�=[}Τ��j������2Ԟ��q�I����P���\r�m,,���\n��`^�o�c�@�Z �x⡇�1�	tkwEV�d�[��Ri��9cw��¯���:�������[6ZƱ��&3f44^����j���\"��B��g@%1�W,T��ZL1��h�مڝ�X�+�Cߥ_.:\"z�K+ʳ��2@S4㊐�YKNW�*a��&J�M^i5)ŷ�y+TC�y��f�%Dl�{K�Q���X*�n�0���/KP�\rf�dX1H���ӳE��/`��\\.T��M���b`Ъ?�\\J�:�BO��ԗP��&����k���Z����[�Lt]����(k�\"����X|뛷\"�ږ)3!8l�,�X�eY4ifr�Ul��4����.D*S�L\\&iU&2�PG8/0e7�\0f�	��H27#�.Rj���~�%�\"1P���2�y�%���T�y�+B�Kۍb����ny�i~���R��m��3�}Gf��Z��HPl����Z�>/��#�ˌ��	,��U9���nM�]��>�h�)\'T��a��J��Qzz�(�8���	�^���$��b4Ӊe2�B3}�\0iR�:	j$�;Uأ��$\ZTڹ�2��-���\"�T��\'�=v�c�\'��R���R\n/\'��/5�D��:�V�2�1�P-5�� �\r|��w0�*���]JՄ�ؑ��Oa��E�\\k�l�R�\'�7u}��j�*�W,U\0�+�T�\Z����t����\"�fgs�Rw�cK������+�	$��_D\r�.��-L.��V�*���q��)rtG��0a.�� �,%�ï�b��zD92y����6�Uv���6y��7m�*E6�����L��N#�\'�?���ψ��,������k�f��ؑ��4�.���f���}	ջ*�L:pa�[�� }-�ڀ5a��WyeC4��k�t֦^��{�*u\rN:�w�ɳ��C�LK�2٨&o��+�����p�旪4\n�63 ��y�l,����ֲw֌�s%J����wn?m��v�Ri�M�6\\�y}��_A�ʝz{3�0��26�M��h�7���Ǻ�����5o\'��Z+�V��1�?�\\?��ʬ��ˊ\rٹ�\'d��n��m�\Z���qcO-ʜnG���\r(��\Z�}�N,N���0�veI��I�ps@-�us;\n��g��cp��L���p,?��Ne�\\!�|�S�0���p;\n��O�\Z���?WFb[:�m�e��|Va�ֳZ(�I��XoՌU�ج�T0_v�D��<��F$��g�g7Y6|�����]^�W$�	��|��*c�.c�T�M]Rk�������TI�~6\"2��\"S��_UH��宪]Y���H;9��\rƛ\0l*Y\0�l���lS�v.��%��-f	8t#:�y��ZJ䇷�����[<����-�g�SDI���3�f�%�n��\"]�d)�Ҩ�ƞ�WmJ��h+\"������2=6r�5����v��hG%�<�7ZF:\\�-��Ԡ��45|h]�������+R�&MN\0�A�;zD 2������={H72t�]\r(�凅�c�\Z\"A|�aw[�\"�SS;P��$�K��Ʌ{ӎ�O2���$k_l���!]�J�~�flXf-,b��%f#3\nɀ\r�U�*�\'�j)&*Co\r{�\0[m5�Km�h��bla�o\rs#�E���2ڪ#���\'�֍X8��>��Ju�\ZL�[{4j�����Z2����βUd��MϚ%�0l�*����w��]w�&Q��4������i@pG!\r\0��^�?�?Y61q\'[b�����ze��Dm�h�Eaa�c�7b�=A�Y����!J;/����`�ܖ\\k�3�0-~�l�5\r�e�D�d�6:�J[��2 ��P���W֒�*�A�\"�Q�]B�R\"V���\"�Јq�c��y�Ö���\n�_�q��QV�Q��-\n�Z��vMWh�K��q�Y�&��:��J�ɴۃ�1e��;��y�)c�e��\0l��%f^���D�BE�j��!ZW��5ɍ,\"#uQl]hȍb�x\ZS\\�^�^(cx�\'!\n���-�KbO�cd�	hhm,Ζ ~���� �`�ѝȔހ� A�)+\n�����!��eۧ-r�5������M���=������S��]�KۺT%6�?�\r5{�Gg�҃��\0Kn���<���=�[\Z�CH���Ka�5�x�u<�ʕO����\'LvB&M���ʡV`�]X,A�VZ��wI���@f���8�{`��zXx�/t.z�2����PM�x\\�V��e�q���O�a,q�?U#;��Ю�|�Ą�bד�u�V~ۆ@c?�\"��\n����k-	i\"`p�{�>��8�d��T�kg,Y��:lhE������,MJs����&�?��ݕ��y�2(K�:�*NG\rC�O>�.`�>Ό��l�m�+đ�.pqj�-W��raf/��3��;���ڰE����w��a�%���\\zw�i��2\\=�aJ�W�$���Vl\ZZk�	�dX�P+�D���Z:�,���dJx���\ZFt�T���֗�����v8U%j�S�v���[K����.|�	:��2�I:y}���H�u��kc��%�,L��]D����C�yB�H #�O�\"���֥G�������g�|19:�<�:��Z�v| �N�����v�(���t��M�6����A/E�-���Pbr�71��L��Ln�u�;��:l[�Q���d.�/�fVM`�14�^\0���e��\Z|[F��^Წ����)(?�Õ�����O���Z�\'\r�L��HTx�Q;#�����2�:�R���cW�¬H��\r�e����O>0χ�X�N����L��DF���}�39��^��.�\\��$W�E�(P8�R��*s�4�ג�h�Ʊ��*9�������p�B-3:i���y�	���g�.\"\\�1��>��ވ��	nz?�@Y��3���,u`��HҀ�~��ָ!2ѫ\r\"�&�e�Y\ZD�aܹ1�\r�9N!�ܴ*d@�e`�CΞg\'�g�\"���&�=�K�!��bG,�I�\'.�<�IL�u9/�;�RB��hI���ln�������?��J9Eh���V����S�S��ӷ=��dRWO�,a�ޏp��k[����*�f��=��զA�QK+6��/æ���g��9��je�_�Ե�\Z[�͚��tͲ���=˶eY�f���-�v�p�S\r�ٵ-��6�x�wk������_�gv�{�m˸�͸\07\'�a;��_�i��=öeX�f�<�r;��v����ږY��g��}i�C���F�o{�m˴��a�`���͊�gݳ��jsi��p�mX�U>���IN钇��=����\riL�_�E��=��eQ7e_\0g�j�v+7��l>�m홵�o�5g�����|V�����a�W7lg�T%����\\�=_v��5����=_�2�q\Z�|wϵ��	#���=f[1O ԑ\r�0��5@�O��sةy�$��|^�_��[^���F��ԗ��H�����v�)���:�dN0и\\�4����d/V1�u��n\rx�)�G��Ӹң;��^)u�EJ\'N��Fm�!me�TO��aȳ��;��O\"�/�8�\"�<��f\n�3?�16(�|.�\rT�X�( ����D����_���+oHȝ��\r[���m�߫�KY��4��0�h\nwҐN�)�)kFlqO&Л���\0��i����g=J��voU��x2\rY��oIЭ���SY��a��8�XD-�u.�i���y�\r`uz���_$bt\\�`�<�V�Wg��ښP�C~m?��8S�	��ka���B�_�B`y�m]�cs��	��L���8w:~*ĸZ=6����_\\����Z_u�FE����G5� ��R�F2@U��`��ڟ+�J�Qu9Pߒ[�uA�Rz����[�be4(}�I*X�sũɢM�u��[�0�~�S�*W���s\'�R�����������;�Z�~���mg�[��ߥP�!����Wt�u ��������;�w����������w���������;�w��[�^�����������wS��v�,����WT��@g�oy�!����q�K\r���������w�B�;_��_�ѻ\"��^ԧ�tڛOՉ����I^�\0���u8Wwf�{+��=����`G�\"���A�\Z7�黀ާ�\n����bW/ԱO���Tw~0+�!�Dd�����q�׍\0���o|�<�<���.-�?�Ŕ��+i�����\"`�P��d��A훣��6�+���M�l��\\훿���@LTY�s�2�ߜa�f�}ȃw0��^8��\Z��d\rqF:��&PWY�c}2�`���7*��Rz���}�0�����O��ޤ��7&�A�Cڴ��<�;z�ioBl1�F���U<ϰ��~�jt��n��{J2�Aљ����lB���Yhb�3��.Hi:y/�y�&�E��8� �,/���@�]�[v��g�A�}��@3���ĵ�*\n�L|��;��~T���Ţ$���%���8�0�<2qMg>4�6���F����!Y?�k���7��Y��Ǚ���E4N�AF2Z�.qF�������+��������5�f��8��\\e@ː��Y��5�-E�m����q4���4���8D�ޣ�<�=����x�VGVT��C��񭳀��r���A��5a	\ns��S&���`C\'���ǈ�߁M�o�	n�����O`���Qq����x���ȗ���~~��s�4�ߡL���Ț+�Q�aV�&0�T��JЧ%I�Hn*�<y�3M�A~�BJd����5=ILB����� 1\Z���,=֮\'h ��O��=������P�7�WZ�,;\rT��`�۳7P\0JWF�^�%]ح�U�;�j%�i�����E�0�1���I�ㅾ*��V��nu�8tu�l�l��H�h�@���4�P�Uȳ��g�C�A���������zS�蛂u�	���!Ͻ�8E��\0��2�');
/*!40000 ALTER TABLE `cache_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pages_tags`
--

DROP TABLE IF EXISTS `cache_pages_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_pages_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages_tags`
--

LOCK TABLES `cache_pages_tags` WRITE;
/*!40000 ALTER TABLE `cache_pages_tags` DISABLE KEYS */;
INSERT INTO `cache_pages_tags` VALUES (1,'1_587febe8f2e52132ef77778a1ac3132423e13f66','pageId_1');
/*!40000 ALTER TABLE `cache_pages_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_rootline`
--

DROP TABLE IF EXISTS `cache_rootline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_rootline` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline`
--

LOCK TABLES `cache_rootline` WRITE;
/*!40000 ALTER TABLE `cache_rootline` DISABLE KEYS */;
INSERT INTO `cache_rootline` VALUES (1,'1__0_0_1',1691642273,'x�M�]r� ������_r����\Zb�	F#�f:�{�]ZެoV�emt�����n�+�V����:�mjdz׊�@��f_�g�hShd�X�P�^f��hչ=\r;��.:^�	f�?���muD�L����;%.�>��\n/�?3˝�^��`k��a�)M�{·_,ڎ��2�c�a���	K5�ѝ{\nW7��)����F���\'��O����3W펔C��V��J��$l@���qA����(�9�\Z������p��'),(2,'3__0_0_1',1691642275,'x��S�N�0�#�Q�+T����]�8P!����C���D�$���;��)��V�R�Z_�y��7�y�e&�V�K-3!�ANeZZ�^vX�1�r4�)M�Fl��s�b@i��1j�q�Ls[��u\Z��n���Y��A��t&S�_���������\\�Z1���\Zx3F.d�j]a]v�\\𤿙^��s|���^C���kٓd��H�?��?ھ��9�����v�8)+h,<\'�㣄�(�+���^h����\'Xѐ�c�^:�����`�79�&_�l6�����=w�rϕ�\Z����(������Wl���x(�Q(�W�6��;;ڠ�%�id�kO�97�\n݀glť^m�*�Oy��rЀ�۳�]�ɇU�^�γ�]J4I���T;�?�)�y�=Xq���S�#�LA�PQv��m�\0�~�'),(3,'1__0_0_0',1691642278,'x�M�]r� ������_r����\Zb�	F#�f:�{�]ZެoV�emt�����n�+�V����:�mjdz׊�@��f_�g�hShd�X�P�^f��hչ=\r;��.:^�	f�?���muD�L����;%.�>��\n/�?3˝�^��`k��a�)M�{·_,ڎ��2�c�a���	K5�ѝ{\nW7��)����F���\'��O����3W펔C��V��J��$l@���qA����(�9�\Z������p��');
/*!40000 ALTER TABLE `cache_rootline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_rootline_tags`
--

DROP TABLE IF EXISTS `cache_rootline_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_rootline_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline_tags`
--

LOCK TABLES `cache_rootline_tags` WRITE;
/*!40000 ALTER TABLE `cache_rootline_tags` DISABLE KEYS */;
INSERT INTO `cache_rootline_tags` VALUES (1,'1__0_0_1','pageId_1'),(2,'3__0_0_1','pageId_3'),(3,'3__0_0_1','pageId_1'),(4,'1__0_0_0','pageId_1');
/*!40000 ALTER TABLE `cache_rootline_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_treelist`
--

DROP TABLE IF EXISTS `cache_treelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_treelist` (
  `md5hash` varchar(32) NOT NULL DEFAULT '',
  `pid` int(11) NOT NULL DEFAULT 0,
  `treelist` mediumtext DEFAULT NULL,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`md5hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_treelist`
--

LOCK TABLES `cache_treelist` WRITE;
/*!40000 ALTER TABLE `cache_treelist` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_treelist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_groups`
--

DROP TABLE IF EXISTS `fe_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_extbase_type` varchar(255) NOT NULL DEFAULT '0',
  `title` varchar(50) NOT NULL DEFAULT '',
  `subgroup` tinytext DEFAULT NULL,
  `TSconfig` text DEFAULT NULL,
  `felogin_redirectPid` tinytext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_groups`
--

LOCK TABLES `fe_groups` WRITE;
/*!40000 ALTER TABLE `fe_groups` DISABLE KEYS */;
INSERT INTO `fe_groups` VALUES (1,2,1685614562,1685614562,0,0,'','0','All','','','');
/*!40000 ALTER TABLE `fe_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_sessions`
--

DROP TABLE IF EXISTS `fe_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` mediumblob DEFAULT NULL,
  `ses_permanent` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_sessions`
--

LOCK TABLES `fe_sessions` WRITE;
/*!40000 ALTER TABLE `fe_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_users`
--

DROP TABLE IF EXISTS `fe_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_extbase_type` varchar(255) NOT NULL DEFAULT '0',
  `lastlogin` int(11) NOT NULL DEFAULT 0,
  `username` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `usergroup` text DEFAULT NULL,
  `name` varchar(160) NOT NULL DEFAULT '',
  `first_name` varchar(50) NOT NULL DEFAULT '',
  `middle_name` varchar(50) NOT NULL DEFAULT '',
  `last_name` varchar(50) NOT NULL DEFAULT '',
  `address` varchar(255) NOT NULL DEFAULT '',
  `telephone` varchar(30) NOT NULL DEFAULT '',
  `fax` varchar(30) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `uc` blob DEFAULT NULL,
  `title` varchar(40) NOT NULL DEFAULT '',
  `zip` varchar(10) NOT NULL DEFAULT '',
  `city` varchar(50) NOT NULL DEFAULT '',
  `country` varchar(40) NOT NULL DEFAULT '',
  `www` varchar(80) NOT NULL DEFAULT '',
  `company` varchar(80) NOT NULL DEFAULT '',
  `image` tinytext DEFAULT NULL,
  `TSconfig` text DEFAULT NULL,
  `is_online` int(10) unsigned NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `felogin_redirectPid` tinytext DEFAULT NULL,
  `felogin_forgotHash` varchar(80) DEFAULT '',
  `tx_timelog_owner_email` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`username`(100)),
  KEY `username` (`username`(100)),
  KEY `is_online` (`is_online`),
  KEY `felogin_forgotHash` (`felogin_forgotHash`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_users`
--

LOCK TABLES `fe_users` WRITE;
/*!40000 ALTER TABLE `fe_users` DISABLE KEYS */;
INSERT INTO `fe_users` VALUES (1,2,1685614608,1685614585,0,0,0,0,'','0',0,'worker1','$argon2i$v=19$m=65536,t=16,p=1$NXpaRTJFYnF0eHY0b1g4aw$39qBPUvomYoC3FdUA0RkY8ptlbVYTjygogmRC90DAWA','1','','','','','','','','',NULL,'','','','','','','0','',0,NULL,'','',''),(2,2,1685614629,1685614629,0,0,0,0,'','0',0,'worker2','$argon2i$v=19$m=65536,t=16,p=1$UkE1d29SMEtSSzV4VzNmcg$niigLr92mpBBH+X2Bri+gqcry1cox3+nxQuZPOvz+aI','1','','','','','','','','',NULL,'','','','','','',NULL,'',0,NULL,'','',''),(3,2,1685619947,1685619933,0,0,0,0,'','0',0,'owner1','$argon2i$v=19$m=65536,t=16,p=1$TlF3T29LbEZCM1psdFExSg$IECdlEUaBZOFa0p64a2wxqOPTeEXl3fetXYx2uk+DFk','1','owner 1','','','','','','','owner1@timelog.ddev.site',NULL,'','','','','','owner 1 gmbh','0','',0,NULL,'','',''),(4,2,1685619995,1685619995,0,0,0,0,'','0',0,'customer1','$argon2i$v=19$m=65536,t=16,p=1$TjdNWnR2RjNtdVMweGhHaA$+ELqKaeuKoTy7pk3kBRBm4lFYsGyzu4PE2P5yRMWpYM','1','','customer 1','','','','','','customer1@timelog.ddev.site',NULL,'','','','','','customer 1 gmbh',NULL,'',0,NULL,'','','');
/*!40000 ALTER TABLE `fe_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `perms_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_groupid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_user` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_group` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_everybody` smallint(5) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `doktype` int(10) unsigned NOT NULL DEFAULT 0,
  `TSconfig` text DEFAULT NULL,
  `is_siteroot` smallint(6) NOT NULL DEFAULT 0,
  `php_tree_stop` smallint(6) NOT NULL DEFAULT 0,
  `url` varchar(255) NOT NULL DEFAULT '',
  `shortcut` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut_mode` int(10) unsigned NOT NULL DEFAULT 0,
  `subtitle` varchar(255) NOT NULL DEFAULT '',
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `target` varchar(80) NOT NULL DEFAULT '',
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `keywords` text DEFAULT NULL,
  `cache_timeout` int(10) unsigned NOT NULL DEFAULT 0,
  `cache_tags` varchar(255) NOT NULL DEFAULT '',
  `description` text DEFAULT NULL,
  `no_search` smallint(5) unsigned NOT NULL DEFAULT 0,
  `SYS_LASTCHANGED` int(10) unsigned NOT NULL DEFAULT 0,
  `abstract` text DEFAULT NULL,
  `module` varchar(255) NOT NULL DEFAULT '',
  `extendToSubpages` smallint(5) unsigned NOT NULL DEFAULT 0,
  `author` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `nav_title` varchar(255) NOT NULL DEFAULT '',
  `nav_hide` smallint(6) NOT NULL DEFAULT 0,
  `content_from_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid_ol` smallint(6) NOT NULL DEFAULT 0,
  `l18n_cfg` smallint(6) NOT NULL DEFAULT 0,
  `backend_layout` varchar(64) NOT NULL DEFAULT '',
  `backend_layout_next_level` varchar(64) NOT NULL DEFAULT '',
  `tsconfig_includes` text DEFAULT NULL,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `lastUpdated` int(11) NOT NULL DEFAULT 0,
  `newUntil` int(11) NOT NULL DEFAULT 0,
  `slug` varchar(2048) DEFAULT NULL,
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `no_index` smallint(6) NOT NULL DEFAULT 0,
  `no_follow` smallint(6) NOT NULL DEFAULT 0,
  `og_title` varchar(255) NOT NULL DEFAULT '',
  `og_description` text DEFAULT NULL,
  `og_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_title` varchar(255) NOT NULL DEFAULT '',
  `twitter_description` text DEFAULT NULL,
  `twitter_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_card` varchar(255) NOT NULL DEFAULT '',
  `canonical_link` varchar(2048) NOT NULL DEFAULT '',
  `sitemap_priority` decimal(2,1) NOT NULL DEFAULT 0.5,
  `sitemap_changefreq` varchar(10) NOT NULL DEFAULT '',
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `nav_icon_set` varchar(255) NOT NULL DEFAULT '',
  `nav_icon_identifier` varchar(255) NOT NULL DEFAULT '',
  `nav_icon` int(10) unsigned DEFAULT 0,
  `thumbnail` int(10) unsigned DEFAULT 0,
  `tx_pizpalue_background_image` int(10) unsigned DEFAULT 0,
  `tx_pizpalue_css` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `determineSiteRoot` (`is_siteroot`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `slug` (`slug`(127)),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES (1,0,1685605891,1685605795,0,0,0,0,'',256,NULL,0,0,0,0,NULL,0,'{\"doktype\":\"\",\"title\":\"\",\"slug\":\"\",\"nav_title\":\"\",\"subtitle\":\"\",\"nav_icon_set\":\"\",\"nav_icon\":\"\",\"seo_title\":\"\",\"description\":\"\",\"no_index\":\"\",\"no_follow\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"og_title\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_card\":\"\",\"abstract\":\"\",\"keywords\":\"\",\"author\":\"\",\"author_email\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"newUntil\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tx_pizpalue_background_image\":\"\",\"thumbnail\":\"\",\"content_from_pid\":\"\",\"tx_pizpalue_css\":\"\",\"target\":\"\",\"cache_timeout\":\"\",\"cache_tags\":\"\",\"is_siteroot\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"module\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"\",\"hidden\":\"\",\"nav_hide\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,1,1,31,31,0,'Timelog dev site',1,NULL,1,0,'',0,0,'',0,'',0,NULL,0,'',NULL,0,1685605891,NULL,'',0,'','','',0,0,0,0,0,'pagets__simple','pagets__simple',NULL,0,0,0,'/','',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,'',0,'','',0,0,0,NULL),(2,1,1685614488,1685614460,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,1,1,31,31,0,'Users',254,NULL,0,0,'',0,0,'',0,'',0,NULL,0,'',NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,0,0,0,'/users','',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,'',0,'','',0,0,0,NULL),(3,1,1685617039,1685614653,0,0,0,0,'0',128,NULL,0,0,0,0,NULL,0,'{\"doktype\":\"\",\"title\":\"\",\"slug\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"module\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"hidden\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\",\"tx_pizpalue_background_image\":\"\",\"tx_pizpalue_css\":\"\"}',0,0,0,0,1,1,31,31,0,'Timelog',254,'TCEMAIN.preview {\r\n    tx_timelog_domain_model_project {\r\n        disableButtonForDokType = 255, 199\r\n        previewPageId = 1\r\n    }\r\n    tx_timelog_domain_model_taskgroup {\r\n        disableButtonForDokType = 255, 199\r\n        previewPageId = 1\r\n    }\r\n    tx_timelog_domain_model_task {\r\n        disableButtonForDokType = 255, 199\r\n        previewPageId = 1\r\n    }\r\n}',0,0,'',0,0,'',0,'',0,NULL,0,'',NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,0,0,0,'/timelog','',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,'',0,'','',0,0,0,NULL);
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_be_shortcuts`
--

DROP TABLE IF EXISTS `sys_be_shortcuts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_be_shortcuts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `route` varchar(255) NOT NULL DEFAULT '',
  `arguments` text DEFAULT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sc_group` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts`
--

LOCK TABLES `sys_be_shortcuts` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category`
--

DROP TABLE IF EXISTS `sys_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_category` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext NOT NULL,
  `items` int(11) NOT NULL DEFAULT 0,
  `parent` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `category_parent` (`parent`),
  KEY `category_list` (`pid`,`deleted`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category`
--

LOCK TABLES `sys_category` WRITE;
/*!40000 ALTER TABLE `sys_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category_record_mm`
--

DROP TABLE IF EXISTS `sys_category_record_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_category_record_mm` (
  `uid_local` int(10) unsigned NOT NULL DEFAULT 0,
  `uid_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `tablenames` varchar(255) NOT NULL DEFAULT '',
  `fieldname` varchar(255) NOT NULL DEFAULT '',
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category_record_mm`
--

LOCK TABLES `sys_category_record_mm` WRITE;
/*!40000 ALTER TABLE `sys_category_record_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category_record_mm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_csp_resolution`
--

DROP TABLE IF EXISTS `sys_csp_resolution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_csp_resolution` (
  `summary` varchar(40) NOT NULL,
  `created` int(10) unsigned NOT NULL,
  `scope` varchar(32) NOT NULL,
  `mutation_identifier` text DEFAULT NULL,
  `mutation_collection` mediumtext DEFAULT NULL,
  `meta` mediumtext DEFAULT NULL,
  PRIMARY KEY (`summary`),
  KEY `created` (`created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_csp_resolution`
--

LOCK TABLES `sys_csp_resolution` WRITE;
/*!40000 ALTER TABLE `sys_csp_resolution` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_csp_resolution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file`
--

DROP TABLE IF EXISTS `sys_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `last_indexed` int(11) NOT NULL DEFAULT 0,
  `missing` smallint(6) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `type` varchar(10) NOT NULL DEFAULT '',
  `metadata` int(11) NOT NULL DEFAULT 0,
  `identifier` text DEFAULT NULL,
  `identifier_hash` varchar(40) NOT NULL DEFAULT '',
  `folder_hash` varchar(40) NOT NULL DEFAULT '',
  `extension` varchar(255) NOT NULL DEFAULT '',
  `mime_type` varchar(255) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `sha1` varchar(40) NOT NULL DEFAULT '',
  `size` bigint(20) unsigned NOT NULL DEFAULT 0,
  `creation_date` int(11) NOT NULL DEFAULT 0,
  `modification_date` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `sel01` (`storage`,`identifier_hash`),
  KEY `folder` (`storage`,`folder_hash`),
  KEY `tstamp` (`tstamp`),
  KEY `lastindex` (`last_indexed`),
  KEY `sha1` (`sha1`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file`
--

LOCK TABLES `sys_file` WRITE;
/*!40000 ALTER TABLE `sys_file` DISABLE KEYS */;
INSERT INTO `sys_file` VALUES (1,0,1685605872,0,0,0,'2',0,'/typo3conf/ext/pizpalue/Resources/Public/Images/logo.svg','f58aecbf54576a74b25ac2b41de7ea67ab111985','dd94046bf22bb2ceaab9445e61808b94503ecba0','svg','image/svg+xml','logo.svg','209bad3465fb3ea3045e14b4fb46648e4fa669f0',6428,1685605164,1683704358),(2,0,1685605872,0,0,0,'2',0,'/typo3conf/ext/pizpalue/Resources/Public/Images/logo_inv.svg','6f173dfaa393763e1afe9baeac4ec8fcd222f105','dd94046bf22bb2ceaab9445e61808b94503ecba0','svg','image/svg+xml','logo_inv.svg','6fb1dcf4ee8443902d186f5960437bd32356e5c6',6426,1685605164,1683704358),(3,0,1685725205,0,0,0,'2',0,'/_assets/d42faaa7800615c4a3db88a1dfdddb36/Images/logo.svg','b5789c4c5a4d3253ff23b6fbfbbe9a2ddbfce730','f80e3d6b23f1a7f541824f3cb5136afab7787153','svg','image/svg+xml','logo.svg','209bad3465fb3ea3045e14b4fb46648e4fa669f0',6428,1685724684,1683704358),(4,0,1685725205,0,0,0,'2',0,'/_assets/d42faaa7800615c4a3db88a1dfdddb36/Images/logo_inv.svg','8da84941da30167592cd3a703c43b4dad3a2d232','f80e3d6b23f1a7f541824f3cb5136afab7787153','svg','image/svg+xml','logo_inv.svg','6fb1dcf4ee8443902d186f5960437bd32356e5c6',6426,1685724684,1683704358);
/*!40000 ALTER TABLE `sys_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_collection`
--

DROP TABLE IF EXISTS `sys_file_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_collection` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `type` varchar(30) NOT NULL DEFAULT 'static',
  `files` int(11) NOT NULL DEFAULT 0,
  `folder_identifier` varchar(255) NOT NULL DEFAULT '',
  `recursive` smallint(6) NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_collection`
--

LOCK TABLES `sys_file_collection` WRITE;
/*!40000 ALTER TABLE `sys_file_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_collection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_metadata`
--

DROP TABLE IF EXISTS `sys_file_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_metadata` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `file` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `width` int(11) NOT NULL DEFAULT 0,
  `height` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `file` (`file`),
  KEY `fal_filelist` (`l10n_parent`,`sys_language_uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_metadata`
--

LOCK TABLES `sys_file_metadata` WRITE;
/*!40000 ALTER TABLE `sys_file_metadata` DISABLE KEYS */;
INSERT INTO `sys_file_metadata` VALUES (1,0,1685605872,1685605872,0,0,NULL,0,'',0,0,0,0,1,NULL,1773,600,NULL,NULL,0),(2,0,1685605872,1685605872,0,0,NULL,0,'',0,0,0,0,2,NULL,1773,600,NULL,NULL,0),(3,0,1685725205,1685725205,0,0,NULL,0,'',0,0,0,0,3,NULL,1773,600,NULL,NULL,0),(4,0,1685725205,1685725205,0,0,NULL,0,'',0,0,0,0,4,NULL,1773,600,NULL,NULL,0);
/*!40000 ALTER TABLE `sys_file_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_processedfile`
--

DROP TABLE IF EXISTS `sys_file_processedfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_processedfile` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `original` int(11) NOT NULL DEFAULT 0,
  `identifier` varchar(512) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `processing_url` text DEFAULT NULL,
  `configuration` blob DEFAULT NULL,
  `configurationsha1` varchar(40) NOT NULL DEFAULT '',
  `originalfilesha1` varchar(40) NOT NULL DEFAULT '',
  `task_type` varchar(200) NOT NULL DEFAULT '',
  `checksum` varchar(32) NOT NULL DEFAULT '',
  `width` int(11) DEFAULT 0,
  `height` int(11) DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `combined_1` (`original`,`task_type`(100),`configurationsha1`),
  KEY `identifier` (`storage`,`identifier`(180))
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_processedfile`
--

LOCK TABLES `sys_file_processedfile` WRITE;
/*!40000 ALTER TABLE `sys_file_processedfile` DISABLE KEYS */;
INSERT INTO `sys_file_processedfile` VALUES (1,1685605872,1685605872,0,1,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','209bad3465fb3ea3045e14b4fb46648e4fa669f0','Image.CropScaleMask','2d625d340c',1773,600),(2,1685605872,1685605872,0,2,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','6fb1dcf4ee8443902d186f5960437bd32356e5c6','Image.CropScaleMask','5f990e4a3f',1773,600),(3,1685725205,1685725205,0,3,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','209bad3465fb3ea3045e14b4fb46648e4fa669f0','Image.CropScaleMask','c40bc3ce78',1773,600),(4,1685725205,1685725205,0,4,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','6fb1dcf4ee8443902d186f5960437bd32356e5c6','Image.CropScaleMask','45293a279d',1773,600);
/*!40000 ALTER TABLE `sys_file_processedfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_reference`
--

DROP TABLE IF EXISTS `sys_file_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_reference` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `description` text DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `link` varchar(1024) NOT NULL DEFAULT '',
  `crop` varchar(4000) NOT NULL DEFAULT '',
  `autoplay` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `tablenames_fieldname` (`tablenames`(32),`fieldname`(12)),
  KEY `deleted` (`deleted`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`),
  KEY `combined_1` (`l10n_parent`,`t3ver_oid`,`t3ver_wsid`,`t3ver_state`,`deleted`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_reference`
--

LOCK TABLES `sys_file_reference` WRITE;
/*!40000 ALTER TABLE `sys_file_reference` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_reference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_storage`
--

DROP TABLE IF EXISTS `sys_file_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_storage` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `driver` tinytext DEFAULT NULL,
  `configuration` text DEFAULT NULL,
  `is_default` smallint(6) NOT NULL DEFAULT 0,
  `is_browsable` smallint(6) NOT NULL DEFAULT 0,
  `is_public` smallint(6) NOT NULL DEFAULT 0,
  `is_writable` smallint(6) NOT NULL DEFAULT 0,
  `is_online` smallint(6) NOT NULL DEFAULT 1,
  `auto_extract_metadata` smallint(6) NOT NULL DEFAULT 1,
  `processingfolder` tinytext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_storage`
--

LOCK TABLES `sys_file_storage` WRITE;
/*!40000 ALTER TABLE `sys_file_storage` DISABLE KEYS */;
INSERT INTO `sys_file_storage` VALUES (1,0,1685605803,1685605803,0,'This is the local fileadmin/ directory. This storage mount has been created automatically by TYPO3.','fileadmin','Local','<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"basePath\">\n                    <value index=\"vDEF\">fileadmin/</value>\n                </field>\n                <field index=\"pathType\">\n                    <value index=\"vDEF\">relative</value>\n                </field>\n                <field index=\"caseSensitive\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',1,1,1,1,1,1,NULL);
/*!40000 ALTER TABLE `sys_file_storage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_filemounts`
--

DROP TABLE IF EXISTS `sys_filemounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_filemounts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `identifier` varchar(255) NOT NULL DEFAULT '',
  `read_only` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_filemounts`
--

LOCK TABLES `sys_filemounts` WRITE;
/*!40000 ALTER TABLE `sys_filemounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_filemounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_history`
--

DROP TABLE IF EXISTS `sys_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_history` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `actiontype` smallint(6) NOT NULL DEFAULT 0,
  `usertype` varchar(2) NOT NULL DEFAULT 'BE',
  `userid` int(10) unsigned DEFAULT NULL,
  `originaluserid` int(10) unsigned DEFAULT NULL,
  `recuid` int(11) NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `history_data` mediumtext DEFAULT NULL,
  `workspace` int(11) DEFAULT 0,
  `correlation_id` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `recordident_1` (`tablename`(100),`recuid`),
  KEY `recordident_2` (`tablename`(100),`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_history`
--

LOCK TABLES `sys_history` WRITE;
/*!40000 ALTER TABLE `sys_history` DISABLE KEYS */;
INSERT INTO `sys_history` VALUES (1,1685605795,1,'BE',1,0,1,'pages','{\"uid\":1,\"pid\":0,\"tstamp\":1685605795,\"crdate\":1685605795,\"deleted\":0,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"fe_group\":\"0\",\"sorting\":256,\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"title\":\"Timelog dev site\",\"doktype\":1,\"TSconfig\":null,\"is_siteroot\":0,\"php_tree_stop\":0,\"url\":\"\",\"shortcut\":0,\"shortcut_mode\":0,\"subtitle\":\"\",\"layout\":0,\"target\":\"\",\"media\":0,\"keywords\":null,\"cache_timeout\":0,\"cache_tags\":\"\",\"description\":null,\"no_search\":0,\"SYS_LASTCHANGED\":0,\"abstract\":null,\"module\":\"\",\"extendToSubpages\":0,\"author\":\"\",\"author_email\":\"\",\"nav_title\":\"\",\"nav_hide\":0,\"content_from_pid\":0,\"mount_pid\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":null,\"categories\":0,\"lastUpdated\":0,\"newUntil\":0,\"slug\":\"\\/\",\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"og_title\":\"\",\"og_description\":null,\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":null,\"twitter_image\":0,\"twitter_card\":\"summary\",\"canonical_link\":\"\",\"sitemap_priority\":\"0.5\",\"sitemap_changefreq\":\"\",\"tx_impexp_origuid\":0,\"nav_icon_set\":\"\",\"nav_icon_identifier\":\"\",\"nav_icon\":0,\"thumbnail\":0,\"tx_pizpalue_background_image\":0,\"tx_pizpalue_css\":null}',0,'0400$b2fed2865756140d6d5070d12c328569:e175f7045d7ccbfb26ffcf279422c2e5'),(2,1685605800,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$292bfdbc45ea0557b9e64dbd140769d4:e175f7045d7ccbfb26ffcf279422c2e5'),(3,1685605813,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"is_siteroot\":0,\"fe_group\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"is_siteroot\":\"1\",\"fe_group\":\"\",\"l10n_diffsource\":\"{\\\"doktype\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"nav_icon_set\\\":\\\"\\\",\\\"nav_icon\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"tx_pizpalue_background_image\\\":\\\"\\\",\\\"thumbnail\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"tx_pizpalue_css\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"TSconfig\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$e2a66986eacc5ade9d15b191f262911b:e175f7045d7ccbfb26ffcf279422c2e5'),(4,1685605824,1,'BE',1,0,1,'sys_template','{\"uid\":1,\"pid\":1,\"tstamp\":1685605824,\"crdate\":1685605824,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"sorting\":256,\"description\":null,\"t3_origuid\":0,\"title\":\"NEW SITE\",\"root\":1,\"clear\":3,\"include_static_file\":null,\"constants\":null,\"config\":\"\\n# Default PAGE object:\\npage = PAGE\\npage.10 = TEXT\\npage.10.value = HELLO WORLD!\\n\",\"basedOn\":\"\",\"includeStaticAfterBasedOn\":0,\"static_file_mode\":0,\"tx_impexp_origuid\":0}',0,'0400$4c639abd18607bebf82df5a2abc4ccf3:35af6288617af54964e77af08c30949a'),(5,1685605831,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"config\":\"\\n# Default PAGE object:\\npage = PAGE\\npage.10 = TEXT\\npage.10.value = HELLO WORLD!\\n\"},\"newRecord\":{\"config\":\"\\r\\n\"}}',0,'0400$fbf53627ecaca4e50f1d59afc1f76b65:35af6288617af54964e77af08c30949a'),(6,1685605850,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"config\":\"\\r\\n\",\"include_static_file\":null},\"newRecord\":{\"config\":\"\",\"include_static_file\":\"EXT:bootstrap_package\\/Configuration\\/TypoScript,EXT:pizpalue\\/Configuration\\/TypoScript\\/Main,EXT:timelog\\/Configuration\\/TypoScript\"}}',0,'0400$ddd8ecab2c5046e91f5e8183b1a3ef23:35af6288617af54964e77af08c30949a'),(7,1685605869,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout\":\"\",\"backend_layout_next_level\":\"\"},\"newRecord\":{\"backend_layout\":\"pagets__default\",\"backend_layout_next_level\":\"pagets__default\"}}',0,'0400$b1de38b339d8457ff0a0757219419e89:e175f7045d7ccbfb26ffcf279422c2e5'),(8,1685605891,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout\":\"pagets__default\",\"backend_layout_next_level\":\"pagets__default\"},\"newRecord\":{\"backend_layout\":\"pagets__simple\",\"backend_layout_next_level\":\"pagets__simple\"}}',0,'0400$06d3b2f61aba2617796176d7f8cb1b23:e175f7045d7ccbfb26ffcf279422c2e5'),(9,1685614460,1,'BE',1,0,2,'pages','{\"uid\":2,\"pid\":1,\"tstamp\":1685614460,\"crdate\":1685614460,\"deleted\":0,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"fe_group\":\"0\",\"sorting\":256,\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"title\":\"Users\",\"doktype\":254,\"TSconfig\":null,\"is_siteroot\":0,\"php_tree_stop\":0,\"url\":\"\",\"shortcut\":0,\"shortcut_mode\":0,\"subtitle\":\"\",\"layout\":0,\"target\":\"\",\"media\":0,\"keywords\":null,\"cache_timeout\":0,\"cache_tags\":\"\",\"description\":null,\"no_search\":0,\"SYS_LASTCHANGED\":0,\"abstract\":null,\"module\":\"\",\"extendToSubpages\":0,\"author\":\"\",\"author_email\":\"\",\"nav_title\":\"\",\"nav_hide\":0,\"content_from_pid\":0,\"mount_pid\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":null,\"categories\":0,\"lastUpdated\":0,\"newUntil\":0,\"slug\":\"\\/users\",\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"og_title\":\"\",\"og_description\":null,\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":null,\"twitter_image\":0,\"twitter_card\":\"summary\",\"canonical_link\":\"\",\"sitemap_priority\":\"0.5\",\"sitemap_changefreq\":\"\",\"tx_impexp_origuid\":0,\"nav_icon_set\":\"\",\"nav_icon_identifier\":\"\",\"nav_icon\":0,\"thumbnail\":0,\"tx_pizpalue_background_image\":0,\"tx_pizpalue_css\":null}',0,'0400$dbcf7791409b51d9730352cb3e030d5d:f11830df10b4b0bca2db34810c2241b3'),(10,1685614488,2,'BE',1,0,2,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$b5fdb1c2d97d4d2a67a6f245f2bdf626:f11830df10b4b0bca2db34810c2241b3'),(11,1685614562,1,'BE',1,0,1,'fe_groups','{\"uid\":1,\"pid\":2,\"tstamp\":1685614562,\"crdate\":1685614562,\"deleted\":0,\"hidden\":0,\"description\":\"\",\"tx_extbase_type\":\"0\",\"title\":\"All\",\"subgroup\":\"\",\"TSconfig\":\"\",\"felogin_redirectPid\":\"\"}',0,'0400$122dfb1be5d11980af73ad8bb81d14ac:74fdbe61b0d9932f32a509c1ca766543'),(12,1685614585,1,'BE',1,0,1,'fe_users','{\"uid\":1,\"pid\":2,\"tstamp\":1685614585,\"crdate\":1685614585,\"deleted\":0,\"disable\":0,\"starttime\":0,\"endtime\":0,\"description\":\"\",\"tx_extbase_type\":\"0\",\"lastlogin\":0,\"username\":\"worker1\",\"password\":\"$argon2i$v=19$m=65536,t=16,p=1$cTF0eE43Nnd1Sk8zYzJ6Lg$8lPU9OkrcevUiC64hDiDbj6670IAoNsiRGJSGciii6g\",\"usergroup\":\"1\",\"name\":\"\",\"first_name\":\"\",\"middle_name\":\"\",\"last_name\":\"\",\"address\":\"\",\"telephone\":\"\",\"fax\":\"\",\"email\":\"\",\"uc\":null,\"title\":\"\",\"zip\":\"\",\"city\":\"\",\"country\":\"\",\"www\":\"\",\"company\":\"\",\"image\":null,\"TSconfig\":\"\",\"is_online\":0,\"mfa\":null,\"felogin_redirectPid\":\"\",\"felogin_forgotHash\":\"\",\"tx_timelog_owner_email\":\"\"}',0,'0400$94fd2914c3ecc1e951eefb5e7bc5fd29:237e89c1b2a56068427543279fe1982e'),(13,1685614608,2,'BE',1,0,1,'fe_users','{\"oldRecord\":{\"password\":\"$argon2i$v=19$m=65536,t=16,p=1$cTF0eE43Nnd1Sk8zYzJ6Lg$8lPU9OkrcevUiC64hDiDbj6670IAoNsiRGJSGciii6g\",\"image\":null},\"newRecord\":{\"password\":\"$argon2i$v=19$m=65536,t=16,p=1$NXpaRTJFYnF0eHY0b1g4aw$39qBPUvomYoC3FdUA0RkY8ptlbVYTjygogmRC90DAWA\",\"image\":0}}',0,'0400$4ba60591a506f611609534f2a5c83a4f:237e89c1b2a56068427543279fe1982e'),(14,1685614629,1,'BE',1,0,2,'fe_users','{\"uid\":2,\"pid\":2,\"tstamp\":1685614629,\"crdate\":1685614629,\"deleted\":0,\"disable\":0,\"starttime\":0,\"endtime\":0,\"description\":\"\",\"tx_extbase_type\":\"0\",\"lastlogin\":0,\"username\":\"worker2\",\"password\":\"$argon2i$v=19$m=65536,t=16,p=1$UkE1d29SMEtSSzV4VzNmcg$niigLr92mpBBH+X2Bri+gqcry1cox3+nxQuZPOvz+aI\",\"usergroup\":\"1\",\"name\":\"\",\"first_name\":\"\",\"middle_name\":\"\",\"last_name\":\"\",\"address\":\"\",\"telephone\":\"\",\"fax\":\"\",\"email\":\"\",\"uc\":null,\"title\":\"\",\"zip\":\"\",\"city\":\"\",\"country\":\"\",\"www\":\"\",\"company\":\"\",\"image\":null,\"TSconfig\":\"\",\"is_online\":0,\"mfa\":null,\"felogin_redirectPid\":\"\",\"felogin_forgotHash\":\"\",\"tx_timelog_owner_email\":\"\"}',0,'0400$c6d97d326aeb779b45e30f714a72447f:3f083a6a2d15ee54bb50505f181f8201'),(15,1685614653,1,'BE',1,0,3,'pages','{\"uid\":3,\"pid\":1,\"tstamp\":1685614653,\"crdate\":1685614653,\"deleted\":0,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"fe_group\":\"0\",\"sorting\":128,\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"title\":\"Timelog\",\"doktype\":254,\"TSconfig\":null,\"is_siteroot\":0,\"php_tree_stop\":0,\"url\":\"\",\"shortcut\":0,\"shortcut_mode\":0,\"subtitle\":\"\",\"layout\":0,\"target\":\"\",\"media\":0,\"keywords\":null,\"cache_timeout\":0,\"cache_tags\":\"\",\"description\":null,\"no_search\":0,\"SYS_LASTCHANGED\":0,\"abstract\":null,\"module\":\"\",\"extendToSubpages\":0,\"author\":\"\",\"author_email\":\"\",\"nav_title\":\"\",\"nav_hide\":0,\"content_from_pid\":0,\"mount_pid\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":null,\"categories\":0,\"lastUpdated\":0,\"newUntil\":0,\"slug\":\"\\/timelog\",\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"og_title\":\"\",\"og_description\":null,\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":null,\"twitter_image\":0,\"twitter_card\":\"summary\",\"canonical_link\":\"\",\"sitemap_priority\":\"0.5\",\"sitemap_changefreq\":\"\",\"tx_impexp_origuid\":0,\"nav_icon_set\":\"\",\"nav_icon_identifier\":\"\",\"nav_icon\":0,\"thumbnail\":0,\"tx_pizpalue_background_image\":0,\"tx_pizpalue_css\":null}',0,'0400$49a01c14cd143b4107f4be926e83c8d6:fe15eeb7d49e64e2cea91ab53fcf0db1'),(16,1685614660,2,'BE',1,0,3,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$14ff0977328ad27ed24d8e7d57bfd1b9:fe15eeb7d49e64e2cea91ab53fcf0db1'),(17,1685614704,1,'BE',1,0,1,'tx_timelog_domain_model_task','{\"uid\":1,\"pid\":3,\"tstamp\":1685614704,\"crdate\":1685614704,\"deleted\":0,\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"handle\":\"\",\"title\":\"\",\"description\":\"\",\"active_time\":0,\"batch_date\":0,\"project\":0,\"worker\":1,\"task_group\":0,\"intervals\":0}',0,'0400$17236fef0fcbc31714786023d9975689:5b1b8c29cdf8caac2c60e44caac64098'),(18,1685614704,1,'BE',1,0,1,'tx_timelog_domain_model_interval','{\"uid\":1,\"pid\":3,\"tstamp\":1685614704,\"crdate\":1685614704,\"deleted\":0,\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"task\":0,\"start_time\":1685607420,\"end_time\":1685607480,\"duration\":0}',0,'0400$17236fef0fcbc31714786023d9975689:73a56528dec4f7421d2402a3f5e83294'),(19,1685616346,2,'BE',1,0,1,'tx_timelog_domain_model_interval','{\"oldRecord\":{\"end_time\":1685607480},\"newRecord\":{\"end_time\":1685608020}}',0,'0400$95b74cb523123c7e94dfb4d52bc15541:73a56528dec4f7421d2402a3f5e83294'),(20,1685616397,1,'BE',1,0,2,'tx_timelog_domain_model_task','{\"uid\":2,\"pid\":3,\"tstamp\":1685616397,\"crdate\":1685616397,\"deleted\":0,\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"handle\":\"\",\"title\":\"\",\"description\":\"\",\"active_time\":0,\"batch_date\":0,\"project\":0,\"worker\":2,\"task_group\":0,\"intervals\":0}',0,'0400$5c4bd0ce30aa001eee3ba33bde12465b:01835c40b4c33cbb907545b5df8f4806'),(21,1685616397,1,'BE',1,0,2,'tx_timelog_domain_model_interval','{\"uid\":2,\"pid\":3,\"tstamp\":1685616397,\"crdate\":1685616397,\"deleted\":0,\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"task\":0,\"start_time\":1685612400,\"end_time\":1685612760,\"duration\":0}',0,'0400$5c4bd0ce30aa001eee3ba33bde12465b:a6d90d3a7ca7bae81d59cda3699b4cd6'),(22,1685616546,1,'BE',1,0,1,'tt_content','{\"uid\":1,\"rowDescription\":\"\",\"pid\":1,\"tstamp\":1685616546,\"crdate\":1685616546,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":256,\"editlock\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l18n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"CType\":\"list\",\"header\":\"\",\"header_position\":\"\",\"bodytext\":null,\"bullets_type\":0,\"uploads_description\":0,\"uploads_type\":0,\"assets\":0,\"image\":0,\"imagewidth\":0,\"imageorient\":0,\"imagecols\":1,\"imageborder\":0,\"media\":0,\"layout\":\"0\",\"frame_class\":\"default\",\"cols\":0,\"space_before_class\":\"\",\"space_after_class\":\"\",\"records\":null,\"pages\":\"\",\"colPos\":0,\"subheader\":\"\",\"header_link\":\"\",\"image_zoom\":0,\"header_layout\":\"0\",\"list_type\":\"timelog_taskpanel\",\"sectionIndex\":1,\"linkToTop\":0,\"file_collections\":null,\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"recursive\":0,\"imageheight\":0,\"pi_flexform\":null,\"accessibility_title\":\"\",\"accessibility_bypass\":0,\"accessibility_bypass_text\":\"\",\"category_field\":\"\",\"table_class\":\"\",\"table_caption\":null,\"table_delimiter\":124,\"table_enclosure\":0,\"table_header_position\":0,\"table_tfoot\":0,\"categories\":0,\"selected_categories\":null,\"date\":0,\"tx_impexp_origuid\":0,\"teaser\":null,\"aspect_ratio\":\"1.3333333333333\",\"items_per_page\":10,\"readmore_label\":\"\",\"quote_source\":\"\",\"quote_link\":\"\",\"panel_class\":\"default\",\"file_folder\":null,\"icon\":\"\",\"icon_set\":\"\",\"icon_file\":0,\"icon_position\":\"\",\"icon_size\":\"default\",\"icon_type\":\"default\",\"icon_color\":\"\",\"icon_background\":\"\",\"external_media_source\":\"\",\"external_media_ratio\":\"\",\"tx_bootstrappackage_card_group_item\":0,\"tx_bootstrappackage_carousel_item\":0,\"tx_bootstrappackage_accordion_item\":0,\"tx_bootstrappackage_icon_group_item\":0,\"tx_bootstrappackage_tab_item\":0,\"tx_bootstrappackage_timeline_item\":0,\"frame_layout\":\"default\",\"frame_options\":\"\",\"background_color_class\":\"none\",\"background_image\":0,\"background_image_options\":null,\"tx_pizpalue_header_class\":\"none\",\"tx_pizpalue_subheader_class\":\"none\",\"tx_pizpalue_layout_breakpoint\":\"\",\"tx_pizpalue_inner_space_before_class\":\"\",\"tx_pizpalue_inner_space_after_class\":\"\",\"tx_pizpalue_classes\":\"\",\"tx_pizpalue_inner_classes\":\"\",\"tx_pizpalue_style\":\"\",\"tx_pizpalue_attributes\":\"\",\"tx_pizpalue_animation\":\"0\",\"tx_pizpalue_image_variants\":\"variants\",\"tx_pizpalue_background_image_variants\":\"pageVariants\",\"tx_pizpalue_image_scaling\":\"xxl: 1.0,\\nxl: 1.0,\\nlg: 1.0,\\nmd: 1.0,\\nsm: 1.0,\\nxs: 1.0\",\"tx_pizpalue_image_aspect_ratio\":\"xxl: 0,\\nxl: 0,\\nlg: 0,\\nmd: 0,\\nsm: 0,\\nxs: 0\",\"tx_pizpalue_scroll_navigation_enable\":0,\"tx_pizpalue_scroll_navigation_title\":\"\",\"tx_pizpalue_scroll_navigation_position\":0}',0,'0400$fc8f10291954c60d64ba94cd3d4c6497:7fa2c035f26826fe83eeecaaeddc4d40'),(23,1685617039,2,'BE',1,0,3,'pages','{\"oldRecord\":{\"TSconfig\":null,\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"TSconfig\":\"TCEMAIN.preview {\\r\\n    tx_timelog_domain_model_project {\\r\\n        disableButtonForDokType = 255, 199\\r\\n        previewPageId = 1\\r\\n    }\\r\\n    tx_timelog_domain_model_taskgroup {\\r\\n        disableButtonForDokType = 255, 199\\r\\n        previewPageId = 1\\r\\n    }\\r\\n    tx_timelog_domain_model_task {\\r\\n        disableButtonForDokType = 255, 199\\r\\n        previewPageId = 1\\r\\n    }\\r\\n}\",\"l10n_diffsource\":\"{\\\"doktype\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"TSconfig\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"tx_pizpalue_background_image\\\":\\\"\\\",\\\"tx_pizpalue_css\\\":\\\"\\\"}\"}}',0,'0400$c19ad212283d66f7c191ebca501b40bf:fe15eeb7d49e64e2cea91ab53fcf0db1'),(24,1685617071,2,'BE',1,0,2,'tx_timelog_domain_model_task','{\"oldRecord\":{\"title\":\"\",\"description\":\"\"},\"newRecord\":{\"title\":\"title goes here\",\"description\":\"description goes here\"}}',0,'0400$bf3943f8ddf90c250c76fd3fa16f357d:01835c40b4c33cbb907545b5df8f4806'),(25,1685617146,2,'BE',1,0,1,'tt_content','{\"oldRecord\":{\"pages\":\"\",\"l18n_diffsource\":\"\"},\"newRecord\":{\"pages\":\"3\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"tx_pizpalue_header_class\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_pizpalue_subheader_class\\\":\\\"\\\",\\\"list_type\\\":\\\"\\\",\\\"tx_pizpalue_image_variants\\\":\\\"\\\",\\\"pages\\\":\\\"\\\",\\\"recursive\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"tx_pizpalue_layout_breakpoint\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"frame_layout\\\":\\\"\\\",\\\"frame_options\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"tx_pizpalue_inner_space_before_class\\\":\\\"\\\",\\\"tx_pizpalue_inner_space_after_class\\\":\\\"\\\",\\\"background_color_class\\\":\\\"\\\",\\\"background_image\\\":\\\"\\\",\\\"tx_pizpalue_animation\\\":\\\"\\\",\\\"tx_pizpalue_classes\\\":\\\"\\\",\\\"tx_pizpalue_inner_classes\\\":\\\"\\\",\\\"tx_pizpalue_style\\\":\\\"\\\",\\\"tx_pizpalue_attributes\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"tx_pizpalue_scroll_navigation_enable\\\":\\\"\\\",\\\"tx_pizpalue_scroll_navigation_title\\\":\\\"\\\",\\\"tx_pizpalue_scroll_navigation_position\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$93bda569e874c6e7baf5a2b7b9d15f9e:7fa2c035f26826fe83eeecaaeddc4d40'),(26,1685617189,2,'BE',1,0,1,'tx_timelog_domain_model_task','{\"oldRecord\":{\"title\":\"\",\"description\":\"\"},\"newRecord\":{\"title\":\"title goes here\",\"description\":\"description goes here\"}}',0,'0400$620cd2891821e14bf65b579b346c54f8:5b1b8c29cdf8caac2c60e44caac64098'),(27,1685618901,1,'BE',1,0,1,'tx_timelog_domain_model_taskgroup','{\"uid\":1,\"pid\":3,\"tstamp\":1685618901,\"crdate\":1685618901,\"deleted\":0,\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"handle\":\"\",\"title\":\"task group 1\",\"description\":\"description from task group 1\",\"internal_note\":\"\",\"time_target\":0,\"time_deviation\":0,\"active_time\":0,\"heap_time\":0,\"batch_time\":0,\"project\":0,\"tasks\":0}',0,'0400$173d014f38d6d50756ae8e649e8bd484:2e5a9a4ea2135b751c6385b1c016a6c5'),(28,1685619000,2,'BE',1,0,1,'tx_timelog_domain_model_taskgroup','{\"oldRecord\":{\"time_target\":0},\"newRecord\":{\"time_target\":\"0.00\"}}',0,'0400$2020a4576c7f36c0ba74566f7e5daa6d:2e5a9a4ea2135b751c6385b1c016a6c5'),(29,1685619143,2,'BE',1,0,1,'tx_timelog_domain_model_taskgroup','{\"oldRecord\":{\"time_target\":0},\"newRecord\":{\"time_target\":\"0.00\"}}',0,'0400$6f7f31181e54241249fb08b6f7bf16c6:2e5a9a4ea2135b751c6385b1c016a6c5'),(30,1685619181,2,'BE',1,0,2,'tx_timelog_domain_model_task','{\"oldRecord\":{\"task_group\":0},\"newRecord\":{\"task_group\":\"1\"}}',0,'0400$79f0d733f20374c89a118055c6cb1446:01835c40b4c33cbb907545b5df8f4806'),(31,1685619211,2,'BE',1,0,1,'tx_timelog_domain_model_task','{\"oldRecord\":{\"task_group\":0},\"newRecord\":{\"task_group\":\"1\"}}',0,'0400$161b8ffb07bb6efad93d5821159024d7:5b1b8c29cdf8caac2c60e44caac64098'),(32,1685619274,1,'BE',1,0,1,'tx_timelog_domain_model_project','{\"uid\":1,\"pid\":3,\"tstamp\":1685619274,\"crdate\":1685619274,\"deleted\":0,\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"handle\":\"\",\"title\":\"project 1\",\"description\":\"description from project 1\",\"internal_note\":\"\",\"active_time\":0,\"heap_time\":0,\"batch_time\":0,\"client\":0,\"owner\":0,\"cc_email\":\"\",\"tasks\":0,\"task_groups\":0}',0,'0400$16aeba7800b5b2fecebb0283ffc31dd0:f4a1a31fdc9b2106a014c54eae29ec98'),(33,1685619480,2,'BE',1,0,1,'tx_timelog_domain_model_taskgroup','{\"oldRecord\":{\"time_target\":0,\"tasks\":0},\"newRecord\":{\"time_target\":\"0.00\",\"tasks\":2}}',0,'0400$5b2a9e5a196932992f28e72e0ac3c51a:2e5a9a4ea2135b751c6385b1c016a6c5'),(34,1685619593,2,'BE',1,0,2,'tx_timelog_domain_model_task','{\"oldRecord\":{\"project\":0},\"newRecord\":{\"project\":\"1\"}}',0,'0400$6b770f8045dcb778d80baa1e13e81bc2:01835c40b4c33cbb907545b5df8f4806'),(35,1685619597,2,'BE',1,0,2,'tx_timelog_domain_model_task','{\"oldRecord\":{\"task_group\":1},\"newRecord\":{\"task_group\":0}}',0,'0400$87a377af926f5056c0b88819f6940d6a:01835c40b4c33cbb907545b5df8f4806'),(36,1685619673,2,'BE',1,0,1,'tx_timelog_domain_model_project','{\"oldRecord\":{\"tasks\":0},\"newRecord\":{\"tasks\":1}}',0,'0400$1d23bfa8c515a8d6724e538ef247d28e:f4a1a31fdc9b2106a014c54eae29ec98'),(37,1685619673,1,'BE',1,0,2,'tx_timelog_domain_model_taskgroup','{\"uid\":2,\"pid\":3,\"tstamp\":1685619673,\"crdate\":1685619673,\"deleted\":0,\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"handle\":\"\",\"title\":\"task group 2\",\"description\":\"description from task group 2\",\"internal_note\":\"\",\"time_target\":0,\"time_deviation\":0,\"active_time\":0,\"heap_time\":0,\"batch_time\":0,\"project\":0,\"tasks\":0}',0,'0400$1d23bfa8c515a8d6724e538ef247d28e:b74200366405cd81bcfc60f455930d55'),(38,1685619673,2,'BE',1,0,1,'tx_timelog_domain_model_project','{\"oldRecord\":{\"tasks\":0},\"newRecord\":{\"tasks\":1}}',0,'0400$1d23bfa8c515a8d6724e538ef247d28e:f4a1a31fdc9b2106a014c54eae29ec98'),(39,1685619710,2,'BE',1,0,1,'tx_timelog_domain_model_task','{\"oldRecord\":{\"project\":0},\"newRecord\":{\"project\":\"1\"}}',0,'0400$650298eb109121006e4f6c76f8f1c50a:5b1b8c29cdf8caac2c60e44caac64098'),(40,1685619845,2,'BE',1,0,1,'tx_timelog_domain_model_task','{\"oldRecord\":{\"task_group\":1},\"newRecord\":{\"task_group\":0}}',0,'0400$09979db71f164bd3c029c45bf0a1c25d:5b1b8c29cdf8caac2c60e44caac64098'),(41,1685619933,1,'BE',1,0,3,'fe_users','{\"uid\":3,\"pid\":2,\"tstamp\":1685619933,\"crdate\":1685619933,\"deleted\":0,\"disable\":0,\"starttime\":0,\"endtime\":0,\"description\":\"\",\"tx_extbase_type\":\"0\",\"lastlogin\":0,\"username\":\"owner1\",\"password\":\"$argon2i$v=19$m=65536,t=16,p=1$T2QzeWNPRzVHTjlodFhiTQ$t08GCDJIZ\\/LOaFjUzRSnyhgpsB2E+RBOuZLxdyROChY\",\"usergroup\":\"1\",\"name\":\"owner 1\",\"first_name\":\"\",\"middle_name\":\"\",\"last_name\":\"\",\"address\":\"\",\"telephone\":\"\",\"fax\":\"\",\"email\":\"owner1@timelog.ddev.site\",\"uc\":null,\"title\":\"\",\"zip\":\"\",\"city\":\"\",\"country\":\"\",\"www\":\"\",\"company\":\"owner 1 gmbh\",\"image\":null,\"TSconfig\":\"\",\"is_online\":0,\"mfa\":null,\"felogin_redirectPid\":\"\",\"felogin_forgotHash\":\"\",\"tx_timelog_owner_email\":\"\"}',0,'0400$288b4155b276dcb356ad065f932cc1e8:4f8ae03a7dbbb7f1150f97ab3fdd7687'),(42,1685619947,2,'BE',1,0,3,'fe_users','{\"oldRecord\":{\"password\":\"$argon2i$v=19$m=65536,t=16,p=1$T2QzeWNPRzVHTjlodFhiTQ$t08GCDJIZ\\/LOaFjUzRSnyhgpsB2E+RBOuZLxdyROChY\",\"image\":null},\"newRecord\":{\"password\":\"$argon2i$v=19$m=65536,t=16,p=1$TlF3T29LbEZCM1psdFExSg$IECdlEUaBZOFa0p64a2wxqOPTeEXl3fetXYx2uk+DFk\",\"image\":0}}',0,'0400$c0fe5d8668fef5db6c4e501989521191:4f8ae03a7dbbb7f1150f97ab3fdd7687'),(43,1685619995,1,'BE',1,0,4,'fe_users','{\"uid\":4,\"pid\":2,\"tstamp\":1685619995,\"crdate\":1685619995,\"deleted\":0,\"disable\":0,\"starttime\":0,\"endtime\":0,\"description\":\"\",\"tx_extbase_type\":\"0\",\"lastlogin\":0,\"username\":\"customer1\",\"password\":\"$argon2i$v=19$m=65536,t=16,p=1$TjdNWnR2RjNtdVMweGhHaA$+ELqKaeuKoTy7pk3kBRBm4lFYsGyzu4PE2P5yRMWpYM\",\"usergroup\":\"1\",\"name\":\"\",\"first_name\":\"customer 1\",\"middle_name\":\"\",\"last_name\":\"\",\"address\":\"\",\"telephone\":\"\",\"fax\":\"\",\"email\":\"customer1@timelog.ddev.site\",\"uc\":null,\"title\":\"\",\"zip\":\"\",\"city\":\"\",\"country\":\"\",\"www\":\"\",\"company\":\"customer 1 gmbh\",\"image\":null,\"TSconfig\":\"\",\"is_online\":0,\"mfa\":null,\"felogin_redirectPid\":\"\",\"felogin_forgotHash\":\"\",\"tx_timelog_owner_email\":\"\"}',0,'0400$11af28f4871634fa3747a275dfa9b51c:537abf8b65196b0831af30b1f3b9747f'),(44,1685630812,2,'BE',1,0,1,'tx_timelog_domain_model_project','{\"oldRecord\":{\"tasks\":1},\"newRecord\":{\"tasks\":2}}',0,'0400$9a059a62be97314ea9b96e161be2db9e:f4a1a31fdc9b2106a014c54eae29ec98'),(45,1685632618,2,'BE',1,0,1,'tx_timelog_domain_model_project','{\"oldRecord\":{\"client\":0,\"owner\":0},\"newRecord\":{\"client\":\"4\",\"owner\":\"3\"}}',0,'0400$435191f1a35167de301999aedb1ba716:f4a1a31fdc9b2106a014c54eae29ec98'),(46,1685633577,1,'BE',1,0,3,'tx_timelog_domain_model_task','{\"uid\":3,\"pid\":3,\"tstamp\":1685633577,\"crdate\":1685633577,\"deleted\":0,\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"handle\":\"\",\"title\":\"\",\"description\":\"\",\"active_time\":0,\"batch_date\":0,\"project\":0,\"worker\":2,\"task_group\":0,\"intervals\":0}',0,'0400$6e229dd81f8dbc4d2ac5cf290db3f325:fbcf4d73a416dfc0842ed6e373625608'),(47,1685633594,4,'BE',1,0,3,'tx_timelog_domain_model_task',NULL,0,'0400$b0f7dd365d9c428699ce8a6878e84eff:fbcf4d73a416dfc0842ed6e373625608'),(48,1685689229,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":null},\"newRecord\":{\"constants\":\"\\nplugin.tx_timelog_taskpanel.persistence.storagePid = 3\"}}',0,'0400$23359d11d6e644d6f2cd572c3ad245ea:35af6288617af54964e77af08c30949a'),(49,1685706158,2,'BE',1,0,2,'tx_timelog_domain_model_task','{\"oldRecord\":{\"task_group\":0},\"newRecord\":{\"task_group\":\"2\"}}',0,'0400$e3f2383faf31f7bd6b21ced42b9177dc:01835c40b4c33cbb907545b5df8f4806'),(50,1685726392,2,'BE',1,0,1,'tx_timelog_domain_model_project','{\"oldRecord\":{\"description\":\"description from project 1\"},\"newRecord\":{\"description\":\"description from project 1\\r\\nrow2\\r\\n\\r\\nrow4\"}}',0,'0400$00a9ab3614545da9d641675663ed98b7:f4a1a31fdc9b2106a014c54eae29ec98'),(51,1685726457,2,'BE',1,0,1,'tx_timelog_domain_model_project','{\"oldRecord\":{\"description\":\"description from project 1\\r\\nrow2\\r\\n\\r\\nrow4\"},\"newRecord\":{\"description\":\"description from project 1:\\r\\n- row2\\r\\n\\r\\nrow4\"}}',0,'0400$418fcfde7b633f16b116db41a8e72c69:f4a1a31fdc9b2106a014c54eae29ec98'),(52,1685727116,2,'BE',1,0,1,'tx_timelog_domain_model_project','{\"oldRecord\":{\"description\":\"description from project 1:\\r\\n- row2\\r\\n\\r\\nrow4\"},\"newRecord\":{\"description\":\"description from project 1:\\r\\n- [row2](https:\\/\\/www.buechler.pro)\\r\\n\\r\\nrow4\"}}',0,'0400$5ecd9d74e6409cbcedbb0e22814375ac:f4a1a31fdc9b2106a014c54eae29ec98'),(53,1685727140,2,'BE',1,0,1,'tx_timelog_domain_model_project','{\"oldRecord\":{\"description\":\"description from project 1:\\r\\n- [row2](https:\\/\\/www.buechler.pro)\\r\\n\\r\\nrow4\"},\"newRecord\":{\"description\":\"description from project 1:\\r\\n- www.buechler.pro\\r\\n\\r\\nrow4\"}}',0,'0400$93c9ea6ac0f5c5f5d938a8220f3b2ae7:f4a1a31fdc9b2106a014c54eae29ec98'),(54,1685727162,2,'BE',1,0,1,'tx_timelog_domain_model_project','{\"oldRecord\":{\"description\":\"description from project 1:\\r\\n- www.buechler.pro\\r\\n\\r\\nrow4\"},\"newRecord\":{\"description\":\"description from project 1:\\r\\n- buechler.pro\\r\\n\\r\\nrow4\"}}',0,'0400$05d8bf6e648f59a37f25f4fc7f9197ca:f4a1a31fdc9b2106a014c54eae29ec98'),(55,1685727180,2,'BE',1,0,1,'tx_timelog_domain_model_project','{\"oldRecord\":{\"description\":\"description from project 1:\\r\\n- buechler.pro\\r\\n\\r\\nrow4\"},\"newRecord\":{\"description\":\"description from project 1\"}}',0,'0400$fead29ebfdcd50631e67c6b879072dbf:f4a1a31fdc9b2106a014c54eae29ec98'),(56,1685727434,2,'BE',1,0,1,'tx_timelog_domain_model_project','{\"oldRecord\":{\"description\":\"description from project 1\"},\"newRecord\":{\"description\":\"description from project 1\\r\\nrow2\\r\\n\\r\\nrow4\"}}',0,'0400$ac407f58d910a23ee3b1ee4da1bbb179:f4a1a31fdc9b2106a014c54eae29ec98'),(57,1685728213,2,'BE',1,0,1,'tx_timelog_domain_model_project','{\"oldRecord\":{\"description\":\"description from project 1\\r\\nrow2\\r\\n\\r\\nrow4\"},\"newRecord\":{\"description\":\"description from project 1  \\r\\nrow2\\r\\n\\r\\nrow4\"}}',0,'0400$7d02abede56e00d02391043c0b211fcb:f4a1a31fdc9b2106a014c54eae29ec98');
/*!40000 ALTER TABLE `sys_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_http_report`
--

DROP TABLE IF EXISTS `sys_http_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_http_report` (
  `uuid` varchar(36) NOT NULL,
  `status` smallint(5) unsigned NOT NULL DEFAULT 0,
  `created` int(10) unsigned NOT NULL,
  `changed` int(10) unsigned NOT NULL,
  `type` varchar(32) NOT NULL,
  `scope` varchar(32) NOT NULL,
  `request_time` bigint(20) unsigned NOT NULL,
  `meta` mediumtext DEFAULT NULL,
  `details` mediumtext DEFAULT NULL,
  `summary` varchar(40) NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `type_scope` (`type`,`scope`),
  KEY `created` (`created`),
  KEY `changed` (`changed`),
  KEY `request_time` (`request_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_http_report`
--

LOCK TABLES `sys_http_report` WRITE;
/*!40000 ALTER TABLE `sys_http_report` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_http_report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_lockedrecords`
--

DROP TABLE IF EXISTS `sys_lockedrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_lockedrecords` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `record_table` varchar(255) NOT NULL DEFAULT '',
  `record_uid` int(11) NOT NULL DEFAULT 0,
  `record_pid` int(11) NOT NULL DEFAULT 0,
  `username` varchar(50) NOT NULL DEFAULT '',
  `feuserid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_lockedrecords`
--

LOCK TABLES `sys_lockedrecords` WRITE;
/*!40000 ALTER TABLE `sys_lockedrecords` DISABLE KEYS */;
INSERT INTO `sys_lockedrecords` VALUES (117,1,1689050278,'tx_timelog_domain_model_project',1,0,'admin',0);
/*!40000 ALTER TABLE `sys_lockedrecords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_log`
--

DROP TABLE IF EXISTS `sys_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_log` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `action` smallint(5) unsigned NOT NULL DEFAULT 0,
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `recpid` int(11) NOT NULL DEFAULT 0,
  `error` smallint(5) unsigned NOT NULL DEFAULT 0,
  `details` text DEFAULT NULL,
  `type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `channel` varchar(20) NOT NULL DEFAULT 'default',
  `details_nr` smallint(6) NOT NULL DEFAULT 0,
  `IP` varchar(39) NOT NULL DEFAULT '',
  `log_data` text DEFAULT NULL,
  `event_pid` int(11) NOT NULL DEFAULT -1,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `NEWid` varchar(30) NOT NULL DEFAULT '',
  `request_id` varchar(13) NOT NULL DEFAULT '',
  `time_micro` double NOT NULL DEFAULT 0,
  `component` varchar(255) NOT NULL DEFAULT '',
  `level` varchar(10) NOT NULL DEFAULT 'info',
  `message` text DEFAULT NULL,
  `data` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`event_pid`),
  KEY `recuidIdx` (`recuid`),
  KEY `user_auth` (`type`,`action`,`tstamp`),
  KEY `request` (`request_id`),
  KEY `combined_1` (`tstamp`,`type`,`userid`),
  KEY `errorcount` (`tstamp`,`error`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=147 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_log`
--

LOCK TABLES `sys_log` WRITE;
/*!40000 ALTER TABLE `sys_log` DISABLE KEYS */;
INSERT INTO `sys_log` VALUES (1,0,1685605751,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.6','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(2,0,1685605795,1,1,1,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.6','{\"title\":\"Timelog dev site\",\"table\":\"pages\",\"uid\":1,\"pageTitle\":\"[root-level]\",\"pid\":0}',0,0,'NEW_1','',0,'','info',NULL,NULL),(3,0,1685605800,1,2,1,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.6','{\"title\":\"Timelog dev site\",\"table\":\"pages\",\"uid\":1,\"history\":\"2\"}',1,0,'','',0,'','info',NULL,NULL),(4,0,1685605813,1,2,1,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.6','{\"title\":\"Timelog dev site\",\"table\":\"pages\",\"uid\":1,\"history\":\"3\"}',1,0,'','',0,'','info',NULL,NULL),(5,0,1685605824,1,1,1,'sys_template',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.6','{\"title\":\"NEW SITE\",\"table\":\"sys_template\",\"uid\":1,\"pageTitle\":\"Timelog dev site\",\"pid\":1}',1,0,'NEW','',0,'','info',NULL,NULL),(6,0,1685605831,1,2,1,'sys_template',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.6','{\"title\":\"NEW SITE\",\"table\":\"sys_template\",\"uid\":1,\"history\":\"5\"}',1,0,'','',0,'','info',NULL,NULL),(7,0,1685605850,1,2,1,'sys_template',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.6','{\"title\":\"NEW SITE\",\"table\":\"sys_template\",\"uid\":1,\"history\":\"6\"}',1,0,'','',0,'','info',NULL,NULL),(8,0,1685605869,1,2,1,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.6','{\"title\":\"Timelog dev site\",\"table\":\"pages\",\"uid\":1,\"history\":\"7\"}',1,0,'','',0,'','info',NULL,NULL),(9,0,1685605891,1,2,1,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.6','{\"title\":\"Timelog dev site\",\"table\":\"pages\",\"uid\":1,\"history\":\"8\"}',1,0,'','',0,'','info',NULL,NULL),(10,0,1685606128,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1476107295: PHP Warning: Undefined property: PhpParser\\Node\\Expr\\ArrayDimFetch::$name in /var/www/html/.build/public/typo3/sysext/install/Classes/ExtensionScanner/Php/Matcher/InterfaceMethodChangedMatcher.php line 85 | TYPO3\\CMS\\Core\\Error\\Exception thrown in file /var/www/html/.build/public/typo3/sysext/core/Classes/Error/ErrorHandler.php in line 138. Requested URL: https://timelog.ddev.site/typo3/install.php?install[controller]=upgrade&install[context]=backend',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(11,0,1685607033,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),(12,0,1685607071,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),(13,0,1685607140,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),(14,0,1685607586,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),(15,0,1685608211,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),(16,0,1685608600,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),(17,0,1685611456,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1054: An exception occurred while executing a query: Unknown column \'cruser_id\' in \'where clause\' | Doctrine\\DBAL\\Exception\\InvalidFieldNameException thrown in file /var/www/html/.build/vendor/doctrine/dbal/src/Driver/API/MySQL/ExceptionConverter.php in line 67. Requested URL: https://timelog.ddev.site/typo3/record/edit?token=--AnonymizedToken--&edit%%5Btx_timelog_domain_model_task%%5D%%5B1%%5D=new&returnUrl=/typo3/module/web/list?token%%3D--AnonymizedToken--%%26id%%3D1%%26table%%3D%%26pointer%%3D1',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(18,0,1685614460,1,1,2,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.6','{\"title\":\"Users\",\"table\":\"pages\",\"uid\":2,\"pageTitle\":\"Timelog dev site\",\"pid\":1}',1,0,'NEW_1','',0,'','info',NULL,NULL),(19,0,1685614488,1,2,2,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.6','{\"title\":\"Users\",\"table\":\"pages\",\"uid\":2,\"history\":\"10\"}',2,0,'','',0,'','info',NULL,NULL),(20,0,1685614562,1,1,1,'fe_groups',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.6','{\"title\":\"All\",\"table\":\"fe_groups\",\"uid\":1,\"pageTitle\":\"Users\",\"pid\":2}',2,0,'NEW64786fda7cdb9818352180','',0,'','info',NULL,NULL),(21,0,1685614585,1,2,0,'fe_users',0,4,'Password not saved ({table}:{uid}): The password must at least contain one upper case char',1,'content',-1,'172.18.0.6','{\"table\":\"fe_users\",\"uid\":\"NEW64786fe876907448791986\"}',2,0,'','',0,'','info',NULL,NULL),(22,0,1685614585,1,1,1,'fe_users',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.6','{\"title\":\"worker1\",\"table\":\"fe_users\",\"uid\":1,\"pageTitle\":\"Users\",\"pid\":2}',2,0,'NEW64786fe876907448791986','',0,'','info',NULL,NULL),(23,0,1685614608,1,2,1,'fe_users',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.6','{\"title\":\"worker1\",\"table\":\"fe_users\",\"uid\":1,\"history\":\"13\"}',2,0,'','',0,'','info',NULL,NULL),(24,0,1685614629,1,1,2,'fe_users',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.6','{\"title\":\"worker2\",\"table\":\"fe_users\",\"uid\":2,\"pageTitle\":\"Users\",\"pid\":2}',2,0,'NEW6478701571fed408072145','',0,'','info',NULL,NULL),(25,0,1685614653,1,1,3,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.6','{\"title\":\"Timelog\",\"table\":\"pages\",\"uid\":3,\"pageTitle\":\"Timelog dev site\",\"pid\":1}',1,0,'NEW_1','',0,'','info',NULL,NULL),(26,0,1685614660,1,2,3,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.6','{\"title\":\"Timelog\",\"table\":\"pages\",\"uid\":3,\"history\":\"16\"}',3,0,'','',0,'','info',NULL,NULL),(27,0,1685614704,1,1,1,'tx_timelog_domain_model_task',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.6','{\"title\":\"0.0\",\"table\":\"tx_timelog_domain_model_task\",\"uid\":1,\"pageTitle\":\"Timelog\",\"pid\":3}',3,0,'NEW6478704c65eb9852947870','',0,'','info',NULL,NULL),(28,0,1685614704,1,1,1,'tx_timelog_domain_model_interval',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.6','{\"title\":\"[No title]\",\"table\":\"tx_timelog_domain_model_interval\",\"uid\":1,\"pageTitle\":\"Timelog\",\"pid\":3}',3,0,'NEW6478704cd6df9817510422','',0,'','info',NULL,NULL),(29,0,1685614704,1,2,1,'tx_timelog_domain_model_task',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.6','{\"title\":\"0.0\",\"table\":\"tx_timelog_domain_model_task\",\"uid\":1,\"history\":0}',3,0,'','',0,'','info',NULL,NULL),(30,0,1685614704,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Call to a member function dispatch() on null | Error thrown in file /var/www/html/Classes/Domain/Model/Task.php in line 143. Requested URL: https://timelog.ddev.site/typo3/record/edit?token=--AnonymizedToken--&edit%%5Btx_timelog_domain_model_task%%5D%%5B3%%5D=new&returnUrl=%%2Ftypo3%%2Fmodule%%2Fweb%%2Flist%%3Ftoken%%3D--AnonymizedToken--%%26id%%3D3%%26table%%3D%%26pointer%%3D1',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(31,0,1685614774,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1476107295: PHP Warning: Undefined array key \"worker\" in /var/www/html/Classes/Backend/Hook/DataHandlerHook.php line 79 | TYPO3\\CMS\\Core\\Error\\Exception thrown in file /var/www/html/.build/public/typo3/sysext/core/Classes/Error/ErrorHandler.php in line 138. Requested URL: https://timelog.ddev.site/typo3/record/edit?token=--AnonymizedToken--&edit%%5Btx_timelog_domain_model_task%%5D%%5B1%%5D=edit&returnUrl=%%2Ftypo3%%2Fmodule%%2Fweb%%2Flist%%3Ftoken%%3D--AnonymizedToken--%%26id%%3D3%%26table%%3D%%26pointer%%3D1',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(32,0,1685614844,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Call to a member function dispatch() on null | Error thrown in file /var/www/html/Classes/Domain/Model/Task.php in line 143. Requested URL: https://timelog.ddev.site/typo3/record/edit?token=--AnonymizedToken--&edit%%5Btx_timelog_domain_model_task%%5D%%5B1%%5D=edit&returnUrl=%%2Ftypo3%%2Fmodule%%2Fweb%%2Flist%%3Ftoken%%3D--AnonymizedToken--%%26id%%3D3%%26table%%3D%%26pointer%%3D1',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(33,0,1685615061,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Call to a member function dispatch() on null | Error thrown in file /var/www/html/Classes/Domain/Model/Task.php in line 143. Requested URL: https://timelog.ddev.site/typo3/record/edit?token=--AnonymizedToken--&edit%%5Btx_timelog_domain_model_task%%5D%%5B1%%5D=edit&returnUrl=%%2Ftypo3%%2Fmodule%%2Fweb%%2Flist%%3Ftoken%%3D--AnonymizedToken--%%26id%%3D3%%26table%%3D%%26pointer%%3D1',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(34,0,1685615090,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Call to a member function dispatch() on null | Error thrown in file /var/www/html/Classes/Domain/Model/Task.php in line 143. Requested URL: https://timelog.ddev.site/typo3/record/edit?token=--AnonymizedToken--&edit%%5Btx_timelog_domain_model_task%%5D%%5B1%%5D=edit&returnUrl=%%2Ftypo3%%2Fmodule%%2Fweb%%2Flist%%3Ftoken%%3D--AnonymizedToken--%%26id%%3D3%%26table%%3D%%26pointer%%3D1',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(35,0,1685615108,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),(36,0,1685615110,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Call to a member function dispatch() on null | Error thrown in file /var/www/html/Classes/Domain/Model/Task.php in line 143. Requested URL: https://timelog.ddev.site/typo3/record/edit?token=--AnonymizedToken--&edit%%5Btx_timelog_domain_model_task%%5D%%5B1%%5D=edit&returnUrl=%%2Ftypo3%%2Fmodule%%2Fweb%%2Flist%%3Ftoken%%3D--AnonymizedToken--%%26id%%3D3%%26table%%3D%%26pointer%%3D1',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(37,0,1685615255,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Call to a member function dispatch() on null | Error thrown in file /var/www/html/Classes/Domain/Model/Task.php in line 146. Requested URL: https://timelog.ddev.site/typo3/record/edit?token=--AnonymizedToken--&edit%%5Btx_timelog_domain_model_task%%5D%%5B1%%5D=edit&returnUrl=%%2Ftypo3%%2Fmodule%%2Fweb%%2Flist%%3Ftoken%%3D--AnonymizedToken--%%26id%%3D3%%26table%%3D%%26pointer%%3D1',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(38,0,1685615328,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),(39,0,1685615335,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Call to a member function dispatch() on null | Error thrown in file /var/www/html/Classes/Domain/Model/Task.php in line 146. Requested URL: https://timelog.ddev.site/typo3/record/edit?token=--AnonymizedToken--&edit%%5Btx_timelog_domain_model_task%%5D%%5B1%%5D=edit&returnUrl=%%2Ftypo3%%2Fmodule%%2Fweb%%2Flist%%3Ftoken%%3D--AnonymizedToken--%%26id%%3D3%%26table%%3D%%26pointer%%3D1',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(40,0,1685615380,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Call to a member function dispatch() on null | Error thrown in file /var/www/html/Classes/Domain/Model/Task.php in line 146. Requested URL: https://timelog.ddev.site/typo3/record/edit?token=--AnonymizedToken--&edit%%5Btx_timelog_domain_model_task%%5D%%5B1%%5D=edit&returnUrl=%%2Ftypo3%%2Fmodule%%2Fweb%%2Flist%%3Ftoken%%3D--AnonymizedToken--%%26id%%3D3%%26table%%3D%%26pointer%%3D1',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(41,0,1685615473,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Call to a member function dispatch() on null | Error thrown in file /var/www/html/Classes/Domain/Model/Task.php in line 146. Requested URL: https://timelog.ddev.site/typo3/record/edit?token=--AnonymizedToken--&edit%%5Btx_timelog_domain_model_task%%5D%%5B1%%5D=edit&returnUrl=%%2Ftypo3%%2Fmodule%%2Fweb%%2Flist%%3Ftoken%%3D--AnonymizedToken--%%26id%%3D3%%26table%%3D%%26pointer%%3D1',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(42,0,1685615544,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Call to a member function dispatch() on null | Error thrown in file /var/www/html/Classes/Domain/Model/Task.php in line 147. Requested URL: https://timelog.ddev.site/typo3/record/edit?token=--AnonymizedToken--&edit%%5Btx_timelog_domain_model_task%%5D%%5B1%%5D=edit&returnUrl=%%2Ftypo3%%2Fmodule%%2Fweb%%2Flist%%3Ftoken%%3D--AnonymizedToken--%%26id%%3D3%%26table%%3D%%26pointer%%3D1',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(43,0,1685615809,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Call to a member function dispatch() on null | Error thrown in file /var/www/html/Classes/Domain/Model/Task.php in line 147. Requested URL: https://timelog.ddev.site/typo3/record/edit?token=--AnonymizedToken--&edit%%5Btx_timelog_domain_model_task%%5D%%5B1%%5D=edit&returnUrl=%%2Ftypo3%%2Fmodule%%2Fweb%%2Flist%%3Ftoken%%3D--AnonymizedToken--%%26id%%3D3%%26table%%3D%%26pointer%%3D1',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(44,0,1685616346,1,2,1,'tx_timelog_domain_model_interval',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.6','{\"title\":\" (01-06-23 10:17 - 0.02)\",\"table\":\"tx_timelog_domain_model_interval\",\"uid\":1,\"history\":\"19\"}',3,0,'','',0,'','info',NULL,NULL),(45,0,1685616397,1,1,2,'tx_timelog_domain_model_task',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.6','{\"title\":\"0.0\",\"table\":\"tx_timelog_domain_model_task\",\"uid\":2,\"pageTitle\":\"Timelog\",\"pid\":3}',3,0,'NEW647876ef1049a482355407','',0,'','info',NULL,NULL),(46,0,1685616397,1,1,2,'tx_timelog_domain_model_interval',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.6','{\"title\":\"[No title]\",\"table\":\"tx_timelog_domain_model_interval\",\"uid\":2,\"pageTitle\":\"Timelog\",\"pid\":3}',3,0,'NEW647876eff21b1068347912','',0,'','info',NULL,NULL),(47,0,1685616397,1,2,2,'tx_timelog_domain_model_task',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.6','{\"title\":\"0.0\",\"table\":\"tx_timelog_domain_model_task\",\"uid\":2,\"history\":0}',3,0,'','',0,'','info',NULL,NULL),(48,0,1685616546,1,1,1,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.6','{\"title\":\"[No title]\",\"table\":\"tt_content\",\"uid\":1,\"pageTitle\":\"Timelog dev site\",\"pid\":1}',1,0,'NEW6478779bd2705409513023','',0,'','info',NULL,NULL),(49,0,1685616548,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1638554283: Controller action Buepro\\Timelog\\Controller\\TaskController::listAction did not return an instance of Psr\\Http\\Message\\ResponseInterface. | RuntimeException thrown in file /var/www/html/.build/public/typo3/sysext/extbase/Classes/Mvc/Controller/ActionController.php in line 489. Requested URL: https://timelog.ddev.site/',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(50,0,1685616850,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1638554283: Controller action Buepro\\Timelog\\Controller\\ProjectController::listAction did not return an instance of Psr\\Http\\Message\\ResponseInterface. | RuntimeException thrown in file /var/www/html/.build/public/typo3/sysext/extbase/Classes/Mvc/Controller/ActionController.php in line 489. Requested URL: https://timelog.ddev.site/?tx_timelog_taskpanel%%5Baction%%5D=list&tx_timelog_taskpanel%%5Bcontroller%%5D=Project&tx_timelog_taskpanel%%5BprojectHandle%%5D=&cHash=2e4ecb38aae35f37bb8f03cc73266ba8',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(51,0,1685617039,1,2,3,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.6','{\"title\":\"Timelog\",\"table\":\"pages\",\"uid\":3,\"history\":\"23\"}',3,0,'','',0,'','info',NULL,NULL),(52,0,1685617071,1,2,2,'tx_timelog_domain_model_task',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.6','{\"title\":\"title goes here - 0.1 - NRpZ35qw\",\"table\":\"tx_timelog_domain_model_task\",\"uid\":2,\"history\":\"24\"}',3,0,'','',0,'','info',NULL,NULL),(53,0,1685617146,1,2,1,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.6','{\"title\":\"[No title]\",\"table\":\"tt_content\",\"uid\":1,\"history\":\"25\"}',1,0,'','',0,'','info',NULL,NULL),(54,0,1685617151,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\Extbase\\Persistence\\Generic\\Query::logicalAnd(): Argument #1 must be of type TYPO3\\CMS\\Extbase\\Persistence\\Generic\\Qom\\ConstraintInterface, array given, called in /var/www/html/Classes/Domain/Repository/TaskRepository.php on line 209 | TypeError thrown in file /var/www/html/.build/public/typo3/sysext/extbase/Classes/Persistence/Generic/Query.php in line 394. Requested URL: https://timelog.ddev.site/?tx_timelog_taskpanel%%5Baction%%5D=list&tx_timelog_taskpanel%%5Bcontroller%%5D=Task&cHash=689d837b6dd60ff0923a4b83f0ad05d9',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(55,0,1685617189,1,2,1,'tx_timelog_domain_model_task',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.6','{\"title\":\"title goes here - 0.2 - MOJzl56n\",\"table\":\"tx_timelog_domain_model_task\",\"uid\":1,\"history\":\"26\"}',3,0,'','',0,'','info',NULL,NULL),(56,0,1685617193,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\Extbase\\Persistence\\Generic\\Query::logicalAnd(): Argument #1 must be of type TYPO3\\CMS\\Extbase\\Persistence\\Generic\\Qom\\ConstraintInterface, array given, called in /var/www/html/Classes/Domain/Repository/TaskRepository.php on line 209 | TypeError thrown in file /var/www/html/.build/public/typo3/sysext/extbase/Classes/Persistence/Generic/Query.php in line 394. Requested URL: https://timelog.ddev.site/?tx_timelog_taskpanel%%5BtaskHandle%%5D=MOJzl56n&cHash=8059a2316e32c7c0df043bff7266b9d8',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(57,0,1685617210,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\Extbase\\Persistence\\Generic\\Query::logicalAnd(): Argument #1 must be of type TYPO3\\CMS\\Extbase\\Persistence\\Generic\\Qom\\ConstraintInterface, array given, called in /var/www/html/Classes/Domain/Repository/TaskRepository.php on line 209 | TypeError thrown in file /var/www/html/.build/public/typo3/sysext/extbase/Classes/Persistence/Generic/Query.php in line 394. Requested URL: https://timelog.ddev.site/?tx_timelog_taskpanel%%5BtaskHandle%%5D=MOJzl56n&cHash=8059a2316e32c7c0df043bff7266b9d8',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(58,0,1685617725,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1407060572: Fluid parse error in template partial_Helper/Parsedown_5908f60f83b39715ff66dcfff88518a47cd06f9a, line 12 at character 45. Error: The ViewHelper \"<auxlibs:parsedown>\" could not be resolved.\nBased on your spelling, the system would load the class \"Buepro\\Auxlibs\\ViewHelpers\\ParsedownViewHelper\", however this class does not exist. (error code 1407060572). Template source chunk: \n    <div class=\"tx-timelog-markdown\">\n        {pvh:format.pregReplace(subject: text, pattern: settings.regexp, replacement: \'\')\n            -> auxlibs:parsedown(nl2br: settings.maintainLineBreaks)\n            -> f:format.raw()}\n    </div>\n | TYPO3Fluid\\Fluid\\Core\\Parser\\Exception thrown in file /var/www/html/.build/vendor/typo3fluid/fluid/src/Core/Parser/TemplateParser.php in line 159. Requested URL: https://timelog.ddev.site/?tx_timelog_taskpanel%%5BtaskHandle%%5D=MOJzl56n&cHash=8059a2316e32c7c0df043bff7266b9d8',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(59,0,1685618039,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1407060572: Fluid parse error in template partial_Helper/Parsedown_6ee3b022cd2126289b29ff066b253e0d5d0a4d65, line 12 at character 45. Error: The ViewHelper \"<tl:parsedown>\" could not be resolved.\nBased on your spelling, the system would load the class \"Buepro\\Auxlibs\\ViewHelpers\\ParsedownViewHelper\", however this class does not exist. (error code 1407060572). Template source chunk: \n    <div class=\"tx-timelog-markdown\">\n        {pvh:format.pregReplace(subject: text, pattern: settings.regexp, replacement: \'\')\n            -> tl:parsedown(nl2br: settings.maintainLineBreaks)\n            -> f:format.raw()}\n    </div>\n | TYPO3Fluid\\Fluid\\Core\\Parser\\Exception thrown in file /var/www/html/.build/vendor/typo3fluid/fluid/src/Core/Parser/TemplateParser.php in line 159. Requested URL: https://timelog.ddev.site/?tx_timelog_taskpanel%%5BtaskHandle%%5D=MOJzl56n&cHash=8059a2316e32c7c0df043bff7266b9d8',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(60,0,1685618052,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),(61,0,1685618056,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1407060572: Fluid parse error in template partial_Helper/Parsedown_6ee3b022cd2126289b29ff066b253e0d5d0a4d65, line 12 at character 45. Error: The ViewHelper \"<tl:parsedown>\" could not be resolved.\nBased on your spelling, the system would load the class \"Buepro\\Auxlibs\\ViewHelpers\\ParsedownViewHelper\", however this class does not exist. (error code 1407060572). Template source chunk: \n    <div class=\"tx-timelog-markdown\">\n        {pvh:format.pregReplace(subject: text, pattern: settings.regexp, replacement: \'\')\n            -> tl:parsedown(nl2br: settings.maintainLineBreaks)\n            -> f:format.raw()}\n    </div>\n | TYPO3Fluid\\Fluid\\Core\\Parser\\Exception thrown in file /var/www/html/.build/vendor/typo3fluid/fluid/src/Core/Parser/TemplateParser.php in line 159. Requested URL: https://timelog.ddev.site/?tx_timelog_taskpanel%%5BtaskHandle%%5D=MOJzl56n&cHash=8059a2316e32c7c0df043bff7266b9d8',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(62,0,1685618097,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: You have requested a non-existent service \"Buepro\\Timelog\\ViewHelpers\\ParsedownViewHelper\". Did you mean one of these: \"Buepro\\Pizpalue\\ViewHelpers\\FrameDataViewHelper\", \"Buepro\\Pizpalue\\ViewHelpers\\FrameViewHelper\"? | Symfony\\Component\\DependencyInjection\\Exception\\ServiceNotFoundException thrown in file /var/www/html/.build/vendor/symfony/dependency-injection/Container.php in line 264. Requested URL: https://timelog.ddev.site/?tx_timelog_taskpanel%%5BtaskHandle%%5D=MOJzl56n&cHash=8059a2316e32c7c0df043bff7266b9d8',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(63,0,1685618901,1,1,1,'tx_timelog_domain_model_taskgroup',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.6','{\"title\":\"task group 1 - 0.0, 0.0\",\"table\":\"tx_timelog_domain_model_taskgroup\",\"uid\":1,\"pageTitle\":\"Timelog\",\"pid\":3}',3,0,'NEW647880b0eb892130133308','',0,'','info',NULL,NULL),(64,0,1685618901,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1476107295: PHP Warning: Undefined array key \"active_time\" in /var/www/html/Classes/Backend/UserFunc/TcaUserFunc.php line 77 | TYPO3\\CMS\\Core\\Error\\Exception thrown in file /var/www/html/.build/public/typo3/sysext/core/Classes/Error/ErrorHandler.php in line 138. Requested URL: https://timelog.ddev.site/typo3/record/edit?token=--AnonymizedToken--&edit%%5Btx_timelog_domain_model_taskgroup%%5D%%5B3%%5D=new&returnUrl=%%2Ftypo3%%2Fmodule%%2Fweb%%2Flist%%3Ftoken%%3D--AnonymizedToken--%%26id%%3D3%%26table%%3D%%26pointer%%3D1',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(65,0,1685619000,1,2,1,'tx_timelog_domain_model_taskgroup',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.6','{\"title\":\"task group 1 - 0.0, 0.0\",\"table\":\"tx_timelog_domain_model_taskgroup\",\"uid\":1,\"history\":\"28\"}',3,0,'','',0,'','info',NULL,NULL),(66,0,1685619000,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1476107295: PHP Warning: Undefined array key \"active_time\" in /var/www/html/Classes/Backend/UserFunc/TcaUserFunc.php line 77 | TYPO3\\CMS\\Core\\Error\\Exception thrown in file /var/www/html/.build/public/typo3/sysext/core/Classes/Error/ErrorHandler.php in line 138. Requested URL: https://timelog.ddev.site/typo3/record/edit?token=--AnonymizedToken--&edit%%5Btx_timelog_domain_model_taskgroup%%5D%%5B1%%5D=edit&returnUrl=%%2Ftypo3%%2Fmodule%%2Fweb%%2Flist%%3Ftoken%%3D--AnonymizedToken--%%26id%%3D3%%26table%%3D%%26pointer%%3D1',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(67,0,1685619143,1,2,1,'tx_timelog_domain_model_taskgroup',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.6','{\"title\":\"task group 1 - 0.0, 0.0\",\"table\":\"tx_timelog_domain_model_taskgroup\",\"uid\":1,\"history\":\"29\"}',3,0,'','',0,'','info',NULL,NULL),(68,0,1685619181,1,2,2,'tx_timelog_domain_model_task',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.6','{\"title\":\"title goes here - 0.1 - NRpZ35qw\",\"table\":\"tx_timelog_domain_model_task\",\"uid\":2,\"history\":\"30\"}',3,0,'','',0,'','info',NULL,NULL),(69,0,1685619211,1,2,1,'tx_timelog_domain_model_task',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.6','{\"title\":\"title goes here - 0.2 - MOJzl56n\",\"table\":\"tx_timelog_domain_model_task\",\"uid\":1,\"history\":\"31\"}',3,0,'','',0,'','info',NULL,NULL),(70,0,1685619274,1,1,1,'tx_timelog_domain_model_project',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.6','{\"title\":\"project 1 - 0.0, 0.0\",\"table\":\"tx_timelog_domain_model_project\",\"uid\":1,\"pageTitle\":\"Timelog\",\"pid\":3}',3,0,'NEW6478822ea2fc5073648167','',0,'','info',NULL,NULL),(71,0,1685619274,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1476107295: PHP Warning: Undefined array key \"active_time\" in /var/www/html/Classes/Backend/UserFunc/TcaUserFunc.php line 24 | TYPO3\\CMS\\Core\\Error\\Exception thrown in file /var/www/html/.build/public/typo3/sysext/core/Classes/Error/ErrorHandler.php in line 138. Requested URL: https://timelog.ddev.site/typo3/record/edit?token=--AnonymizedToken--&edit%%5Btx_timelog_domain_model_project%%5D%%5B3%%5D=new&returnUrl=%%2Ftypo3%%2Fmodule%%2Fweb%%2Flist%%3Ftoken%%3D--AnonymizedToken--%%26id%%3D3%%26table%%3D%%26pointer%%3D1',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(72,0,1685619480,1,2,1,'tx_timelog_domain_model_taskgroup',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.6','{\"title\":\"task group 1 - 0.0, 0.0 - 9d05nZyE\",\"table\":\"tx_timelog_domain_model_taskgroup\",\"uid\":1,\"history\":\"33\"}',3,0,'','',0,'','info',NULL,NULL),(73,0,1685619593,1,2,2,'tx_timelog_domain_model_task',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.6','{\"title\":\"title goes here - 0.1 - project 1 - NRpZ35qw\",\"table\":\"tx_timelog_domain_model_task\",\"uid\":2,\"history\":\"34\"}',3,0,'','',0,'','info',NULL,NULL),(74,0,1685619597,1,2,2,'tx_timelog_domain_model_task',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.6','{\"title\":\"title goes here - 0.1 - project 1 - NRpZ35qw\",\"table\":\"tx_timelog_domain_model_task\",\"uid\":2,\"history\":\"35\"}',3,0,'','',0,'','info',NULL,NULL),(75,0,1685619673,1,2,1,'tx_timelog_domain_model_project',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.6','{\"title\":\"project 1 - 0.0, 0.0 - 7wznO6qK\",\"table\":\"tx_timelog_domain_model_project\",\"uid\":1,\"history\":\"36\"}',3,0,'','',0,'','info',NULL,NULL),(76,0,1685619673,1,1,2,'tx_timelog_domain_model_taskgroup',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.6','{\"title\":\"task group 2 - 0.0, 0.0\",\"table\":\"tx_timelog_domain_model_taskgroup\",\"uid\":2,\"pageTitle\":\"Timelog\",\"pid\":3}',3,0,'NEW647883b97da4b701913356','',0,'','info',NULL,NULL),(77,0,1685619673,1,2,1,'tx_timelog_domain_model_project',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.6','{\"title\":\"project 1 - 0.0, 0.0 - 7wznO6qK\",\"table\":\"tx_timelog_domain_model_project\",\"uid\":1,\"history\":\"38\"}',3,0,'','',0,'','info',NULL,NULL),(78,0,1685619710,1,2,1,'tx_timelog_domain_model_task',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.6','{\"title\":\"title goes here - 0.2 - project 1 - MOJzl56n\",\"table\":\"tx_timelog_domain_model_task\",\"uid\":1,\"history\":\"39\"}',3,0,'','',0,'','info',NULL,NULL),(79,0,1685619845,1,2,1,'tx_timelog_domain_model_task',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.6','{\"title\":\"title goes here - 0.2 - project 1 - MOJzl56n\",\"table\":\"tx_timelog_domain_model_task\",\"uid\":1,\"history\":\"40\"}',3,0,'','',0,'','info',NULL,NULL),(80,0,1685619933,1,2,0,'fe_users',0,4,'Password not saved ({table}:{uid}): The password must at least contain one upper case char',1,'content',-1,'172.18.0.6','{\"table\":\"fe_users\",\"uid\":\"NEW647884a052adc371566725\"}',2,0,'','',0,'','info',NULL,NULL),(81,0,1685619933,1,1,3,'fe_users',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.6','{\"title\":\"owner1\",\"table\":\"fe_users\",\"uid\":3,\"pageTitle\":\"Users\",\"pid\":2}',2,0,'NEW647884a052adc371566725','',0,'','info',NULL,NULL),(82,0,1685619947,1,2,3,'fe_users',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.6','{\"title\":\"owner1\",\"table\":\"fe_users\",\"uid\":3,\"history\":\"42\"}',2,0,'','',0,'','info',NULL,NULL),(83,0,1685619995,1,1,4,'fe_users',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.6','{\"title\":\"customer1\",\"table\":\"fe_users\",\"uid\":4,\"pageTitle\":\"Users\",\"pid\":2}',2,0,'NEW647884f246567535405689','',0,'','info',NULL,NULL),(84,0,1685620005,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1476107295: PHP Warning: Undefined array key \"text\" in /var/www/html/Classes/Backend/UserFunc/TcaUserFunc.php line 116 | TYPO3\\CMS\\Core\\Error\\Exception thrown in file /var/www/html/.build/public/typo3/sysext/core/Classes/Error/ErrorHandler.php in line 138. Requested URL: https://timelog.ddev.site/typo3/ajax/wizard/suggest/search?token=--AnonymizedToken--',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(85,0,1685620005,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1476107295: PHP Warning: Undefined array key \"text\" in /var/www/html/Classes/Backend/UserFunc/TcaUserFunc.php line 116 | TYPO3\\CMS\\Core\\Error\\Exception thrown in file /var/www/html/.build/public/typo3/sysext/core/Classes/Error/ErrorHandler.php in line 138. Requested URL: https://timelog.ddev.site/typo3/ajax/wizard/suggest/search?token=--AnonymizedToken--',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(86,0,1685620011,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1476107295: PHP Warning: Undefined array key \"text\" in /var/www/html/Classes/Backend/UserFunc/TcaUserFunc.php line 116 | TYPO3\\CMS\\Core\\Error\\Exception thrown in file /var/www/html/.build/public/typo3/sysext/core/Classes/Error/ErrorHandler.php in line 138. Requested URL: https://timelog.ddev.site/typo3/ajax/wizard/suggest/search?token=--AnonymizedToken--',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(87,0,1685620021,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1476107295: PHP Warning: Undefined array key \"text\" in /var/www/html/Classes/Backend/UserFunc/TcaUserFunc.php line 116 | TYPO3\\CMS\\Core\\Error\\Exception thrown in file /var/www/html/.build/public/typo3/sysext/core/Classes/Error/ErrorHandler.php in line 138. Requested URL: https://timelog.ddev.site/typo3/ajax/wizard/suggest/search?token=--AnonymizedToken--',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(88,0,1685620031,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1476107295: PHP Warning: Undefined array key \"text\" in /var/www/html/Classes/Backend/UserFunc/TcaUserFunc.php line 116 | TYPO3\\CMS\\Core\\Error\\Exception thrown in file /var/www/html/.build/public/typo3/sysext/core/Classes/Error/ErrorHandler.php in line 138. Requested URL: https://timelog.ddev.site/typo3/ajax/wizard/suggest/search?token=--AnonymizedToken--',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(89,0,1685620031,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1476107295: PHP Warning: Undefined array key \"text\" in /var/www/html/Classes/Backend/UserFunc/TcaUserFunc.php line 116 | TYPO3\\CMS\\Core\\Error\\Exception thrown in file /var/www/html/.build/public/typo3/sysext/core/Classes/Error/ErrorHandler.php in line 138. Requested URL: https://timelog.ddev.site/typo3/ajax/wizard/suggest/search?token=--AnonymizedToken--',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(90,0,1685620035,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1476107295: PHP Warning: Undefined array key \"text\" in /var/www/html/Classes/Backend/UserFunc/TcaUserFunc.php line 116 | TYPO3\\CMS\\Core\\Error\\Exception thrown in file /var/www/html/.build/public/typo3/sysext/core/Classes/Error/ErrorHandler.php in line 138. Requested URL: https://timelog.ddev.site/typo3/ajax/wizard/suggest/search?token=--AnonymizedToken--',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(91,0,1685620057,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1476107295: PHP Warning: Undefined array key \"text\" in /var/www/html/Classes/Backend/UserFunc/TcaUserFunc.php line 116 | TYPO3\\CMS\\Core\\Error\\Exception thrown in file /var/www/html/.build/public/typo3/sysext/core/Classes/Error/ErrorHandler.php in line 138. Requested URL: https://timelog.ddev.site/typo3/ajax/wizard/suggest/search?token=--AnonymizedToken--',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(92,0,1685620058,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1476107295: PHP Warning: Undefined array key \"text\" in /var/www/html/Classes/Backend/UserFunc/TcaUserFunc.php line 116 | TYPO3\\CMS\\Core\\Error\\Exception thrown in file /var/www/html/.build/public/typo3/sysext/core/Classes/Error/ErrorHandler.php in line 138. Requested URL: https://timelog.ddev.site/typo3/ajax/wizard/suggest/search?token=--AnonymizedToken--',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(93,0,1685620337,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1476107295: PHP Warning: Undefined array key \"text\" in /var/www/html/Classes/Backend/UserFunc/TcaUserFunc.php line 116 | TYPO3\\CMS\\Core\\Error\\Exception thrown in file /var/www/html/.build/public/typo3/sysext/core/Classes/Error/ErrorHandler.php in line 138. Requested URL: https://timelog.ddev.site/typo3/ajax/wizard/suggest/search?token=--AnonymizedToken--',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(94,0,1685620420,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),(95,0,1685630809,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),(96,0,1685630812,1,2,1,'tx_timelog_domain_model_project',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.6','{\"title\":\"project 1 - 0.1, 0.1 - 7wznO6qK\",\"table\":\"tx_timelog_domain_model_project\",\"uid\":1,\"history\":\"44\"}',3,0,'','',0,'','info',NULL,NULL),(97,0,1685630816,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1476107295: PHP Warning: Undefined array key \"text\" in /var/www/html/Classes/Backend/UserFunc/TcaUserFunc.php line 116 | TYPO3\\CMS\\Core\\Error\\Exception thrown in file /var/www/html/.build/public/typo3/sysext/core/Classes/Error/ErrorHandler.php in line 138. Requested URL: https://timelog.ddev.site/typo3/ajax/wizard/suggest/search?token=--AnonymizedToken--',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(98,0,1685630840,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1476107295: PHP Warning: Undefined array key \"text\" in /var/www/html/Classes/Backend/UserFunc/TcaUserFunc.php line 116 | TYPO3\\CMS\\Core\\Error\\Exception thrown in file /var/www/html/.build/public/typo3/sysext/core/Classes/Error/ErrorHandler.php in line 138. Requested URL: https://timelog.ddev.site/typo3/ajax/wizard/suggest/search?token=--AnonymizedToken--',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(99,0,1685630992,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1476107295: PHP Warning: Undefined array key 1 in /var/www/html/Classes/Backend/UserFunc/TcaUserFunc.php line 135 | TYPO3\\CMS\\Core\\Error\\Exception thrown in file /var/www/html/.build/public/typo3/sysext/core/Classes/Error/ErrorHandler.php in line 138. Requested URL: https://timelog.ddev.site/typo3/ajax/wizard/suggest/search?token=--AnonymizedToken--',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(100,0,1685631000,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),(101,0,1685631003,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1476107295: PHP Warning: Undefined array key 1 in /var/www/html/Classes/Backend/UserFunc/TcaUserFunc.php line 135 | TYPO3\\CMS\\Core\\Error\\Exception thrown in file /var/www/html/.build/public/typo3/sysext/core/Classes/Error/ErrorHandler.php in line 138. Requested URL: https://timelog.ddev.site/typo3/ajax/wizard/suggest/search?token=--AnonymizedToken--',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(102,0,1685631013,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1476107295: PHP Warning: Undefined array key 1 in /var/www/html/Classes/Backend/UserFunc/TcaUserFunc.php line 135 | TYPO3\\CMS\\Core\\Error\\Exception thrown in file /var/www/html/.build/public/typo3/sysext/core/Classes/Error/ErrorHandler.php in line 138. Requested URL: https://timelog.ddev.site/typo3/ajax/wizard/suggest/search?token=--AnonymizedToken--',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(103,0,1685631128,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1476107295: PHP Warning: Undefined array key 1 in /var/www/html/Classes/Backend/UserFunc/TcaUserFunc.php line 135 | TYPO3\\CMS\\Core\\Error\\Exception thrown in file /var/www/html/.build/public/typo3/sysext/core/Classes/Error/ErrorHandler.php in line 138. Requested URL: https://timelog.ddev.site/typo3/ajax/wizard/suggest/search?token=--AnonymizedToken--',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(104,0,1685631160,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1476107295: PHP Warning: Undefined array key 1 in /var/www/html/Classes/Backend/UserFunc/TcaUserFunc.php line 135 | TYPO3\\CMS\\Core\\Error\\Exception thrown in file /var/www/html/.build/public/typo3/sysext/core/Classes/Error/ErrorHandler.php in line 138. Requested URL: https://timelog.ddev.site/typo3/ajax/wizard/suggest/search?token=--AnonymizedToken--',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(105,0,1685632618,1,2,1,'tx_timelog_domain_model_project',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.6','{\"title\":\"project 1 - 0.3, 0.3 - customer 1 gmbh - 7wznO6qK\",\"table\":\"tx_timelog_domain_model_project\",\"uid\":1,\"history\":\"45\"}',3,0,'','',0,'','info',NULL,NULL),(106,0,1685633565,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),(107,0,1685633577,1,1,3,'tx_timelog_domain_model_task',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.6','{\"title\":\"0.0\",\"table\":\"tx_timelog_domain_model_task\",\"uid\":3,\"pageTitle\":\"Timelog\",\"pid\":3}',3,0,'NEW6478b74e1302e662142022','',0,'','info',NULL,NULL),(108,0,1685633594,1,3,3,'tx_timelog_domain_model_task',0,0,'Record \"{title}\" ({table}:{uid}) was deleted from page \"{pageTitle}\" ({pid})',1,'content',0,'172.18.0.6','{\"title\":\"0.0 - 105Nqp98\",\"table\":\"tx_timelog_domain_model_task\",\"uid\":3,\"pageTitle\":\"Timelog\",\"pid\":3}',3,0,'','',0,'','info',NULL,NULL),(109,0,1685636483,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),(110,0,1685637350,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),(111,0,1685637506,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),(112,0,1685638189,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),(113,0,1685688176,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.6','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(114,0,1685688474,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1639818540: ViewHelper f:link.action can be used only in extbase context and needs a request implementing extbase RequestInterface. | RuntimeException thrown in file /var/www/html/.build/public/typo3/sysext/fluid/Classes/ViewHelpers/Link/ActionViewHelper.php in line 81. Requested URL: https://timelog.ddev.site/?smt=client&tx_timelog_taskpanel%%5Bcontroller%%5D=Task&tx_timelog_taskpanel%%5BprojectHandle%%5D=7wznO6qK&cHash=43e0920f34293bc7cc8819a91f0ad787',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(115,0,1685688506,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1639818540: ViewHelper f:link.action can be used only in extbase context and needs a request implementing extbase RequestInterface. | RuntimeException thrown in file /var/www/html/.build/public/typo3/sysext/fluid/Classes/ViewHelpers/Link/ActionViewHelper.php in line 81. Requested URL: https://timelog.ddev.site/?smt=client&tx_timelog_taskpanel%%5Bcontroller%%5D=Task&tx_timelog_taskpanel%%5BprojectHandle%%5D=7wznO6qK&cHash=43e0920f34293bc7cc8819a91f0ad787',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(116,0,1685688690,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1639818540: ViewHelper f:link.action can be used only in extbase context and needs a request implementing extbase RequestInterface. | RuntimeException thrown in file /var/www/html/.build/public/typo3/sysext/fluid/Classes/ViewHelpers/Link/ActionViewHelper.php in line 81. Requested URL: https://timelog.ddev.site/?smt=client&tx_timelog_taskpanel%%5Bcontroller%%5D=Task&tx_timelog_taskpanel%%5BprojectHandle%%5D=7wznO6qK&cHash=43e0920f34293bc7cc8819a91f0ad787',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(117,0,1685688723,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1639818540: ViewHelper f:link.action can be used only in extbase context and needs a request implementing extbase RequestInterface. | RuntimeException thrown in file /var/www/html/.build/public/typo3/sysext/fluid/Classes/ViewHelpers/Link/ActionViewHelper.php in line 81. Requested URL: https://timelog.ddev.site/?smt=client&tx_timelog_taskpanel%%5Bcontroller%%5D=Task&tx_timelog_taskpanel%%5BprojectHandle%%5D=7wznO6qK&cHash=43e0920f34293bc7cc8819a91f0ad787',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(118,0,1685689083,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1639818540: ViewHelper f:link.action can be used only in extbase context and needs a request implementing extbase RequestInterface. | RuntimeException thrown in file /var/www/html/.build/public/typo3/sysext/fluid/Classes/ViewHelpers/Link/ActionViewHelper.php in line 81. Requested URL: https://timelog.ddev.site/?smt=client&tx_timelog_taskpanel%%5Bcontroller%%5D=Task&tx_timelog_taskpanel%%5BprojectHandle%%5D=7wznO6qK&cHash=43e0920f34293bc7cc8819a91f0ad787',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(119,0,1685689229,1,2,1,'sys_template',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.6','{\"title\":\"NEW SITE\",\"table\":\"sys_template\",\"uid\":1,\"history\":\"48\"}',1,0,'','',0,'','info',NULL,NULL),(120,0,1685689233,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),(121,0,1685689260,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1639818540: ViewHelper f:link.action can be used only in extbase context and needs a request implementing extbase RequestInterface. | RuntimeException thrown in file /var/www/html/.build/public/typo3/sysext/fluid/Classes/ViewHelpers/Link/ActionViewHelper.php in line 81. Requested URL: https://timelog.ddev.site/?smt=client&tx_timelog_taskpanel%%5Bcontroller%%5D=Task&tx_timelog_taskpanel%%5BprojectHandle%%5D=7wznO6qK&cHash=43e0920f34293bc7cc8819a91f0ad787',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(122,0,1685689510,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1639818540: ViewHelper f:link.action can be used only in extbase context and needs a request implementing extbase RequestInterface. | RuntimeException thrown in file /var/www/html/.build/public/typo3/sysext/fluid/Classes/ViewHelpers/Link/ActionViewHelper.php in line 81. Requested URL: https://timelog.ddev.site/?smt=client&tx_timelog_taskpanel%%5Bcontroller%%5D=Task&tx_timelog_taskpanel%%5BprojectHandle%%5D=7wznO6qK&cHash=43e0920f34293bc7cc8819a91f0ad787',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(123,0,1685689844,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1639818540: ViewHelper f:link.action can be used only in extbase context and needs a request implementing extbase RequestInterface. | RuntimeException thrown in file /var/www/html/.build/public/typo3/sysext/fluid/Classes/ViewHelpers/Link/ActionViewHelper.php in line 81. Requested URL: https://timelog.ddev.site/?smt=client&tx_timelog_taskpanel%%5Bcontroller%%5D=Task&tx_timelog_taskpanel%%5BprojectHandle%%5D=7wznO6qK&cHash=43e0920f34293bc7cc8819a91f0ad787',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(124,0,1685690138,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1639818540: ViewHelper f:link.action can be used only in extbase context and needs a request implementing extbase RequestInterface. | RuntimeException thrown in file /var/www/html/.build/public/typo3/sysext/fluid/Classes/ViewHelpers/Link/ActionViewHelper.php in line 81. Requested URL: https://timelog.ddev.site/?smt=client&tx_timelog_taskpanel%%5Bcontroller%%5D=Task&tx_timelog_taskpanel%%5BprojectHandle%%5D=7wznO6qK&cHash=43e0920f34293bc7cc8819a91f0ad787',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(125,0,1685690533,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1639818540: ViewHelper f:link.action can be used only in extbase context and needs a request implementing extbase RequestInterface. | RuntimeException thrown in file /var/www/html/.build/public/typo3/sysext/fluid/Classes/ViewHelpers/Link/ActionViewHelper.php in line 81. Requested URL: https://timelog.ddev.site/?smt=client&tx_timelog_taskpanel%%5Bcontroller%%5D=Task&tx_timelog_taskpanel%%5BprojectHandle%%5D=7wznO6qK&cHash=43e0920f34293bc7cc8819a91f0ad787',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(126,0,1685695374,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1624452070: Given request must have an attribute \"extbase\" of type ExtbaseAttribute | InvalidArgumentException thrown in file /var/www/html/.build/public/typo3/sysext/extbase/Classes/Mvc/Request.php in line 41. Requested URL: https://timelog.ddev.site/?smt=client&tx_timelog_taskpanel%%5Bcontroller%%5D=Task&tx_timelog_taskpanel%%5BprojectHandle%%5D=7wznO6qK&cHash=43e0920f34293bc7cc8819a91f0ad787',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(127,0,1685704626,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1256475113: The argument \"additionalAttributes\" was registered with type \"array\", but is of type \"string\" in view helper \"TYPO3\\CMS\\Fluid\\ViewHelpers\\Form\\SelectViewHelper\". | InvalidArgumentException thrown in file /var/www/html/.build/vendor/typo3fluid/fluid/src/Core/ViewHelper/AbstractViewHelper.php in line 347. Requested URL: https://timelog.ddev.site/?tx_timelog_taskpanel%%5BtaskHandle%%5D=MOJzl56n&cHash=8059a2316e32c7c0df043bff7266b9d8',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(128,0,1685704656,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1407060572: Fluid parse error in template partial_Project/Single_b53df5fb5d8e2a29fcb2d2781b8219db93f3d02c, line 114 at character 1. Error: The ViewHelper \"<f:format.row>\" could not be resolved.\nBased on your spelling, the system would load the class \"TYPO3Fluid\\Fluid\\ViewHelpers\\Format\\RowViewHelper\", however this class does not exist. (error code 1407060572). Template source chunk: <f:form.select name=\"taskGroupHandle\" class=\"form-control\" additionalAttributes=\"{onchange: \'{_onChange -> f:format.row()}\'}\"> | TYPO3Fluid\\Fluid\\Core\\Parser\\Exception thrown in file /var/www/html/.build/vendor/typo3fluid/fluid/src/Core/Parser/TemplateParser.php in line 159. Requested URL: https://timelog.ddev.site/?tx_timelog_taskpanel%%5BtaskHandle%%5D=MOJzl56n&cHash=8059a2316e32c7c0df043bff7266b9d8',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','info',NULL,NULL),(129,0,1685706158,1,2,2,'tx_timelog_domain_model_task',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.6','{\"title\":\"title goes here - 0.1 - project 1 - customer 1 gmbh - NRpZ35qw\",\"table\":\"tx_timelog_domain_model_task\",\"uid\":2,\"history\":\"49\"}',3,0,'','',0,'','info',NULL,NULL),(130,0,1685725168,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.6','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(131,0,1685726392,1,2,1,'tx_timelog_domain_model_project',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.6','{\"title\":\"project 1 - 0.3, 0.3 - customer 1 gmbh - 7wznO6qK\",\"table\":\"tx_timelog_domain_model_project\",\"uid\":1,\"history\":\"50\"}',3,0,'','',0,'','info',NULL,NULL),(132,0,1685726457,1,2,1,'tx_timelog_domain_model_project',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.6','{\"title\":\"project 1 - 0.3, 0.3 - customer 1 gmbh - gZx0px5n\",\"table\":\"tx_timelog_domain_model_project\",\"uid\":1,\"history\":\"51\"}',3,0,'','',0,'','info',NULL,NULL),(133,0,1685727116,1,2,1,'tx_timelog_domain_model_project',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.6','{\"title\":\"project 1 - 0.3, 0.3 - customer 1 gmbh - gZx0px5n\",\"table\":\"tx_timelog_domain_model_project\",\"uid\":1,\"history\":\"52\"}',3,0,'','',0,'','info',NULL,NULL),(134,0,1685727140,1,2,1,'tx_timelog_domain_model_project',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.6','{\"title\":\"project 1 - 0.3, 0.3 - customer 1 gmbh - gZx0px5n\",\"table\":\"tx_timelog_domain_model_project\",\"uid\":1,\"history\":\"53\"}',3,0,'','',0,'','info',NULL,NULL),(135,0,1685727162,1,2,1,'tx_timelog_domain_model_project',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.6','{\"title\":\"project 1 - 0.3, 0.3 - customer 1 gmbh - gZx0px5n\",\"table\":\"tx_timelog_domain_model_project\",\"uid\":1,\"history\":\"54\"}',3,0,'','',0,'','info',NULL,NULL),(136,0,1685727180,1,2,1,'tx_timelog_domain_model_project',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.6','{\"title\":\"project 1 - 0.3, 0.3 - customer 1 gmbh - gZx0px5n\",\"table\":\"tx_timelog_domain_model_project\",\"uid\":1,\"history\":\"55\"}',3,0,'','',0,'','info',NULL,NULL),(137,0,1685727434,1,2,1,'tx_timelog_domain_model_project',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.6','{\"title\":\"project 1 - 0.3, 0.3 - customer 1 gmbh - gZx0px5n\",\"table\":\"tx_timelog_domain_model_project\",\"uid\":1,\"history\":\"56\"}',3,0,'','',0,'','info',NULL,NULL),(138,0,1685728213,1,2,1,'tx_timelog_domain_model_project',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.6','{\"title\":\"project 1 - 0.3, 0.3 - customer 1 gmbh - gZx0px5n\",\"table\":\"tx_timelog_domain_model_project\",\"uid\":1,\"history\":\"57\"}',3,0,'','',0,'','info',NULL,NULL),(139,0,1685728627,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),(140,0,1685728631,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),(141,0,1688987694,0,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\', password not accepted!',255,'user',1,'172.18.0.6','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(142,0,1688987708,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.6','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(143,0,1688987728,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Error: argument `$color` of `red($color)` must be a color: /var/www/html/.build/vendor/bk2k/bootstrap-package/Resources/Public/Contrib/bootstrap5/scss/_functions.scss on line 184, at column 3\nCall Stack:\n#0 function luminance /var/www/html/.build/vendor/bk2k/bootstrap-package/Resources/Public/Contrib/bootstrap5/scss/_functions.scss on line 174\n#1 function contrast-ratio /var/www/html/.build/vendor/bk2k/bootstrap-package/Resources/Public/Contrib/bootstrap5/scss/_functions.scss on line 159\n#2 function color-contrast Bootstrap5/../Theme/_variables.scss on line 21\n#3 import Bootstrap5/../Theme/_variables.scss Bootstrap5/theme.scss on line 17\n#4 import Bootstrap5/theme.scss theme.scss on line 9\n#5 import theme.scss theme.scss on line 1 | ScssPhp\\ScssPhp\\Exception\\CompilerException thrown in file /var/www/html/.build/vendor/scssphp/scssphp/src/Compiler.php in line 6102. Requested URL: https://timelog.ddev.site/',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','error',NULL,NULL),(144,0,1688987807,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Error: argument `$color` of `red($color)` must be a color: /var/www/html/.build/vendor/bk2k/bootstrap-package/Resources/Public/Contrib/bootstrap5/scss/_functions.scss on line 184, at column 3\nCall Stack:\n#0 function luminance /var/www/html/.build/vendor/bk2k/bootstrap-package/Resources/Public/Contrib/bootstrap5/scss/_functions.scss on line 174\n#1 function contrast-ratio /var/www/html/.build/vendor/bk2k/bootstrap-package/Resources/Public/Contrib/bootstrap5/scss/_functions.scss on line 159\n#2 function color-contrast Bootstrap5/../Theme/_variables.scss on line 21\n#3 import Bootstrap5/../Theme/_variables.scss Bootstrap5/theme.scss on line 17\n#4 import Bootstrap5/theme.scss theme.scss on line 9\n#5 import theme.scss theme.scss on line 1 | ScssPhp\\ScssPhp\\Exception\\CompilerException thrown in file /var/www/html/.build/vendor/scssphp/scssphp/src/Compiler.php in line 6102. Requested URL: https://timelog.ddev.site/',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','error',NULL,NULL),(145,0,1689050234,0,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\', password not accepted!',255,'user',1,'172.18.0.6','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(146,0,1689050245,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.6','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL);
/*!40000 ALTER TABLE `sys_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_messenger_messages`
--

DROP TABLE IF EXISTS `sys_messenger_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_messenger_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `body` longtext NOT NULL,
  `headers` longtext NOT NULL,
  `queue_name` varchar(190) NOT NULL,
  `created_at` datetime NOT NULL,
  `available_at` datetime NOT NULL,
  `delivered_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `queue_name` (`queue_name`),
  KEY `available_at` (`available_at`),
  KEY `delivered_at` (`delivered_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_messenger_messages`
--

LOCK TABLES `sys_messenger_messages` WRITE;
/*!40000 ALTER TABLE `sys_messenger_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_messenger_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_news`
--

DROP TABLE IF EXISTS `sys_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_news` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `content` mediumtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_news`
--

LOCK TABLES `sys_news` WRITE;
/*!40000 ALTER TABLE `sys_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_note`
--

DROP TABLE IF EXISTS `sys_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_note` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `subject` varchar(255) NOT NULL DEFAULT '',
  `cruser` int(10) unsigned NOT NULL DEFAULT 0,
  `message` text DEFAULT NULL,
  `personal` smallint(5) unsigned NOT NULL DEFAULT 0,
  `category` smallint(5) unsigned NOT NULL DEFAULT 0,
  `position` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_note`
--

LOCK TABLES `sys_note` WRITE;
/*!40000 ALTER TABLE `sys_note` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_reaction`
--

DROP TABLE IF EXISTS `sys_reaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_reaction` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `updatedon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdon` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disabled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `name` varchar(100) NOT NULL DEFAULT '',
  `reaction_type` varchar(255) NOT NULL DEFAULT '',
  `secret` varchar(255) NOT NULL DEFAULT '',
  `impersonate_user` int(10) unsigned NOT NULL DEFAULT 0,
  `table_name` varchar(255) NOT NULL DEFAULT '',
  `storage_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `fields` longtext DEFAULT NULL COMMENT '(DC2Type:json)',
  `identifier` varchar(36) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  UNIQUE KEY `identifier_key` (`identifier`),
  KEY `index_source` (`reaction_type`(5)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_reaction`
--

LOCK TABLES `sys_reaction` WRITE;
/*!40000 ALTER TABLE `sys_reaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_reaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_refindex`
--

DROP TABLE IF EXISTS `sys_refindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_refindex` (
  `hash` varchar(32) NOT NULL DEFAULT '',
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `recuid` int(11) NOT NULL DEFAULT 0,
  `field` varchar(64) NOT NULL DEFAULT '',
  `flexpointer` varchar(255) NOT NULL DEFAULT '',
  `softref_key` varchar(30) NOT NULL DEFAULT '',
  `softref_id` varchar(40) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `ref_table` varchar(255) NOT NULL DEFAULT '',
  `ref_uid` int(11) NOT NULL DEFAULT 0,
  `ref_string` varchar(1024) NOT NULL DEFAULT '',
  PRIMARY KEY (`hash`),
  KEY `lookup_rec` (`tablename`(100),`recuid`),
  KEY `lookup_uid` (`ref_table`(100),`ref_uid`),
  KEY `lookup_string` (`ref_string`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_refindex`
--

LOCK TABLES `sys_refindex` WRITE;
/*!40000 ALTER TABLE `sys_refindex` DISABLE KEYS */;
INSERT INTO `sys_refindex` VALUES ('001cd2e4390e0152274a1a31cabbf067','fe_users',1,'usergroup','','','',0,0,'fe_groups',1,''),('121e4c7af1a67d742beae6f5495860d9','fe_users',3,'usergroup','','','',0,0,'fe_groups',1,''),('13439728d2da2d1186599da8dd462640','tt_content',1,'pages','','','',0,0,'pages',3,''),('230123cca4c1a884720e923c2ab97f4a','tx_timelog_domain_model_project',1,'owner','','','',0,0,'fe_users',3,''),('25ff69f2c42145e28c5f74737e9bd4d8','tx_timelog_domain_model_task',1,'intervals','','','',0,0,'tx_timelog_domain_model_interval',1,''),('2bede5c771d6a5e28b152eb8729eca3d','tx_timelog_domain_model_project',1,'tasks','','','',0,0,'tx_timelog_domain_model_task',2,''),('35706a3652a86def5effa8c8d3b334ff','tx_timelog_domain_model_project',1,'task_groups','','','',0,0,'tx_timelog_domain_model_taskgroup',2,''),('3743fd900b9fb33e28f4dad79eed6179','tx_timelog_domain_model_task',2,'task_group','','','',0,0,'tx_timelog_domain_model_taskgroup',2,''),('39362c40991da91b702a7d894748ec51','tx_timelog_domain_model_taskgroup',1,'tasks','','','',0,0,'tx_timelog_domain_model_task',2,''),('5d804a07fff5d1b318d9f17e018bf40a','tx_timelog_domain_model_project',1,'tasks','','','',1,0,'tx_timelog_domain_model_task',1,''),('5ff116c608a56549122da8ede41464c6','tx_timelog_domain_model_taskgroup',2,'project','','','',0,0,'tx_timelog_domain_model_project',1,''),('69e2083617f19fccff41d15a595d8b74','tx_timelog_domain_model_taskgroup',1,'tasks','','','',1,0,'tx_timelog_domain_model_task',1,''),('6e40f52c2d7d5549d2f83af7dbf0989f','tx_timelog_domain_model_taskgroup',2,'tasks','','','',0,0,'tx_timelog_domain_model_task',2,''),('8d139b1d4542bf95c8b4be986ef5eaa6','fe_users',2,'usergroup','','','',0,0,'fe_groups',1,''),('bb63e8f4c8093815c530df1bff058a38','fe_users',4,'email','','email','2',-1,0,'_STRING',0,'customer1@timelog.ddev.site'),('c54640f81d6a6945169236df104d07b2','tx_timelog_domain_model_project',1,'client','','','',0,0,'fe_users',4,''),('c7d76f8b9127e85852dcc461122ae217','tx_timelog_domain_model_task',1,'project','','','',0,0,'tx_timelog_domain_model_project',1,''),('cca234ba287dceaefadd4e6eed797393','fe_users',4,'usergroup','','','',0,0,'fe_groups',1,''),('d18d07ca5201563faa7d07e5c285533e','fe_users',3,'email','','email','2',-1,0,'_STRING',0,'owner1@timelog.ddev.site'),('d4a8c77a5d6c522498a6e667eaa0c6d4','tx_timelog_domain_model_task',1,'worker','','','',0,0,'fe_users',1,''),('eacce6bc3ede29d1cbcb36c0689367d6','tx_timelog_domain_model_task',2,'project','','','',0,0,'tx_timelog_domain_model_project',1,''),('f4bf256749e0b76f68400b815062747a','tx_timelog_domain_model_task',2,'intervals','','','',0,0,'tx_timelog_domain_model_interval',2,''),('f9853f1b708bd365e25d63b5928c2440','tx_timelog_domain_model_task',2,'worker','','','',0,0,'fe_users',2,'');
/*!40000 ALTER TABLE `sys_refindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_registry`
--

DROP TABLE IF EXISTS `sys_registry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_registry` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_namespace` varchar(128) NOT NULL DEFAULT '',
  `entry_key` varchar(128) NOT NULL DEFAULT '',
  `entry_value` mediumblob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `entry_identifier` (`entry_namespace`,`entry_key`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_registry`
--

LOCK TABLES `sys_registry` WRITE;
/*!40000 ALTER TABLE `sys_registry` DISABLE KEYS */;
INSERT INTO `sys_registry` VALUES (2,'installUpdateRows','rowUpdatersDone','a:4:{i:0;s:66:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\L18nDiffsourceToJsonMigration\";i:1;s:77:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\WorkspaceMovePlaceholderRemovalMigration\";i:2;s:76:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\WorkspaceNewPlaceholderRemovalMigration\";i:3;s:69:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\SysRedirectRootPageMoveMigration\";}'),(3,'installUpdate','TYPO3\\CMS\\Install\\Updates\\PasswordPolicyForFrontendUsersUpdate','i:1;'),(4,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SvgFilesSanitization','i:1;'),(5,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysLogChannel','i:1;'),(6,'core','formProtectionSessionToken:1','s:64:\"89424955d30c1bbbcb92c96d082171e0e7897e0d72662f213fd2a6bb02cc5913\";'),(7,'tx-timelog-be-user-worker-uid','1','i:2;'),(8,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendGroupsExplicitAllowDenyMigration','i:1;'),(9,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendModulePermissionMigration','i:1;'),(10,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendUserLanguageMigration','i:1;'),(11,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FeLoginModeExtractionUpdate','i:1;'),(12,'installUpdate','TYPO3\\CMS\\Install\\Updates\\CollectionsExtractionUpdate','i:1;'),(13,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigrateSiteSettingsConfigUpdate','i:1;'),(14,'installUpdate','TYPO3\\CMS\\Install\\Updates\\ShortcutRecordsMigration','i:1;'),(15,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysFileCollectionIdentifierMigration','i:1;'),(16,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysFileMountIdentifierMigration','i:1;'),(17,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysLogSerializationUpdate','i:1;'),(18,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysTemplateNoWorkspaceMigration','i:1;'),(19,'extensionDataImport','typo3/cms-core/ext_tables_static+adt.sql','s:0:\"\";'),(20,'extensionDataImport','typo3/cms-extbase/ext_tables_static+adt.sql','s:0:\"\";'),(21,'extensionDataImport','typo3/cms-fluid/ext_tables_static+adt.sql','s:0:\"\";'),(22,'extensionDataImport','typo3/cms-install/ext_tables_static+adt.sql','s:0:\"\";'),(23,'extensionDataImport','typo3/cms-backend/ext_tables_static+adt.sql','s:0:\"\";'),(24,'extensionDataImport','typo3/cms-frontend/ext_tables_static+adt.sql','s:0:\"\";'),(25,'extensionDataImport','typo3/cms-dashboard/ext_tables_static+adt.sql','s:0:\"\";'),(26,'extensionDataImport','typo3/cms-fluid-styled-content/ext_tables_static+adt.sql','s:0:\"\";'),(27,'extensionDataImport','typo3/cms-seo/ext_tables_static+adt.sql','s:0:\"\";'),(28,'extensionDataImport','typo3/cms-filelist/ext_tables_static+adt.sql','s:0:\"\";'),(29,'extensionDataImport','typo3/cms-impexp/ext_tables_static+adt.sql','s:0:\"\";'),(30,'extensionDataImport','typo3/cms-form/ext_tables_static+adt.sql','s:0:\"\";'),(31,'extensionDataImport','typo3/cms-lowlevel/ext_tables_static+adt.sql','s:0:\"\";'),(32,'extensionDataImport','typo3/cms-reactions/ext_tables_static+adt.sql','s:0:\"\";'),(33,'extensionDataImport','typo3/cms-setup/ext_tables_static+adt.sql','s:0:\"\";'),(34,'extensionDataImport','typo3/cms-rte-ckeditor/ext_tables_static+adt.sql','s:0:\"\";'),(35,'extensionDataImport','typo3/cms-webhooks/ext_tables_static+adt.sql','s:0:\"\";'),(36,'extensionDataImport','typo3/cms-belog/ext_tables_static+adt.sql','s:0:\"\";'),(37,'extensionDataImport','typo3/cms-beuser/ext_tables_static+adt.sql','s:0:\"\";'),(38,'extensionDataImport','typo3/cms-extensionmanager/ext_tables_static+adt.sql','s:0:\"\";'),(39,'extensionDataImport','typo3/cms-felogin/ext_tables_static+adt.sql','s:0:\"\";'),(40,'extensionDataImport','typo3/cms-info/ext_tables_static+adt.sql','s:0:\"\";'),(41,'extensionDataImport','typo3/cms-recycler/ext_tables_static+adt.sql','s:0:\"\";'),(42,'extensionDataImport','typo3/cms-sys-note/ext_tables_static+adt.sql','s:0:\"\";'),(43,'extensionDataImport','typo3/cms-t3editor/ext_tables_static+adt.sql','s:0:\"\";'),(44,'extensionDataImport','typo3/cms-tstemplate/ext_tables_static+adt.sql','s:0:\"\";'),(45,'extensionDataImport','typo3/cms-viewpage/ext_tables_static+adt.sql','s:0:\"\";'),(46,'extensionDataImport','bk2k/bootstrap-package/ext_tables_static+adt.sql','s:0:\"\";'),(47,'extensionDataImport','buepro/typo3-pvh/ext_tables_static+adt.sql','s:0:\"\";'),(48,'extensionDataImport','buepro/typo3-pizpalue/Initialisation/Files','i:1;'),(49,'extensionDataImport','buepro/typo3-pizpalue/ext_tables_static+adt.sql','s:0:\"\";'),(50,'extensionDataImport','/Files','i:1;'),(51,'extensionDataImport','tic+adt.sql','s:0:\"\";');
/*!40000 ALTER TABLE `sys_registry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_template`
--

DROP TABLE IF EXISTS `sys_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_template` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `root` smallint(5) unsigned NOT NULL DEFAULT 0,
  `clear` smallint(5) unsigned NOT NULL DEFAULT 0,
  `include_static_file` text DEFAULT NULL,
  `constants` text DEFAULT NULL,
  `config` text DEFAULT NULL,
  `basedOn` tinytext DEFAULT NULL,
  `includeStaticAfterBasedOn` smallint(5) unsigned NOT NULL DEFAULT 0,
  `static_file_mode` smallint(5) unsigned NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `roottemplate` (`deleted`,`hidden`,`root`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_template`
--

LOCK TABLES `sys_template` WRITE;
/*!40000 ALTER TABLE `sys_template` DISABLE KEYS */;
INSERT INTO `sys_template` VALUES (1,1,1685689229,1685605824,0,0,0,0,256,NULL,0,'NEW SITE',1,3,'EXT:bootstrap_package/Configuration/TypoScript,EXT:pizpalue/Configuration/TypoScript/Main,EXT:timelog/Configuration/TypoScript','\nplugin.tx_timelog_taskpanel.persistence.storagePid = 3','','',0,0,0);
/*!40000 ALTER TABLE `sys_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_webhook`
--

DROP TABLE IF EXISTS `sys_webhook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_webhook` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `updatedon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdon` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disabled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `name` varchar(100) NOT NULL DEFAULT '',
  `url` varchar(2048) NOT NULL DEFAULT '',
  `method` varchar(10) NOT NULL DEFAULT '',
  `secret` varchar(255) NOT NULL DEFAULT '',
  `webhook_type` varchar(255) NOT NULL DEFAULT '',
  `verify_ssl` int(11) NOT NULL DEFAULT 1,
  `additional_headers` longtext DEFAULT NULL COMMENT '(DC2Type:json)',
  `identifier` varchar(36) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  UNIQUE KEY `identifier_key` (`identifier`),
  KEY `index_source` (`webhook_type`(5)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_webhook`
--

LOCK TABLES `sys_webhook` WRITE;
/*!40000 ALTER TABLE `sys_webhook` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_webhook` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tt_content`
--

DROP TABLE IF EXISTS `tt_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tt_content` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rowDescription` text DEFAULT NULL,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l18n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l18n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `CType` varchar(255) NOT NULL DEFAULT '',
  `header` varchar(255) NOT NULL DEFAULT '',
  `header_position` varchar(255) NOT NULL DEFAULT '',
  `bodytext` mediumtext DEFAULT NULL,
  `bullets_type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_description` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `assets` int(10) unsigned NOT NULL DEFAULT 0,
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `imagewidth` int(10) unsigned NOT NULL DEFAULT 0,
  `imageorient` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imagecols` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imageborder` smallint(5) unsigned NOT NULL DEFAULT 0,
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` varchar(255) NOT NULL DEFAULT '',
  `frame_class` varchar(60) NOT NULL DEFAULT 'default',
  `cols` int(10) unsigned NOT NULL DEFAULT 0,
  `space_before_class` varchar(60) NOT NULL DEFAULT '',
  `space_after_class` varchar(60) NOT NULL DEFAULT '',
  `records` text DEFAULT NULL,
  `pages` text DEFAULT NULL,
  `colPos` int(10) unsigned NOT NULL DEFAULT 0,
  `subheader` varchar(255) NOT NULL DEFAULT '',
  `header_link` varchar(1024) NOT NULL DEFAULT '',
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  `header_layout` varchar(30) NOT NULL DEFAULT '0',
  `list_type` varchar(255) NOT NULL DEFAULT '',
  `sectionIndex` smallint(5) unsigned NOT NULL DEFAULT 0,
  `linkToTop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `file_collections` text DEFAULT NULL,
  `filelink_size` smallint(5) unsigned NOT NULL DEFAULT 0,
  `filelink_sorting` varchar(64) NOT NULL DEFAULT '',
  `filelink_sorting_direction` varchar(4) NOT NULL DEFAULT '',
  `target` varchar(30) NOT NULL DEFAULT '',
  `recursive` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imageheight` int(10) unsigned NOT NULL DEFAULT 0,
  `pi_flexform` mediumtext DEFAULT NULL,
  `accessibility_title` varchar(30) NOT NULL DEFAULT '',
  `accessibility_bypass` smallint(5) unsigned NOT NULL DEFAULT 0,
  `accessibility_bypass_text` varchar(30) NOT NULL DEFAULT '',
  `category_field` varchar(64) NOT NULL DEFAULT '',
  `table_class` varchar(60) NOT NULL DEFAULT '',
  `table_caption` varchar(255) DEFAULT NULL,
  `table_delimiter` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_enclosure` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_header_position` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_tfoot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `selected_categories` longtext DEFAULT NULL,
  `date` int(11) NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `teaser` text DEFAULT NULL,
  `aspect_ratio` varchar(255) NOT NULL DEFAULT '1.3333333333333',
  `items_per_page` int(10) unsigned DEFAULT 10,
  `readmore_label` varchar(255) NOT NULL DEFAULT '',
  `quote_source` varchar(255) NOT NULL DEFAULT '',
  `quote_link` varchar(1024) NOT NULL DEFAULT '',
  `panel_class` varchar(60) NOT NULL DEFAULT 'default',
  `file_folder` text DEFAULT NULL,
  `icon` varchar(255) NOT NULL DEFAULT '',
  `icon_set` varchar(255) NOT NULL DEFAULT '',
  `icon_file` int(10) unsigned DEFAULT 0,
  `icon_position` varchar(255) NOT NULL DEFAULT '',
  `icon_size` varchar(60) NOT NULL DEFAULT 'default',
  `icon_type` varchar(60) NOT NULL DEFAULT 'default',
  `icon_color` varchar(255) NOT NULL DEFAULT '',
  `icon_background` varchar(255) NOT NULL DEFAULT '',
  `external_media_source` varchar(1024) NOT NULL DEFAULT '',
  `external_media_ratio` varchar(10) NOT NULL DEFAULT '',
  `tx_bootstrappackage_card_group_item` int(10) unsigned DEFAULT 0,
  `tx_bootstrappackage_carousel_item` int(10) unsigned DEFAULT 0,
  `tx_bootstrappackage_accordion_item` int(10) unsigned DEFAULT 0,
  `tx_bootstrappackage_icon_group_item` int(10) unsigned DEFAULT 0,
  `tx_bootstrappackage_tab_item` int(10) unsigned DEFAULT 0,
  `tx_bootstrappackage_timeline_item` int(10) unsigned DEFAULT 0,
  `frame_layout` varchar(255) NOT NULL DEFAULT 'default',
  `frame_options` varchar(255) NOT NULL DEFAULT '',
  `background_color_class` varchar(255) NOT NULL DEFAULT '',
  `background_image` int(10) unsigned DEFAULT 0,
  `background_image_options` mediumtext DEFAULT NULL,
  `tx_pizpalue_header_class` varchar(255) NOT NULL DEFAULT '',
  `tx_pizpalue_subheader_class` varchar(255) NOT NULL DEFAULT '',
  `tx_pizpalue_layout_breakpoint` varchar(15) NOT NULL DEFAULT '',
  `tx_pizpalue_inner_space_before_class` varchar(255) NOT NULL DEFAULT '',
  `tx_pizpalue_inner_space_after_class` varchar(255) NOT NULL DEFAULT '',
  `tx_pizpalue_classes` varchar(255) NOT NULL DEFAULT '',
  `tx_pizpalue_inner_classes` varchar(255) NOT NULL DEFAULT '',
  `tx_pizpalue_style` text DEFAULT NULL,
  `tx_pizpalue_attributes` varchar(255) NOT NULL DEFAULT '',
  `tx_pizpalue_animation` varchar(255) NOT NULL DEFAULT '',
  `tx_pizpalue_image_variants` varchar(255) NOT NULL DEFAULT 'variants',
  `tx_pizpalue_background_image_variants` varchar(255) NOT NULL DEFAULT 'pageVariants',
  `tx_pizpalue_image_scaling` text DEFAULT NULL,
  `tx_pizpalue_image_aspect_ratio` text DEFAULT NULL,
  `tx_pizpalue_scroll_navigation_enable` smallint(6) NOT NULL DEFAULT 0,
  `tx_pizpalue_scroll_navigation_title` varchar(255) NOT NULL DEFAULT '',
  `tx_pizpalue_scroll_navigation_position` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`sorting`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l18n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tt_content`
--

LOCK TABLES `tt_content` WRITE;
/*!40000 ALTER TABLE `tt_content` DISABLE KEYS */;
INSERT INTO `tt_content` VALUES (1,'',1,1685617146,1685616546,0,0,0,0,'',256,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"header_layout\":\"\",\"tx_pizpalue_header_class\":\"\",\"header_position\":\"\",\"date\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"tx_pizpalue_subheader_class\":\"\",\"list_type\":\"\",\"tx_pizpalue_image_variants\":\"\",\"pages\":\"\",\"recursive\":\"\",\"layout\":\"\",\"tx_pizpalue_layout_breakpoint\":\"\",\"frame_class\":\"\",\"frame_layout\":\"\",\"frame_options\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"tx_pizpalue_inner_space_before_class\":\"\",\"tx_pizpalue_inner_space_after_class\":\"\",\"background_color_class\":\"\",\"background_image\":\"\",\"tx_pizpalue_animation\":\"\",\"tx_pizpalue_classes\":\"\",\"tx_pizpalue_inner_classes\":\"\",\"tx_pizpalue_style\":\"\",\"tx_pizpalue_attributes\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"tx_pizpalue_scroll_navigation_enable\":\"\",\"tx_pizpalue_scroll_navigation_title\":\"\",\"tx_pizpalue_scroll_navigation_position\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'list','','',NULL,0,0,0,0,0,0,0,1,0,0,'0','default',0,'','',NULL,'3',0,'','',0,'0','timelog_taskpanel',1,0,NULL,0,'','','',0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL,0,0,NULL,'1.3333333333333',10,'','','','default',NULL,'','',0,'','default','default','','','','',0,0,0,0,0,0,'default','','none',0,NULL,'none','none','','','','','','','','0','variants','pageVariants','xxl: 1.0,\nxl: 1.0,\nlg: 1.0,\nmd: 1.0,\nsm: 1.0,\nxs: 1.0','xxl: 0,\nxl: 0,\nlg: 0,\nmd: 0,\nsm: 0,\nxs: 0',0,'',0);
/*!40000 ALTER TABLE `tt_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_bootstrappackage_accordion_item`
--

DROP TABLE IF EXISTS `tx_bootstrappackage_accordion_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_bootstrappackage_accordion_item` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `tt_content` int(10) unsigned DEFAULT 0,
  `header` varchar(255) NOT NULL DEFAULT '',
  `bodytext` text DEFAULT NULL,
  `media` int(10) unsigned DEFAULT 0,
  `mediaorient` varchar(60) NOT NULL DEFAULT 'left',
  `imagecols` smallint(5) unsigned NOT NULL DEFAULT 1,
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_bootstrappackage_accordion_item`
--

LOCK TABLES `tx_bootstrappackage_accordion_item` WRITE;
/*!40000 ALTER TABLE `tx_bootstrappackage_accordion_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_bootstrappackage_accordion_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_bootstrappackage_card_group_item`
--

DROP TABLE IF EXISTS `tx_bootstrappackage_card_group_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_bootstrappackage_card_group_item` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `tt_content` int(10) unsigned DEFAULT 0,
  `header` varchar(255) NOT NULL DEFAULT '',
  `subheader` varchar(255) NOT NULL DEFAULT '',
  `image` int(11) NOT NULL DEFAULT 0,
  `bodytext` text DEFAULT NULL,
  `link` varchar(1024) NOT NULL DEFAULT '',
  `link_title` varchar(255) NOT NULL DEFAULT '',
  `link_icon_set` varchar(255) NOT NULL DEFAULT '',
  `link_icon_identifier` varchar(255) NOT NULL DEFAULT '',
  `link_icon` int(10) unsigned DEFAULT 0,
  `link_class` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_bootstrappackage_card_group_item`
--

LOCK TABLES `tx_bootstrappackage_card_group_item` WRITE;
/*!40000 ALTER TABLE `tx_bootstrappackage_card_group_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_bootstrappackage_card_group_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_bootstrappackage_carousel_item`
--

DROP TABLE IF EXISTS `tx_bootstrappackage_carousel_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_bootstrappackage_carousel_item` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `tt_content` int(10) unsigned DEFAULT 0,
  `item_type` varchar(255) NOT NULL DEFAULT '',
  `layout` varchar(255) NOT NULL DEFAULT '',
  `header` varchar(255) NOT NULL DEFAULT '',
  `header_layout` smallint(5) unsigned NOT NULL DEFAULT 1,
  `header_position` varchar(255) NOT NULL DEFAULT 'center',
  `header_class` varchar(255) NOT NULL DEFAULT '',
  `subheader` varchar(255) NOT NULL DEFAULT '',
  `subheader_layout` smallint(5) unsigned NOT NULL DEFAULT 2,
  `subheader_class` varchar(255) NOT NULL DEFAULT '',
  `nav_title` varchar(255) NOT NULL DEFAULT '',
  `button_text` varchar(255) NOT NULL DEFAULT '',
  `bodytext` text DEFAULT NULL,
  `image` int(10) unsigned DEFAULT 0,
  `link` varchar(1024) NOT NULL DEFAULT '',
  `text_color` varchar(255) NOT NULL DEFAULT '',
  `background_color` varchar(255) NOT NULL DEFAULT '',
  `background_image` int(10) unsigned DEFAULT 0,
  `background_image_options` mediumtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_bootstrappackage_carousel_item`
--

LOCK TABLES `tx_bootstrappackage_carousel_item` WRITE;
/*!40000 ALTER TABLE `tx_bootstrappackage_carousel_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_bootstrappackage_carousel_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_bootstrappackage_icon_group_item`
--

DROP TABLE IF EXISTS `tx_bootstrappackage_icon_group_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_bootstrappackage_icon_group_item` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `tt_content` int(10) unsigned DEFAULT 0,
  `header` varchar(255) NOT NULL DEFAULT '',
  `subheader` varchar(255) NOT NULL DEFAULT '',
  `bodytext` text DEFAULT NULL,
  `link` varchar(1024) NOT NULL DEFAULT '',
  `icon_set` varchar(255) NOT NULL DEFAULT '',
  `icon_identifier` varchar(255) NOT NULL DEFAULT '',
  `icon_file` int(10) unsigned DEFAULT 0,
  `tx_pizpalue_icon_color` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_bootstrappackage_icon_group_item`
--

LOCK TABLES `tx_bootstrappackage_icon_group_item` WRITE;
/*!40000 ALTER TABLE `tx_bootstrappackage_icon_group_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_bootstrappackage_icon_group_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_bootstrappackage_tab_item`
--

DROP TABLE IF EXISTS `tx_bootstrappackage_tab_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_bootstrappackage_tab_item` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `tt_content` int(10) unsigned DEFAULT 0,
  `header` varchar(255) NOT NULL DEFAULT '',
  `bodytext` text DEFAULT NULL,
  `media` int(10) unsigned DEFAULT 0,
  `mediaorient` varchar(60) NOT NULL DEFAULT 'left',
  `imagecols` smallint(5) unsigned NOT NULL DEFAULT 1,
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_bootstrappackage_tab_item`
--

LOCK TABLES `tx_bootstrappackage_tab_item` WRITE;
/*!40000 ALTER TABLE `tx_bootstrappackage_tab_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_bootstrappackage_tab_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_bootstrappackage_timeline_item`
--

DROP TABLE IF EXISTS `tx_bootstrappackage_timeline_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_bootstrappackage_timeline_item` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `tt_content` int(10) unsigned DEFAULT 0,
  `date` datetime DEFAULT NULL,
  `header` varchar(255) NOT NULL DEFAULT '',
  `bodytext` text DEFAULT NULL,
  `icon_set` varchar(255) NOT NULL DEFAULT '',
  `icon_identifier` varchar(255) NOT NULL DEFAULT '',
  `icon_file` int(10) unsigned DEFAULT 0,
  `image` int(10) unsigned DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_bootstrappackage_timeline_item`
--

LOCK TABLES `tx_bootstrappackage_timeline_item` WRITE;
/*!40000 ALTER TABLE `tx_bootstrappackage_timeline_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_bootstrappackage_timeline_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_easyconf_configuration`
--

DROP TABLE IF EXISTS `tx_easyconf_configuration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_easyconf_configuration` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `scaffold_contact_button_page_uid` varchar(100) NOT NULL DEFAULT '',
  `logo_file_reference` int(10) unsigned DEFAULT 0,
  `logo_file_inverted_reference` int(10) unsigned DEFAULT 0,
  `appicon_generator_archive` int(10) unsigned DEFAULT 0,
  `appicon_generator_text` text DEFAULT NULL,
  `menu_fast_items_first_content_uid` varchar(100) NOT NULL DEFAULT '',
  `menu_fast_items_first_page_uid` varchar(100) NOT NULL DEFAULT '',
  `menu_fast_items_second_content_uid` varchar(100) NOT NULL DEFAULT '',
  `menu_fast_items_second_page_uid` varchar(100) NOT NULL DEFAULT '',
  `menu_fast_items_third_content_uid` varchar(100) NOT NULL DEFAULT '',
  `menu_fast_items_third_page_uid` varchar(100) NOT NULL DEFAULT '',
  `menu_scroll_page_uid` varchar(100) NOT NULL DEFAULT '',
  `social_channel_facebook` varchar(100) NOT NULL DEFAULT '',
  `social_channel_github` varchar(100) NOT NULL DEFAULT '',
  `social_channel_googleplus` varchar(100) NOT NULL DEFAULT '',
  `social_channel_instagram` varchar(100) NOT NULL DEFAULT '',
  `social_channel_linkedin` varchar(100) NOT NULL DEFAULT '',
  `social_channel_pinterest` varchar(100) NOT NULL DEFAULT '',
  `social_channel_rss` varchar(100) NOT NULL DEFAULT '',
  `social_channel_twitter` varchar(100) NOT NULL DEFAULT '',
  `social_channel_vimeo` varchar(100) NOT NULL DEFAULT '',
  `social_channel_vk` varchar(100) NOT NULL DEFAULT '',
  `social_channel_xing` varchar(100) NOT NULL DEFAULT '',
  `social_channel_youtube` varchar(100) NOT NULL DEFAULT '',
  `cookie_content_href` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_easyconf_configuration`
--

LOCK TABLES `tx_easyconf_configuration` WRITE;
/*!40000 ALTER TABLE `tx_easyconf_configuration` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_easyconf_configuration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_extensionmanager_domain_model_extension`
--

DROP TABLE IF EXISTS `tx_extensionmanager_domain_model_extension`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_extensionmanager_domain_model_extension` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `extension_key` varchar(60) NOT NULL DEFAULT '',
  `repository` int(11) NOT NULL DEFAULT 1,
  `remote` varchar(100) NOT NULL DEFAULT 'ter',
  `version` varchar(15) NOT NULL DEFAULT '',
  `alldownloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `downloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(150) NOT NULL DEFAULT '',
  `description` mediumtext DEFAULT NULL,
  `state` int(11) NOT NULL DEFAULT 0,
  `review_state` int(11) NOT NULL DEFAULT 0,
  `category` int(11) NOT NULL DEFAULT 0,
  `serialized_dependencies` mediumtext DEFAULT NULL,
  `author_name` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `ownerusername` varchar(50) NOT NULL DEFAULT '',
  `md5hash` varchar(35) NOT NULL DEFAULT '',
  `update_comment` mediumtext DEFAULT NULL,
  `authorcompany` varchar(255) NOT NULL DEFAULT '',
  `integer_version` int(11) NOT NULL DEFAULT 0,
  `current_version` int(11) NOT NULL DEFAULT 0,
  `lastreviewedversion` int(11) NOT NULL DEFAULT 0,
  `documentation_link` varchar(2048) DEFAULT NULL,
  `distribution_image` varchar(255) DEFAULT NULL,
  `distribution_welcome_image` varchar(255) DEFAULT NULL,
  `last_updated` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `versionextrepo` (`extension_key`,`version`,`remote`),
  KEY `index_extrepo` (`extension_key`,`remote`),
  KEY `index_versionrepo` (`integer_version`,`remote`,`extension_key`),
  KEY `index_currentversions` (`current_version`,`review_state`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_extensionmanager_domain_model_extension`
--

LOCK TABLES `tx_extensionmanager_domain_model_extension` WRITE;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_impexp_presets`
--

DROP TABLE IF EXISTS `tx_impexp_presets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_impexp_presets` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `public` smallint(6) NOT NULL DEFAULT 0,
  `item_uid` int(11) NOT NULL DEFAULT 0,
  `user_uid` int(10) unsigned NOT NULL DEFAULT 0,
  `preset_data` blob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `lookup` (`item_uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_impexp_presets`
--

LOCK TABLES `tx_impexp_presets` WRITE;
/*!40000 ALTER TABLE `tx_impexp_presets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_impexp_presets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_timelog_domain_model_interval`
--

DROP TABLE IF EXISTS `tx_timelog_domain_model_interval`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_timelog_domain_model_interval` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `task` int(10) unsigned NOT NULL DEFAULT 0,
  `start_time` int(11) NOT NULL DEFAULT 0,
  `end_time` int(11) NOT NULL DEFAULT 0,
  `duration` double NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_timelog_domain_model_interval`
--

LOCK TABLES `tx_timelog_domain_model_interval` WRITE;
/*!40000 ALTER TABLE `tx_timelog_domain_model_interval` DISABLE KEYS */;
INSERT INTO `tx_timelog_domain_model_interval` VALUES (1,3,1685620422,1685614704,0,0,0,0,0,1,1685607420,1685608020,0.16666666666667),(2,3,1685706158,1685616397,0,0,0,0,0,2,1685612400,1685612760,0.1);
/*!40000 ALTER TABLE `tx_timelog_domain_model_interval` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_timelog_domain_model_project`
--

DROP TABLE IF EXISTS `tx_timelog_domain_model_project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_timelog_domain_model_project` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `handle` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `description` text DEFAULT NULL,
  `internal_note` text DEFAULT NULL,
  `active_time` double NOT NULL DEFAULT 0,
  `heap_time` double NOT NULL DEFAULT 0,
  `batch_time` double NOT NULL DEFAULT 0,
  `client` int(10) unsigned DEFAULT 0,
  `owner` int(10) unsigned DEFAULT 0,
  `cc_email` varchar(255) NOT NULL DEFAULT '',
  `tasks` int(10) unsigned NOT NULL DEFAULT 0,
  `task_groups` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_timelog_domain_model_project`
--

LOCK TABLES `tx_timelog_domain_model_project` WRITE;
/*!40000 ALTER TABLE `tx_timelog_domain_model_project` DISABLE KEYS */;
INSERT INTO `tx_timelog_domain_model_project` VALUES (1,3,1685728213,1685619274,0,0,0,0,0,'gZx0px5n','project 1','description from project 1  \r\nrow2\r\n\r\nrow4','',0.26666666666667,0.26666666666667,0,4,3,'',2,1);
/*!40000 ALTER TABLE `tx_timelog_domain_model_project` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_timelog_domain_model_task`
--

DROP TABLE IF EXISTS `tx_timelog_domain_model_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_timelog_domain_model_task` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `handle` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `description` text DEFAULT NULL,
  `active_time` double NOT NULL DEFAULT 0,
  `batch_date` int(11) NOT NULL DEFAULT 0,
  `project` int(10) unsigned DEFAULT 0,
  `worker` int(10) unsigned DEFAULT 0,
  `task_group` int(10) unsigned DEFAULT 0,
  `intervals` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_timelog_domain_model_task`
--

LOCK TABLES `tx_timelog_domain_model_task` WRITE;
/*!40000 ALTER TABLE `tx_timelog_domain_model_task` DISABLE KEYS */;
INSERT INTO `tx_timelog_domain_model_task` VALUES (1,3,1685728213,1685614704,0,0,0,0,0,'OkZJvZ7W','title goes here','description goes here',0.16666666666667,0,1,1,0,1),(2,3,1685728213,1685616397,0,0,0,0,0,'VjYxLYGD','title goes here','description goes here',0.1,0,1,2,2,1),(3,3,1685633594,1685633577,1,0,0,0,0,'105Nqp98','','',0,0,0,2,0,0);
/*!40000 ALTER TABLE `tx_timelog_domain_model_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_timelog_domain_model_taskgroup`
--

DROP TABLE IF EXISTS `tx_timelog_domain_model_taskgroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_timelog_domain_model_taskgroup` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `handle` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `description` text DEFAULT NULL,
  `internal_note` text DEFAULT NULL,
  `time_target` double NOT NULL DEFAULT 0,
  `time_deviation` double NOT NULL DEFAULT 0,
  `active_time` double NOT NULL DEFAULT 0,
  `heap_time` double NOT NULL DEFAULT 0,
  `batch_time` double NOT NULL DEFAULT 0,
  `project` int(10) unsigned DEFAULT 0,
  `tasks` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_timelog_domain_model_taskgroup`
--

LOCK TABLES `tx_timelog_domain_model_taskgroup` WRITE;
/*!40000 ALTER TABLE `tx_timelog_domain_model_taskgroup` DISABLE KEYS */;
INSERT INTO `tx_timelog_domain_model_taskgroup` VALUES (1,3,1685619480,1685618901,0,0,0,0,0,'9d05nZyE','task group 1','description from task group 1','',0,-0.26666666666667,0.26666666666667,0.26666666666667,0,0,2),(2,3,1685728213,1685619673,0,0,0,0,0,'AgN6gxYp','task group 2','description from task group 2','',0,-0.1,0.1,0.1,0,1,0);
/*!40000 ALTER TABLE `tx_timelog_domain_model_taskgroup` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-07-11  6:39:09
